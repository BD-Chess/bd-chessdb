'use strict';

const { blackRatio, getOpenComponents, countTwoByTwoBlacks, symmetryMismatch, uglyPocketScore, crossingStats } = require('./cw_metrics');

function evaluateState(mask, assignments, trace = {}, opts = {}) {
  const components = getOpenComponents(mask);
  const filledSlots = Object.values(assignments);
  const filled = filledSlots.filter(s => s && s.word);
  const slotCount = Number(trace.slotCount || filledSlots.length || 0);
  const fillRatio = filled.length / Math.max(1, slotCount);
  const slotLens = Array.isArray(trace.slotLens) ? trace.slotLens : filledSlots.map(s => s.len);
  const cross = crossingStats(mask, filledSlots);
  const targetBlackMin = Number(trace.targetBlackMin ?? opts.targetBlackMin ?? 0.16);
  const targetBlackMax = Number(trace.targetBlackMax ?? opts.targetBlackMax ?? 0.30);
  const longSlots = slotLens.filter(x => x >= 8).length;
  const hugeSlots = slotLens.filter(x => x >= Math.max(mask.length - 1, 8)).length;
  const black = blackRatio(mask);
  const avgWordScore = filled.length ? filled.reduce((a, s) => a + (s.score || 0), 0) / filled.length : 0;
  const garbageWords = filled.filter(s => (s.score || 0) < 65 || (s.shapePenalty || 0) > 8 || (s.tier || 1) > 1).length;
  const lowHintCount = filled.filter(s => !s.h).length;
  const twoByTwo = countTwoByTwoBlacks(mask);
  const asymmetry = symmetryMismatch(mask);
  const ugly = uglyPocketScore(mask);
  const searchCost = Math.log1p(Number(trace.backtracks || 0) + Number(trace.maskMutations || 0) * 4 + Number(trace.fillAttempts || 0) * 2);
  const deadSlots = Number(trace.deadSlots || 0);
  const entropyPenalty = Number(trace.avgEntropy || 0) <= 0 ? 20 : Math.max(0, 10 - Number(trace.avgEntropy || 0));

  const L_black = black * 140 + Math.max(0, targetBlackMin - black) * 700 + Math.max(0, black - targetBlackMax) * 260;
  const L_disconnect = Math.max(0, components.length - 1) * 220;
  const L_unchecked = cross.unchecked * 5.5;
  const L_deadends = ugly * 2.2 + deadSlots * 16 + twoByTwo * 25;
  const L_rarity = filled.reduce((a, s) => a + Math.max(0, 82 - (s.score || 0)) * 0.28, 0);
  const L_bad_words = garbageWords * 8 + lowHintCount * 0.4;
  const L_repeat = duplicatePenalty(filled) + sameStemPenalty(filled);
  const L_shape = asymmetry * 40 + slotVariancePenalty(filled.length, slotLens) + perimeterClutter(mask) * 2.5 + longSlots * 6 + hugeSlots * 16;
  const L_search_cost = searchCost * 8 + entropyPenalty;

  const R_cross = cross.crossingDensity * 44;
  const R_fill = fillRatio * 52;
  const R_words = Math.max(0, avgWordScore - 60) * 0.65;
  const R_dense = (1 - black) * 14;

  const total = L_black + L_disconnect + L_unchecked + L_deadends + L_rarity + L_bad_words + L_repeat + L_shape + L_search_cost - R_cross - R_fill - R_words - R_dense;

  return {
    total: round2(total),
    penalties: {
      L_black: round2(L_black),
      L_disconnect: round2(L_disconnect),
      L_unchecked: round2(L_unchecked),
      L_deadends: round2(L_deadends),
      L_rarity: round2(L_rarity),
      L_bad_words: round2(L_bad_words),
      L_repeat: round2(L_repeat),
      L_shape: round2(L_shape),
      L_search_cost: round2(L_search_cost),
    },
    rewards: {
      R_cross: round2(R_cross),
      R_fill: round2(R_fill),
      R_words: round2(R_words),
      R_dense: round2(R_dense),
    },
    metrics: {
      components: components.length,
      blackRatio: round4(black),
      fillRatio: round4(fillRatio),
      crossingDensity: round4(cross.crossingDensity),
      checkedLetters: cross.checked,
      uncheckedLetters: cross.unchecked,
      averageWordScore: round2(avgWordScore),
      garbageWords,
      lowHintCount,
      twoByTwoBlacks: twoByTwo,
      asymmetry: round4(asymmetry),
      uglyPocketScore: round2(ugly),
      searchCost: round2(searchCost),
    }
  };
}

function duplicatePenalty(filled) {
  const seen = new Set();
  let pen = 0;
  for (const s of filled) {
    if (seen.has(s.word)) pen += 25;
    seen.add(s.word);
  }
  return pen;
}

function sameStemPenalty(filled) {
  const counts = new Map();
  for (const s of filled) {
    const stem = String(s.word || '').slice(0, Math.min(4, String(s.word || '').length));
    counts.set(stem, (counts.get(stem) || 0) + 1);
  }
  let pen = 0;
  for (const v of counts.values()) if (v > 2) pen += (v - 2) * 4;
  return pen;
}

function slotVariancePenalty(filledCount, slotLens) {
  if (!slotLens.length) return 20;
  const mean = slotLens.reduce((a, b) => a + b, 0) / slotLens.length;
  const variance = slotLens.reduce((a, b) => a + (b - mean) ** 2, 0) / slotLens.length;
  const unfilled = slotLens.length - filledCount;
  return variance * 0.8 + unfilled * 18;
}

function perimeterClutter(mask) {
  const n = mask.length;
  let pen = 0;
  for (let i = 0; i < n; i++) {
    if (!mask[0][i]) pen += 0.4;
    if (!mask[n - 1][i]) pen += 0.4;
    if (!mask[i][0]) pen += 0.4;
    if (!mask[i][n - 1]) pen += 0.4;
  }
  return pen;
}

function round2(x) { return Math.round(x * 100) / 100; }
function round4(x) { return Math.round(x * 10000) / 10000; }

module.exports = { evaluateState };
