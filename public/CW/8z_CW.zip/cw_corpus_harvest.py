
#!/usr/bin/env python3
"""
cw_corpus_harvest.py

Build a local crossword corpus from public/open sources and normalize what we can.

Goals:
- download public/open crossword-related sources from GitHub / Hugging Face / generic URLs
- optionally include "risky/unclear-rights" sources only if user explicitly asks
- extract:
    * full solved grids, when present
    * clue-answer pairs
    * crossword entry/word lists
- dedupe and write normalized artifacts for later MDL analysis and dictionary curation

No hard dependency beyond the Python standard library.
Optional:
    pip install puzpy
for .puz parsing

Usage:
    python cw_corpus_harvest.py --out corpus
    python cw_corpus_harvest.py --out corpus --include-risky
    python cw_corpus_harvest.py --manifest my_sources.json --out corpus

Manifest format:
{
  "sources": [
    {
      "id": "nzfeng_dataset",
      "enabled": true,
      "risk": "open",
      "type": "github_repo_zip",
      "owner": "nzfeng",
      "repo": "crossword-dataset",
      "ref": "main",
      "notes": "GPL-3.0 curated crossword entries"
    }
  ]
}
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import re
import shutil
import sys
import tarfile
import time
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen

UA = "Mozilla/5.0 (compatible; cw-corpus-harvest/1.0; +local-research)"
TIMEOUT = 60

DEFAULT_MANIFEST = {
    "sources": [
        {
            "id": "nzfeng_crossword_dataset",
            "enabled": True,
            "risk": "open",
            "type": "github_repo_zip",
            "owner": "nzfeng",
            "repo": "crossword-dataset",
            "ref": "main",
            "notes": "Curated ~42k crossword entries / GPL-3.0"
        },
        {
            "id": "crosswordqa_hf",
            "enabled": True,
            "risk": "mixed",
            "type": "hf_file",
            "repo_id": "albertxu/CrosswordQA",
            "file_path": "data/train-00000-of-00001.parquet",
            "notes": "Large clue-answer dataset; provenance mixed/scraped, use with care"
        },
        {
            "id": "crosswordbench_hf_readme",
            "enabled": True,
            "risk": "open",
            "type": "generic_url",
            "url": "https://huggingface.co/datasets/SeanLeng1/CrossWordBench/raw/main/README.md",
            "notes": "Small anchor to keep CrossWordBench in corpus metadata; add actual files manually if desired"
        },
        {
            "id": "nyt_crosswords_archive_optin",
            "enabled": False,
            "risk": "unclear",
            "type": "github_repo_zip",
            "owner": "doshea",
            "repo": "nyt_crosswords",
            "ref": "master",
            "notes": "Public GitHub archive exists, but rights/provenance are not clean; opt-in only"
        }
    ]
}

def log(*args):
    print(*args, file=sys.stderr)

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)

def fetch_bytes(url: str, dest: Optional[Path] = None) -> bytes:
    req = Request(url, headers={"User-Agent": UA})
    with urlopen(req, timeout=TIMEOUT) as resp:
        data = resp.read()
    if dest:
        ensure_dir(dest.parent)
        dest.write_bytes(data)
    return data

def safe_name(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", s)

def default_manifest_path(out_dir: Path) -> Path:
    return out_dir / "manifest_used.json"

def load_manifest(path: Optional[Path], out_dir: Path) -> dict:
    if path and path.exists():
        manifest = json.loads(path.read_text(encoding="utf-8"))
    else:
        manifest = DEFAULT_MANIFEST
    default_manifest_path(out_dir).write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest

def iter_enabled_sources(manifest: dict, include_risky: bool):
    for src in manifest.get("sources", []):
        if not src.get("enabled", True):
            continue
        risk = src.get("risk", "open")
        if risk in {"unclear", "mixed"} and not include_risky:
            log(f"[skip] {src['id']} risk={risk}; use --include-risky to enable")
            continue
        yield src

def download_source(src: dict, raw_dir: Path) -> List[Path]:
    stype = src["type"]
    source_id = src["id"]
    target_dir = raw_dir / safe_name(source_id)
    ensure_dir(target_dir)
    outputs: List[Path] = []

    if stype == "github_repo_zip":
        owner = src["owner"]
        repo = src["repo"]
        ref = src.get("ref", "main")
        url = f"https://codeload.github.com/{owner}/{repo}/zip/refs/heads/{ref}"
        zip_path = target_dir / f"{repo}-{ref}.zip"
        log(f"[download] {source_id} <- {url}")
        fetch_bytes(url, zip_path)
        extract_dir = target_dir / "extracted"
        ensure_dir(extract_dir)
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_dir)
        outputs.append(extract_dir)

    elif stype == "hf_file":
        repo_id = src["repo_id"]
        file_path = src["file_path"].lstrip("/")
        # datasets/ form
        url = f"https://huggingface.co/datasets/{repo_id}/resolve/main/{file_path}?download=1"
        out_path = target_dir / Path(file_path).name
        log(f"[download] {source_id} <- {url}")
        fetch_bytes(url, out_path)
        outputs.append(out_path)

    elif stype == "generic_url":
        url = src["url"]
        out_path = target_dir / Path(urlparse(url).path).name
        if not out_path.name:
            out_path = target_dir / "download.bin"
        log(f"[download] {source_id} <- {url}")
        fetch_bytes(url, out_path)
        outputs.append(out_path)

    elif stype == "site_crawl":
        outputs.extend(crawl_site_source(src, target_dir))

    else:
        raise ValueError(f"Unknown source type: {stype}")

    return outputs

class LinkExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag.lower() == "a" and "href" in attrs:
            self.links.append(attrs["href"])

def crawl_site_source(src: dict, target_dir: Path) -> List[Path]:
    seed_urls = src.get("seed_urls", [])
    allowed_domains = set(src.get("allowed_domains", []))
    file_exts = tuple(src.get("file_exts", [".puz", ".ipuz", ".json", ".xd", ".html"]))
    max_pages = int(src.get("max_pages", 200))
    max_files = int(src.get("max_files", 500))
    queue = list(seed_urls)
    seen_pages = set()
    files = []
    pages = 0

    while queue and pages < max_pages and len(files) < max_files:
        url = queue.pop(0)
        if url in seen_pages:
            continue
        seen_pages.add(url)
        try:
            data = fetch_bytes(url)
        except Exception as e:
            log(f"[crawl-skip] {url}: {e}")
            continue
        pages += 1
        ctype = "text/html"
        if url.lower().endswith(file_exts):
            fname = safe_name(urlparse(url).path.strip("/")) or f"file_{len(files)}"
            out_path = target_dir / fname
            out_path.write_bytes(data)
            files.append(out_path)
            continue
        text = data.decode("utf-8", errors="ignore")
        ex = LinkExtractor()
        try:
            ex.feed(text)
        except Exception:
            pass
        for href in ex.links:
            absu = urljoin(url, href)
            parsed = urlparse(absu)
            if allowed_domains and parsed.netloc not in allowed_domains:
                continue
            if parsed.scheme not in {"http", "https"}:
                continue
            if absu.lower().endswith(file_exts):
                if absu not in seen_pages:
                    queue.append(absu)
            else:
                if absu not in seen_pages:
                    queue.append(absu)
        # save exolve-style html too
        if "exolve-begin" in text and "exolve-end" in text:
            fname = safe_name(urlparse(url).path.strip("/")) + ".html"
            out_path = target_dir / fname
            out_path.write_text(text, encoding="utf-8")
            files.append(out_path)
    return files

# -------- Parsing / normalization --------

ENTRY_CLEAN_RE = re.compile(r"[^A-Z ]+")
MULTISPACE_RE = re.compile(r"\s+")

def norm_entry(s: str) -> str:
    s = s.upper().replace("-", " ").replace("_", " ")
    s = ENTRY_CLEAN_RE.sub("", s)
    s = MULTISPACE_RE.sub(" ", s).strip()
    return s

def load_optional_puz():
    try:
        import puz  # type: ignore
        return puz
    except Exception:
        return None

PUZ = load_optional_puz()

def parse_puz(path: Path) -> Optional[dict]:
    if PUZ is None:
        return None
    try:
        p = PUZ.read(str(path))
    except Exception:
        return None
    width, height = p.width, p.height
    sol = p.solution
    rows = [sol[i*width:(i+1)*width] for i in range(height)]
    answers = []
    fill = getattr(p, "fill", "")
    # if clue numbering exists, still just normalize entries from rows/cols
    answers.extend(extract_entries_from_rows(rows))
    return {
        "kind": "puzzle_full_grid",
        "title": getattr(p, "title", None),
        "author": getattr(p, "author", None),
        "rows": rows,
        "entries": sorted(set(a for a in answers if a)),
    }

def extract_entries_from_rows(rows: List[str]) -> List[str]:
    entries = []
    h = len(rows)
    w = len(rows[0]) if rows else 0
    # across
    for r in range(h):
        for seg in rows[r].split("#"):
            e = norm_entry(seg)
            if len(e.replace(" ", "")) >= 3:
                entries.append(e)
    # down
    for c in range(w):
        col = "".join(rows[r][c] for r in range(h))
        for seg in col.split("#"):
            e = norm_entry(seg)
            if len(e.replace(" ", "")) >= 3:
                entries.append(e)
    return entries

def parse_ipuz_like(obj: dict) -> Optional[dict]:
    # Handles many ipuz-ish JSONs if they contain solution arrays
    sol = obj.get("solution") or obj.get("grid")
    if not sol:
        return None
    rows = []
    try:
        if isinstance(sol, list) and sol and isinstance(sol[0], list):
            for row in sol:
                chars = []
                for cell in row:
                    if isinstance(cell, str):
                        chars.append("#" if cell in {"#", ".", "0"} else cell.upper())
                    elif isinstance(cell, dict):
                        value = cell.get("value") or cell.get("cell") or "#"
                        chars.append("#" if str(value) in {"#", ".", "0"} else str(value).upper())
                    elif isinstance(cell, int):
                        chars.append("#" if cell == 0 else str(cell))
                    else:
                        chars.append("#")
                rows.append("".join(chars))
        elif isinstance(sol, list) and sol and isinstance(sol[0], str):
            # maybe flat list or list of strings
            if len(sol) > 1 and all(isinstance(x, str) for x in sol):
                # list of row strings
                rows = [x.replace(".", "#").upper() for x in sol]
        if not rows:
            return None
        entries = extract_entries_from_rows(rows)
        return {
            "kind": "puzzle_full_grid",
            "title": obj.get("title") or obj.get("metadata", {}).get("title"),
            "author": obj.get("author") or obj.get("metadata", {}).get("author"),
            "rows": rows,
            "entries": sorted(set(entries)),
        }
    except Exception:
        return None

def parse_nyt_json_like(obj: dict) -> Optional[dict]:
    # Handle common NYT-style archive variants
    # 1) rows or grid array present
    if "grid" in obj:
        g = obj["grid"]
        size = obj.get("size", {})
        rows = []
        if isinstance(g, list) and g and all(isinstance(x, str) for x in g):
            # could be row strings or flat cells
            if len(set(map(len, g))) == 1 and len(g) > 1:
                rows = [r.replace(".", "#").upper() for r in g]
            else:
                cols = size.get("cols")
                rows_n = size.get("rows")
                if cols and rows_n and len(g) == cols * rows_n:
                    for r in range(rows_n):
                        row = "".join("#" if str(g[r*cols+c]) in {".", "#", "0"} else str(g[r*cols+c]).upper()
                                      for c in range(cols))
                        rows.append(row)
        if rows:
            return {
                "kind": "puzzle_full_grid",
                "title": obj.get("title"),
                "author": obj.get("author"),
                "date": obj.get("date"),
                "rows": rows,
                "entries": sorted(set(extract_entries_from_rows(rows))),
            }
    # 2) answers across/down only
    ans = obj.get("answers")
    if isinstance(ans, dict):
        entries = []
        for k in ("across", "down"):
            part = ans.get(k, [])
            if isinstance(part, list):
                entries.extend(norm_entry(x) for x in part if isinstance(x, str))
            elif isinstance(part, dict):
                entries.extend(norm_entry(v) for v in part.values() if isinstance(v, str))
        entries = [e for e in entries if len(e.replace(" ", "")) >= 3]
        if entries:
            return {
                "kind": "clue_answer_or_entries",
                "title": obj.get("title"),
                "author": obj.get("author"),
                "date": obj.get("date"),
                "entries": sorted(set(entries)),
            }
    return None

def parse_exolve_html_or_xd_text(text: str) -> Optional[dict]:
    # Very light exolve/xd extraction
    lower = text.lower()
    title = None
    m = re.search(r'^\s*title:\s*(.+)$', text, flags=re.MULTILINE)
    if m:
        title = m.group(1).strip()
    if "## Grid" in text and "## Clues" in text:
        m = re.search(r"## Grid\s+(.*?)\s+## Clues", text, flags=re.DOTALL | re.IGNORECASE)
        if m:
            block = m.group(1)
            rows = []
            for line in block.splitlines():
                line = line.strip()
                if not line:
                    continue
                if re.fullmatch(r"[A-Za-z.#0-9]+", line):
                    rows.append(line.replace(".", "#").replace("0", "#").upper())
            if rows:
                return {
                    "kind": "puzzle_full_grid",
                    "title": title,
                    "rows": rows,
                    "entries": sorted(set(extract_entries_from_rows(rows))),
                }
    # exolve html: try to find exolve-begin .. exolve-end and parse grid rows after "exolve-grid:"
    if "exolve-begin" in lower and "exolve-end" in lower:
        m = re.search(r"exolve-begin(.*?)exolve-end", text, flags=re.DOTALL | re.IGNORECASE)
        if m:
            block = m.group(1)
            title_m = re.search(r'^\s*exolve-title:\s*(.+)$', block, flags=re.MULTILINE | re.IGNORECASE)
            if title_m:
                title = title_m.group(1).strip()
            grid_m = re.search(r'^\s*exolve-grid:\s*(.*?)^\s*exolve-', block,
                               flags=re.DOTALL | re.MULTILINE | re.IGNORECASE)
            if grid_m:
                rows = []
                for line in grid_m.group(1).splitlines():
                    line = line.strip()
                    if re.fullmatch(r"[A-Za-z.#0-9]+", line):
                        rows.append(line.replace(".", "#").replace("0", "#").upper())
                if rows:
                    return {
                        "kind": "puzzle_full_grid",
                        "title": title,
                        "rows": rows,
                        "entries": sorted(set(extract_entries_from_rows(rows))),
                    }
    return None

def parse_csv_entries(path: Path) -> Iterable[str]:
    # clue-answer csv or plain word csv
    with path.open("r", encoding="utf-8", errors="ignore", newline="") as f:
        rdr = csv.reader(f)
        header = next(rdr, None)
        if not header:
            return []
        header_l = [h.strip().lower() for h in header]
        # try common answer columns
        ans_idx = None
        for key in ("answer", "answers", "entry", "entries", "solution"):
            if key in header_l:
                ans_idx = header_l.index(key)
                break
        if ans_idx is None:
            return []
        out = []
        for row in rdr:
            if ans_idx < len(row):
                e = norm_entry(row[ans_idx])
                if len(e.replace(" ", "")) >= 3:
                    out.append(e)
        return out

def parse_text_wordlist(path: Path) -> Iterable[str]:
    out = []
    with path.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            s = norm_entry(line.strip())
            if len(s.replace(" ", "")) >= 3:
                out.append(s)
    return out

def parse_json_file(path: Path) -> Optional[dict]:
    try:
        obj = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return None
    if isinstance(obj, dict):
        for parser in (parse_ipuz_like, parse_nyt_json_like):
            res = parser(obj)
            if res:
                return res
    return None

@dataclass
class HarvestStats:
    source_files: int = 0
    full_grids: int = 0
    entry_records: int = 0
    parse_failures: int = 0

def normalize_downloads(download_roots: List[Path], norm_dir: Path) -> HarvestStats:
    ensure_dir(norm_dir)
    full_grid_path = norm_dir / "full_grids.jsonl"
    entry_path = norm_dir / "entries.jsonl"
    catalog_path = norm_dir / "catalog.jsonl"
    entries_counter: Counter[str] = Counter()
    seen_grid_hashes = set()
    seen_records = set()
    stats = HarvestStats()

    fg = full_grid_path.open("w", encoding="utf-8")
    ep = entry_path.open("w", encoding="utf-8")
    cp = catalog_path.open("w", encoding="utf-8")

    def write_catalog(rec):
        cp.write(json.dumps(rec, ensure_ascii=False) + "\n")

    for root in download_roots:
        files = []
        if root.is_dir():
            files = [p for p in root.rglob("*") if p.is_file()]
        elif root.is_file():
            files = [root]
        for path in files:
            stats.source_files += 1
            suffix = path.suffix.lower()
            parsed = None
            try:
                if suffix == ".puz":
                    parsed = parse_puz(path)
                elif suffix in {".json", ".ipuz"}:
                    parsed = parse_json_file(path)
                elif suffix in {".html", ".htm", ".xd", ".txt"}:
                    text = path.read_text(encoding="utf-8", errors="ignore")
                    parsed = parse_exolve_html_or_xd_text(text)
                    if parsed is None and suffix == ".txt":
                        words = list(parse_text_wordlist(path))
                        if words:
                            rec = {
                                "kind": "wordlist",
                                "path": str(path),
                                "entries_count": len(words),
                            }
                            write_catalog(rec)
                            for w in words:
                                entries_counter[w] += 1
                                ep.write(json.dumps({"entry": w, "source_path": str(path)}, ensure_ascii=False) + "\n")
                            stats.entry_records += len(words)
                            continue
                elif suffix == ".csv":
                    words = list(parse_csv_entries(path))
                    if words:
                        rec = {
                            "kind": "clue_answer_csv",
                            "path": str(path),
                            "entries_count": len(words),
                        }
                        write_catalog(rec)
                        for w in words:
                            entries_counter[w] += 1
                            ep.write(json.dumps({"entry": w, "source_path": str(path)}, ensure_ascii=False) + "\n")
                        stats.entry_records += len(words)
                        continue
                elif suffix in {".zip"}:
                    continue
            except Exception:
                parsed = None

            if parsed is None:
                # maybe plain txt entries
                stats.parse_failures += 1
                continue

            if parsed["kind"] == "puzzle_full_grid":
                rows = parsed.get("rows") or []
                if not rows:
                    continue
                grid_hash = sha256_bytes("\n".join(rows).encode("utf-8"))
                if grid_hash in seen_grid_hashes:
                    continue
                seen_grid_hashes.add(grid_hash)
                out = dict(parsed)
                out["path"] = str(path)
                out["grid_hash"] = grid_hash
                fg.write(json.dumps(out, ensure_ascii=False) + "\n")
                stats.full_grids += 1
                write_catalog({
                    "kind": "puzzle_full_grid",
                    "path": str(path),
                    "title": parsed.get("title"),
                    "entries_count": len(parsed.get("entries", [])),
                })
                for w in parsed.get("entries", []):
                    entries_counter[w] += 1
                    ep.write(json.dumps({"entry": w, "source_path": str(path), "grid_hash": grid_hash}, ensure_ascii=False) + "\n")
                stats.entry_records += len(parsed.get("entries", []))
            else:
                entries = parsed.get("entries", [])
                if entries:
                    write_catalog({
                        "kind": parsed["kind"],
                        "path": str(path),
                        "title": parsed.get("title"),
                        "entries_count": len(entries),
                    })
                    for w in entries:
                        entries_counter[w] += 1
                        ep.write(json.dumps({"entry": w, "source_path": str(path)}, ensure_ascii=False) + "\n")
                    stats.entry_records += len(entries)

    fg.close(); ep.close(); cp.close()

    # write unique entries and frequencies
    entries_txt = norm_dir / "entries_unique.txt"
    entries_csv = norm_dir / "entry_frequency.csv"
    with entries_txt.open("w", encoding="utf-8") as f:
        for w in sorted(entries_counter):
            f.write(w + "\n")
    with entries_csv.open("w", encoding="utf-8", newline="") as f:
        wr = csv.writer(f)
        wr.writerow(["entry", "count"])
        for w, c in entries_counter.most_common():
            wr.writerow([w, c])

    summary = {
        "source_files": stats.source_files,
        "full_grids": stats.full_grids,
        "entry_records": stats.entry_records,
        "unique_entries": len(entries_counter),
        "parse_failures": stats.parse_failures,
        "puz_support": PUZ is not None,
    }
    (norm_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return stats

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", type=Path, default=None, help="Path to sources manifest JSON")
    ap.add_argument("--out", type=Path, required=True, help="Output root dir")
    ap.add_argument("--include-risky", action="store_true", help="Include sources marked mixed/unclear rights")
    ap.add_argument("--download-only", action="store_true")
    args = ap.parse_args()

    out_dir = args.out
    raw_dir = out_dir / "raw"
    norm_dir = out_dir / "normalized"
    ensure_dir(out_dir); ensure_dir(raw_dir)

    manifest = load_manifest(args.manifest, out_dir)

    download_roots: List[Path] = []
    for src in iter_enabled_sources(manifest, include_risky=args.include_risky):
        try:
            download_roots.extend(download_source(src, raw_dir))
        except HTTPError as e:
            log(f"[error] {src['id']}: HTTP {e.code}")
        except URLError as e:
            log(f"[error] {src['id']}: {e}")
        except Exception as e:
            log(f"[error] {src['id']}: {e}")

    if args.download_only:
        print(json.dumps({"download_roots": [str(p) for p in download_roots]}, indent=2))
        return

    stats = normalize_downloads(download_roots, norm_dir)
    print(json.dumps({
        "out": str(out_dir),
        "download_roots": [str(p) for p in download_roots],
        "summary_file": str(norm_dir / "summary.json"),
        "full_grids_file": str(norm_dir / "full_grids.jsonl"),
        "entries_file": str(norm_dir / "entries_unique.txt"),
        "entry_frequency_file": str(norm_dir / "entry_frequency.csv"),
        "puz_support": PUZ is not None,
        "stats": stats.__dict__,
    }, indent=2))

if __name__ == "__main__":
    main()
