#!/usr/bin/env python3
"""
cw_ai8_py_arena_v7.py — Crossword Arena v7 (G synthesis)

Intent:
  Keep the proven v6 closure spine, but expose a larger cross-domain sensor set
  so the arena can discover what actually helps on crossword search.

What v7 adds on top of v6:
  • TSP-style DCC delta on the partial-board description stream
  • TSP/NAS-style echo + resonance on crossing letters
  • Sudoku-style cascade depth / cascade power during ordering
  • TSP-style keystone / cluster / criticality refinements in slot choice
  • NAS-style flood & drain dynamic gating (relax when space is wide, tighten when flow is narrow)
  • Sudoku-style process metrics at trial level: process LZ + density-flow LZ
  • ADSR-ish dead-branch prune (zerorable; conservative by default)

Design rule unchanged:
  The exact CSP / AC-3 / MRV spine stays intact.
  Arena learns around it.
  If a new sensor is bad, CMA should be able to zero or invert it.
"""

import argparse, ast, concurrent.futures as cf, json, math, os, random, re
import signal, statistics, sys, time
from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from pathlib import Path

MASKS = {
    'dense9_a': [
        '......###', '......###', '.......##',
        '....#....', '...###...', '....#....',
        '##.......', '###......', '###......',
    ],
}

VOWELS = set('AEIOUY')
WEIRD = {'EEO', 'DPI', 'TRUG', 'INRI', 'EEOC', 'LII', 'TVA', 'OTB', 'ETA', 'PTA'}
MAX_PER_LEN = 4000
EPS = 1e-9

# Fixed solver weights — proven spine
SUPPORT_W = 3.0
MINSUP_W = 2.0
FORCED_W = 1.5
TOPN_EARLY = 80
TOPN_LATE = 120
TOPN_SWITCH = 10


def lz76c(s):
    if not s:
        return 0.0
    n = len(s)
    c = 0
    seen = set()
    i = 0
    while i < n:
        j = i + 1
        while j <= n and s[i:j] in seen:
            j += 1
        seen.add(s[i:j])
        c += 1
        i = j
    return c / max(1.0, n / max(1.0, math.log2(n + 1.0)))


def shannon(s):
    if not s:
        return 0.0
    cnt = Counter(s)
    n = len(s)
    return -sum((v / n) * math.log2(v / n + EPS) for v in cnt.values())


def log1p_clip(x: float, hi: float) -> float:
    return min(hi, math.log1p(max(0.0, x)))


def vowel_count(w: str) -> int:
    return sum(1 for ch in w.upper() if ch in VOWELS)


def acro_like_word(w: str, hinted: bool, score: float) -> bool:
    if hinted:
        return False
    ww = w.upper()
    v = vowel_count(ww)
    if len(ww) <= 3 and v == 0:
        return True
    if len(ww) == 4 and v <= 1 and score < 75:
        return True
    if len(ww) == 5 and v <= 1 and score < 70:
        return True
    return False


def mean_or_zero(xs):
    return sum(xs) / max(1, len(xs))


@dataclass
class QP:
    # staged gating
    core_depth: float = 5.0
    stage2_depth: float = 14.0
    core_min_score: float = 72.0
    bal_min_score: float = 40.0
    fd_relax: float = 4.0
    fd_tighten: float = 4.0

    # choose() cross-domain refinements
    choose_keystone: float = 0.8
    choose_cluster: float = 0.6
    choose_critical: float = 0.8
    choose_frozen: float = 0.6

    # order() cross-domain refinements
    w_dcc_delta: float = 1.2
    w_echo: float = 1.4
    w_resonance: float = 0.8
    w_cascade: float = 1.0
    w_cascade_power: float = 1.2

    # search control
    adsr_depth_start: float = 8.0
    adsr_window: float = 4.0
    adsr_flat_tol: float = 2.0

    # solved-board / trial quality
    q_ugly: float = 25.0
    q_hinted: float = 30.0
    q_avgscore: float = 3.0
    q_mdl: float = 8.0
    q_entropy: float = 4.0
    q_weird: float = 14.0
    q_acro_like: float = 10.0
    q_process_lz: float = 0.0
    q_density_flow: float = 0.0
    q_mean_cascade: float = 0.0
    q_mean_echo: float = 0.0


QP_BOUNDS = {
    # gating
    'core_depth':        (2.0, 8.0),
    'stage2_depth':      (8.0, 20.0),
    'core_min_score':    (55.0, 82.0),
    'bal_min_score':     (10.0, 55.0),
    'fd_relax':          (0.0, 18.0),
    'fd_tighten':        (0.0, 18.0),

    # choose
    'choose_keystone':   (-4.0, 4.0),
    'choose_cluster':    (-4.0, 4.0),
    'choose_critical':   (-4.0, 4.0),
    'choose_frozen':     (-4.0, 4.0),

    # order
    'w_dcc_delta':       (-12.0, 12.0),
    'w_echo':            (-12.0, 12.0),
    'w_resonance':       (-12.0, 12.0),
    'w_cascade':         (-12.0, 12.0),
    'w_cascade_power':   (-12.0, 12.0),

    # search control
    'adsr_depth_start':  (0.0, 20.0),
    'adsr_window':       (0.0, 8.0),
    'adsr_flat_tol':     (0.0, 12.0),

    # quality
    'q_ugly':            (5.0, 50.0),
    'q_hinted':          (5.0, 70.0),
    'q_avgscore':        (0.5, 10.0),
    'q_mdl':             (0.0, 25.0),
    'q_entropy':         (0.0, 15.0),
    'q_weird':           (0.0, 30.0),
    'q_acro_like':       (0.0, 25.0),
    'q_process_lz':      (-6.0, 6.0),
    'q_density_flow':    (-6.0, 6.0),
    'q_mean_cascade':    (-4.0, 4.0),
    'q_mean_echo':       (-4.0, 4.0),
}

QP_SEED = {k: getattr(QP(), k) for k in QP_BOUNDS}


class Solver:
    def __init__(self, source, qp=None, mask='dense9_a', budget=30.0, banned=None, seed=0):
        with open(source, 'r', encoding='utf-8') as f:
            data = json.load(f)
        self.lang = data.get('lang', 'en')
        self.bylen = {int(k): list(v) for k, v in data['words'].items()}
        for l, arr in self.bylen.items():
            arr.sort(key=lambda x: (-(x.get('s', 0)), -(1 if x.get('h') else 0), x['w']))
            if len(arr) > MAX_PER_LEN:
                self.bylen[l] = arr[:MAX_PER_LEN]
        self.wbl = {l: [x['w'] for x in arr] for l, arr in self.bylen.items()}
        self.mask_rows = MASKS[mask]
        self.R = len(self.mask_rows)
        self.C = len(self.mask_rows[0])
        self.slots = self._build_slots()
        self.nbrs = {s['id']: set(s2 for _, s2, _ in s['xr']) for s in self.slots}
        self.asets = {l: set(range(len(a))) for l, a in self.wbl.items()}
        self.ban = {w.upper() for w in (banned or set())}
        self.qp = qp or QP()
        self.budget = budget
        self.seed = seed

        # state
        self.t0 = 0.0
        self.nodes = 0
        self.sols = []
        self.best_d = 0
        self.best_p = None
        self.first_t = None
        self.rej = Counter()

        # trial-level process traces
        self.proc_tokens = []
        self.proc_domain_seq = []
        self.proc_cascade_seq = []
        self.proc_echo_seq = []

        self._precompute_structural_fields()
        self._precompute_letter_surprisal()

    def _build_slots(self):
        slots = []
        for o in 'AD':
            rows = range(self.R) if o == 'A' else range(self.C)
            for primary in rows:
                sec = 0
                limit = self.C if o == 'A' else self.R
                while sec < limit:
                    r, c = (primary, sec) if o == 'A' else (sec, primary)
                    if self.mask_rows[r][c] != '#' and (
                        sec == 0 or (self.mask_rows[r][c - 1] if o == 'A' else self.mask_rows[r - 1][c]) == '#'
                    ):
                        end = sec
                        while end < limit:
                            rr, cc = (primary, end) if o == 'A' else (end, primary)
                            if self.mask_rows[rr][cc] == '#':
                                break
                            end += 1
                        if end - sec >= 3:
                            cells = [(primary, j) for j in range(sec, end)] if o == 'A' else [(j, primary) for j in range(sec, end)]
                            slots.append({'id': len(slots), 'o': o, 'cells': cells, 'len': end - sec})
                        sec = end
                    else:
                        sec += 1
        cm = defaultdict(list)
        for s in slots:
            for p, cell in enumerate(s['cells']):
                cm[cell].append((s['id'], p))
        for s in slots:
            s['xr'] = [(p, s2, p2) for p, cell in enumerate(s['cells']) for s2, p2 in cm[cell] if s2 != s['id']]
        return slots

    def _precompute_structural_fields(self):
        deg = {}
        critical = {}
        keystone = {}
        for s in self.slots:
            sid = s['id']
            partners = list(self.nbrs[sid])
            deg[sid] = len(partners)
            critical[sid] = sum(self.slots[s2]['len'] for s2 in partners)
            keystone[sid] = sum(self.slots[s2]['len'] for _, s2, _ in s['xr'])
        cluster = {}
        for s in self.slots:
            sid = s['id']
            cluster[sid] = deg[sid] + sum(deg[s2] for s2 in self.nbrs[sid])

        def norm_map(d):
            mx = max(d.values()) if d else 1.0
            return {k: (v / mx if mx > 0 else 0.0) for k, v in d.items()}

        self.slot_degree = deg
        self.slot_criticality = norm_map(critical)
        self.slot_keystone = norm_map(keystone)
        self.slot_cluster = norm_map(cluster)

    def _precompute_letter_surprisal(self):
        self.char_surprisal = {}
        for ln, arr in self.bylen.items():
            if not arr:
                continue
            for pos in range(ln):
                cnt = Counter(x['w'][pos] for x in arr)
                total = sum(cnt.values())
                for ch, v in cnt.items():
                    p = (v + 1.0) / (total + 26.0)
                    self.char_surprisal[(ln, pos, ch)] = -math.log(p + EPS)

    def _partial_sig(self, asgn):
        if not asgn:
            return ''
        toks = []
        for sid, idx in sorted(asgn.items()):
            toks.append(f'{sid}:{self.wbl[self.slots[sid]["len"]][idx]}')
        return '|'.join(toks)

    def _domain_mass(self, dom, asgn):
        return sum(len(dom[s['id']]) for s in self.slots if s['id'] not in asgn)

    def _flow_adjust(self, avg_dom):
        # flood & drain: if domains are wide -> relax thresholds; if narrow -> tighten
        relax = 0.0
        tighten = 0.0
        if avg_dom > 8.0:
            relax = self.qp.fd_relax * min(1.0, (avg_dom - 8.0) / 8.0)
        elif avg_dom < 3.0:
            tighten = self.qp.fd_tighten * min(1.0, (3.0 - avg_dom) / 3.0)
        return relax, tighten

    def _gate(self, meta, depth, avg_dom):
        w = meta['w']
        if w in self.ban:
            return False
        s = meta.get('s', 0)
        has_hint = bool(meta.get('h'))
        cd = int(round(self.qp.core_depth))
        s2d = int(round(max(self.qp.stage2_depth, cd + 1)))
        relax, tighten = self._flow_adjust(avg_dom)
        core_min = self.qp.core_min_score - relax + tighten
        bal_min = self.qp.bal_min_score - 0.8 * relax + 0.8 * tighten

        if depth < cd:
            if s < core_min:
                return False
            if len(w) <= 4 and not has_hint:
                return False
            return True
        elif depth < s2d:
            return s >= bal_min
        return True

    # AC-3 core (fixed)
    def _cd(self, slot, dom, asgn, used):
        sid = slot['id']
        if sid in asgn:
            return {asgn[sid]}
        arr = self.wbl[slot['len']]
        out = set()
        for idx in dom[sid]:
            w = arr[idx]
            if w in used or w in self.ban:
                continue
            ok = True
            for p, s2, p2 in slot['xr']:
                if s2 in asgn:
                    if w[p] != self.wbl[self.slots[s2]['len']][asgn[s2]][p2]:
                        ok = False
                        break
            if ok:
                out.add(idx)
        return out

    def _revise(self, dom, xi, xj, used, asgn):
        xrs = [(pi, pj) for pi, s2, pj in self.slots[xi]['xr'] if s2 == xj]
        if not xrs:
            return False
        di = self._cd(self.slots[xi], dom, asgn, used)
        dj = self._cd(self.slots[xj], dom, asgn, used)
        if not di or not dj:
            dom[xi] = set()
            return True
        ai = self.wbl[self.slots[xi]['len']]
        aj = self.wbl[self.slots[xj]['len']]
        sup = [(pi, set(aj[j][pj] for j in dj)) for pi, pj in xrs]
        rem = {i for i in di if any(ai[i][pi] not in lts for pi, lts in sup)}
        if rem:
            dom[xi] = di - rem
            return True
        return False

    def _ac3(self, dom, used, asgn):
        q = deque((s['id'], s2) for s in self.slots for _, s2, _ in s['xr'])
        while q:
            xi, xj = q.popleft()
            if self._revise(dom, xi, xj, used, asgn):
                if not dom[xi]:
                    return False
                for _, xk, _ in self.slots[xi]['xr']:
                    if xk != xj:
                        q.append((xk, xi))
        return True

    def _choose(self, dom, asgn, used):
        best_sid, best_key = None, None
        for slot in self.slots:
            sid = slot['id']
            if sid in asgn:
                continue
            d = self._cd(slot, dom, asgn, used)
            dom[sid] = d
            filled = sum(1 for _, s2, _ in slot['xr'] if s2 in asgn)
            frozen_n = 0
            for _, s2, _ in slot['xr']:
                if s2 in asgn:
                    continue
                d2 = self._cd(self.slots[s2], dom, asgn, used)
                if len(d2) <= 1:
                    frozen_n += 1
            refine = filled
            refine += self.qp.choose_keystone * self.slot_keystone[sid]
            refine += self.qp.choose_cluster * self.slot_cluster[sid]
            refine += self.qp.choose_critical * self.slot_criticality[sid]
            refine += self.qp.choose_frozen * frozen_n
            key = (len(d), -refine, -slot['len'])
            if best_key is None or key < best_key:
                best_key = key
                best_sid = sid
        return best_sid

    def _adsr_prune(self, path_masses, depth):
        w = int(round(self.qp.adsr_window))
        start = int(round(self.qp.adsr_depth_start))
        tol = self.qp.adsr_flat_tol
        if w < 2 or tol <= 0 or depth < start or len(path_masses) < w:
            return False
        tail = path_masses[-w:]
        return (max(tail) - min(tail)) <= tol

    def _order(self, sid, dom, asgn, used):
        slot = self.slots[sid]
        depth = len(asgn)
        d = self._cd(slot, dom, asgn, used)
        unresolved = [s['id'] for s in self.slots if s['id'] not in asgn]
        avg_dom = sum(len(dom[x]) for x in unresolved) / max(1, len(unresolved))
        base_sig = self._partial_sig(asgn)
        base_lz = lz76c(base_sig) if base_sig else 0.0

        # Precompute open crossing domains for echo/cascade/resonance
        open_cons = []
        for p, s2, p2 in slot['xr']:
            if s2 in asgn:
                continue
            d2 = self._cd(self.slots[s2], dom, asgn, used)
            prev = len(d2)
            arr2_meta = self.bylen[self.slots[s2]['len']]
            count = Counter()
            for j in d2:
                ch = self.wbl[self.slots[s2]['len']][j][p2]
                count[ch] += 1
            open_cons.append((p, s2, p2, prev, count))

        scored = []
        for idx in d:
            meta = self.bylen[slot['len']][idx]
            if not self._gate(meta, depth, avg_dom):
                self.rej['gated'] += 1
                continue
            w = meta['w']

            # fixed lexical base from v6
            val = meta.get('s', 0) + (14 if meta.get('h') else 0)
            val += 4.0 * len(set(w)) / len(w)
            if not meta.get('h'):
                val -= 18
            if len(w) <= 4 and sum(c in VOWELS for c in w) <= 1:
                val -= 12
            if re.search(r'(.)\1\1', w):
                val -= 8
            if len(set(w)) <= 2:
                val -= 8
            if w in WEIRD or w in self.ban:
                val -= 22

            minsup, total, zero = 999999, 0, False
            echo_gain = 0.0
            cascade_depth = 0.0
            cascade_power = 0.0
            resonance = 0.0

            for p, s2, p2, prev, count in open_cons:
                cnt = count.get(w[p], 0)
                if cnt == 0:
                    zero = True
                    break
                total += cnt
                minsup = min(minsup, cnt)
                if prev > 0:
                    red = math.log(prev + 1.0) - math.log(cnt + 1.0)
                    echo_gain += red
                    if cnt <= 2:
                        cascade_depth += (3 - cnt) / 2.0  # 1.0 if singleton, 0.5 if two left
                    cascade_power += red * (1.0 + 0.25 * max(0, prev - cnt))
                resonance += self.char_surprisal.get((self.slots[s2]['len'], p2, w[p]), 0.0)

            if zero:
                self.rej['zero_sup'] += 1
                continue

            val += SUPPORT_W * math.log(total + 1) + MINSUP_W * math.log(minsup + 1)

            # cross-domain extras (zerorable / invertible)
            dcc_delta = 0.0
            if abs(self.qp.w_dcc_delta) > EPS:
                new_sig = f'{base_sig}|{sid}:{w}' if base_sig else f'{sid}:{w}'
                dcc_delta = base_lz - lz76c(new_sig)
                val += self.qp.w_dcc_delta * dcc_delta
            if open_cons:
                val += self.qp.w_echo * (echo_gain / len(open_cons))
                val += self.qp.w_resonance * (resonance / len(open_cons))
                val += self.qp.w_cascade * cascade_depth
                val += self.qp.w_cascade_power * cascade_power

            scored.append((val, idx, {
                'dcc_delta': dcc_delta,
                'echo_gain': echo_gain,
                'cascade_depth': cascade_depth,
                'cascade_power': cascade_power,
                'resonance': resonance,
            }))

        scored.sort(key=lambda t: t[0], reverse=True)
        topn = TOPN_EARLY if depth < TOPN_SWITCH else TOPN_LATE
        return [(idx, feat) for _, idx, feat in scored[:topn]]

    def _search(self, dom, asgn, used, path_masses=None):
        self.nodes += 1
        path_masses = list(path_masses or [])
        mass = self._domain_mass(dom, asgn)
        path_masses.append(mass)
        self.proc_domain_seq.append(mass)

        if len(asgn) > self.best_d:
            self.best_d = len(asgn)
            self.best_p = dict(asgn)

        if len(asgn) == len(self.slots):
            self.sols.append(dict(asgn))
            if self.first_t is None:
                self.first_t = time.time() - self.t0
            return False

        if time.time() - self.t0 > self.budget:
            return True

        if self._adsr_prune(path_masses, len(asgn)):
            self.rej['adsr_prune'] += 1
            return False

        sid = self._choose(dom, asgn, used)
        if sid is None or not dom[sid]:
            return False

        ordered = self._order(sid, dom, asgn, used)
        if not ordered:
            return False

        for idx, feat in ordered:
            w = self.wbl[self.slots[sid]['len']][idx]
            if w in used:
                continue
            self.proc_tokens.append(f'{sid}:{w}')
            self.proc_echo_seq.append(feat['echo_gain'])
            self.proc_cascade_seq.append(feat['cascade_power'])

            d2 = {k: set(v) for k, v in dom.items()}
            a2 = dict(asgn)
            u2 = set(used)
            a2[sid] = idx
            u2.add(w)
            d2[sid] = {idx}
            ok = True
            for p, s2, p2 in self.slots[sid]['xr']:
                if s2 in a2:
                    continue
                arr2 = self.wbl[self.slots[s2]['len']]
                nd = {j for j in self._cd(self.slots[s2], d2, a2, u2) if arr2[j][p2] == w[p]}
                d2[s2] = nd
                if not nd:
                    ok = False
                    break
            if not ok:
                continue
            if not self._ac3(d2, u2, a2):
                continue
            if self._search(d2, a2, u2, path_masses):
                return True
        return False

    def board(self, asgn):
        b = [list(r) for r in self.mask_rows]
        for sid, idx in asgn.items():
            sl = self.slots[sid]
            w = self.wbl[sl['len']][idx]
            for (r, c), ch in zip(sl['cells'], w):
                b[r][c] = ch
        return [''.join(r) for r in b]

    def words(self, asgn):
        out = []
        for sid, idx in sorted(asgn.items()):
            m = self.bylen[self.slots[sid]['len']][idx]
            out.append({
                'sid': sid,
                'o': self.slots[sid]['o'],
                'len': self.slots[sid]['len'],
                'w': m['w'],
                'h': m.get('h', ''),
                's': m.get('s', 0),
            })
        return out

    def signals(self, asgn):
        brd = self.board(asgn)
        rows_s = '|'.join(''.join(c for c in row if c != '#') for row in brd)
        cols_s = '|'.join(''.join(brd[r][c] for r in range(self.R) if brd[r][c] != '#') for c in range(self.C))
        letters = ''.join(c for row in brd for c in row if c not in '.#')
        filled = sum(1 for _ in letters)
        total = sum(1 for row in brd for c in row if c != '#')
        proc_tok_str = '|'.join(self.proc_tokens)
        proc_dom_str = ','.join(str(int(x)) for x in self.proc_domain_seq)
        process_lz = round(lz76c(proc_tok_str), 4) if proc_tok_str else 0.0
        density_flow = round(lz76c(proc_dom_str), 4) if proc_dom_str else 0.0
        mean_cascade_power = round(mean_or_zero(self.proc_cascade_seq), 4)
        mean_echo_gain = round(mean_or_zero(self.proc_echo_seq), 4)
        return {
            'sol_mdl': round(lz76c(rows_s + '||' + cols_s), 4),
            'cross_entropy': round(shannon(letters), 4),
            'fill_ratio': round(filled / max(1, total), 4),
            'process_lz': process_lz,
            'density_flow': density_flow,
            'mean_cascade_power': mean_cascade_power,
            'mean_echo_gain': mean_echo_gain,
            'mean_cascade_log': round(log1p_clip(mean_cascade_power, 8.0), 4),
            'mean_echo_log': round(log1p_clip(mean_echo_gain, 4.0), 4),
        }

    def quality(self, asgn):
        ws = self.words(asgn)
        p = self.qp
        hinted = sum(1 for w in ws if w['h'])
        avg_s = sum(w['s'] for w in ws) / max(1, len(ws))
        ugly = sum(1 for w in ws if w['s'] < 65 and not w['h'])
        weird_n = sum(1 for w in ws if w['w'] in WEIRD)
        acro_like_n = sum(1 for w in ws if acro_like_word(w['w'], bool(w['h']), float(w['s'])))
        sig = self.signals(asgn)
        return (
            - p.q_ugly * ugly
            + p.q_hinted * (hinted / max(1, len(ws)))
            + p.q_avgscore * (avg_s / 100.0)
            - p.q_mdl * sig['sol_mdl']
            - p.q_entropy * sig['cross_entropy']
            - p.q_weird * weird_n
            - p.q_acro_like * acro_like_n
            - p.q_process_lz * min(sig['process_lz'], 8.0)
            - p.q_density_flow * min(sig['density_flow'], 8.0)
            + p.q_mean_cascade * sig['mean_cascade_log']
            + p.q_mean_echo * sig['mean_echo_log']
        )

    def run(self):
        dom = {s['id']: set(self.asets[s['len']]) for s in self.slots}
        if not self._ac3(dom, set(), {}):
            return {'solved': False, 'error': 'AC-3 init fail'}
        self.t0 = time.time()
        self._search(dom, {}, set(), [])
        solved = len(self.sols) > 0
        best_a, best_q = None, -1e18
        for a in self.sols:
            q = self.quality(a)
            if q > best_q:
                best_q = q
                best_a = a
        if not solved:
            best_a = self.best_p or {}
        return {
            'solved': solved,
            'num_solutions': len(self.sols),
            'seconds': round(time.time() - self.t0, 3),
            'nodes': self.nodes,
            'best_partial_depth': self.best_d,
            'first_solved_at': round(self.first_t, 3) if self.first_t else None,
            'quality': round(best_q, 4) if solved else None,
            'board': self.board(best_a),
            'words': self.words(best_a),
            'signals': self.signals(best_a),
            'rejections': dict(self.rej),
        }


def clamp(k, v):
    lo, hi = QP_BOUNDS[k]
    return max(lo, min(hi, float(v)))


def sample_qp(mean, sigma, rng):
    vals = {k: clamp(k, rng.gauss(mean[k], max(EPS, sigma[k]))) for k in QP_BOUNDS}
    vals['stage2_depth'] = max(vals['stage2_depth'], vals['core_depth'] + 1)
    return QP(**vals)


def elite_update(elites, mean, sigma, frac=0.35):
    nm, ns = {}, {}
    for k in QP_BOUNDS:
        vals = [e['params'][k] for e in elites]
        m = statistics.fmean(vals)
        s = statistics.pstdev(vals) if len(vals) > 1 else sigma[k] * 0.9
        span = QP_BOUNDS[k][1] - QP_BOUNDS[k][0]
        nm[k] = (1 - frac) * mean[k] + frac * m
        ns[k] = max(span * 0.03, (1 - frac) * sigma[k] + frac * max(s, span * 0.05))
    return nm, ns


def run_trial(job):
    qp = QP(**{k: job['params'][k] for k in QP_BOUNDS})
    s = Solver(job['source'], qp=qp, mask=job['mask'], budget=job['budget'], banned=set(job.get('banned', [])), seed=job['seed'])
    r = s.run()
    return {'trial_id': job['trial_id'], 'gen': job['gen'], 'seed': job['seed'], 'params': job['params'], **r}


def save_json(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(str(path) + '.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def append_jsonl(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'a', encoding='utf-8') as f:
        f.write(json.dumps(obj, ensure_ascii=False) + '\n')


def board_signature(result):
    if result.get('solved'):
        return tuple(result.get('board', []))
    return None


def select_elites(results, elite_n, diverse=True):
    solved = [r for r in results if r.get('solved')]
    if not solved or elite_n <= 0:
        return []
    solved.sort(key=lambda r: (r.get('quality') or -1e18), reverse=True)
    if not diverse:
        return solved[:elite_n]
    picked, seen = [], set()
    for r in solved:
        sig = board_signature(r)
        if sig in seen:
            continue
        picked.append(r)
        seen.add(sig)
        if len(picked) >= elite_n:
            return picked
    for r in solved:
        if len(picked) >= elite_n:
            break
        if r not in picked:
            picked.append(r)
    return picked


def main():
    ap = argparse.ArgumentParser(description='Crossword Arena v7 — cross-domain sensor overbuild on the proven v6 closure spine')
    ap.add_argument('--source', required=True)
    ap.add_argument('--mask', default='dense9_a', choices=sorted(MASKS))
    ap.add_argument('--outdir', required=True)
    ap.add_argument('--hours', type=float, default=1.0)
    ap.add_argument('--budget', '--quality-seconds', dest='budget', type=float, default=30.0)
    ap.add_argument('--population', type=int, default=12)
    ap.add_argument('--elite', type=int, default=4)
    ap.add_argument('--workers', type=int, default=1)
    ap.add_argument('--elite-diversity', dest='elite_diversity', action='store_true')
    ap.add_argument('--no-diversity', dest='elite_diversity', action='store_false')
    ap.set_defaults(elite_diversity=True)
    ap.add_argument('--ban-words', default='')
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--fresh', action='store_true')
    args = ap.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    sp = outdir / 'arena_state.json'
    lb = outdir / 'leaderboard.jsonl'
    lock_path = outdir / 'arena.lock'

    banned = sorted({w.strip().upper() for w in args.ban_words.split(',') if w.strip()})
    rng = random.Random(args.seed)

    save_json(outdir / 'run_manifest.json', {
        'engine': 'cw_ai8_py_arena_v7',
        'source': args.source, 'mask': args.mask,
        'hours': args.hours, 'budget': args.budget,
        'population': args.population, 'elite': args.elite,
        'workers': args.workers, 'seed': args.seed,
        'elite_diversity': args.elite_diversity,
        'banned_words': banned,
        'created_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    })

    if lock_path.exists():
        raise SystemExit(f'Lock exists: {lock_path} — another run active?')
    save_json(lock_path, {'pid': os.getpid(), 'started': time.strftime('%Y-%m-%d %H:%M:%S')})

    interrupted = {'flag': False}
    def _sigint(signum, frame):
        interrupted['flag'] = True
        print('\n[arena_v7] Ctrl+C — will checkpoint after current generation...')
    old_handler = signal.signal(signal.SIGINT, _sigint)

    try:
        state = None if args.fresh else (json.load(open(sp)) if sp.exists() else None)
        if state:
            mean, sigma = state['mean'], state['sigma']
            gen0, tc = state['next_gen'], state.get('tc', 0)
            best = state.get('best')
            rng.setstate(ast.literal_eval(state['rng_state']))
            print(f'[arena_v7] resume gen={gen0} trials={tc}')
        else:
            mean = {k: float(QP_SEED[k]) for k in QP_BOUNDS}
            sigma = {k: (QP_BOUNDS[k][1] - QP_BOUNDS[k][0]) * 0.15 for k in QP_BOUNDS}
            gen0, tc, best = 0, 0, None
            print('[arena_v7] fresh start')

        deadline = time.time() + args.hours * 3600
        t_start = time.time()
        all_unique = set()

        print(f'[arena_v7] source={args.source} mask={args.mask} hours={args.hours}')
        print(f'[arena_v7] budget={args.budget}s pop={args.population} workers={args.workers}')
        print(f'[arena_v7] elite_diversity={args.elite_diversity}')
        print('[arena_v7] fixed spine: AC-3 + MRV + support 3.0/2.0/1.5 + core short-unhint ban')
        print(f'[arena_v7] tunable cross-domain layer: {len(QP_BOUNDS)} params')
        print('[arena_v7] domains imported: TSP (dcc/echo/resonance/keystone), NAS (flood-drain), Sudoku (cascade/process)\n')

        while time.time() < deadline and not interrupted['flag']:
            jobs = []
            for i in range(args.population):
                qp = sample_qp(mean, sigma, rng)
                jobs.append({
                    'trial_id': tc + i, 'gen': gen0,
                    'seed': rng.randint(0, 2**31 - 1),
                    'source': args.source, 'mask': args.mask,
                    'budget': args.budget, 'banned': banned,
                    'params': {k: getattr(qp, k) for k in QP_BOUNDS},
                })
            tc += len(jobs)

            if args.workers <= 1:
                results = [run_trial(j) for j in jobs]
            else:
                with cf.ProcessPoolExecutor(max_workers=args.workers) as ex:
                    results = list(ex.map(run_trial, jobs))

            results.sort(key=lambda r: (1 if r['solved'] else 0, r.get('quality') or -1e9, r['best_partial_depth']), reverse=True)

            for r in results:
                if r['solved']:
                    all_unique.add(tuple(r['board']))

            for r in results:
                append_jsonl(lb, {k: r[k] for k in (
                    'trial_id', 'gen', 'seed', 'solved', 'num_solutions', 'nodes', 'seconds',
                    'quality', 'best_partial_depth', 'signals', 'board', 'words', 'params', 'rejections'
                )})
                if best is None or \
                   (r['solved'] and not best.get('solved')) or \
                   (r['solved'] == best.get('solved') and (r.get('quality') or -1e9) > (best.get('quality') or -1e9)):
                    best = r
                    save_json(outdir / 'best_result.json', r)

            elites = [{'params': r['params'], 'score': r.get('quality', 0)}
                      for r in select_elites(results, args.elite, diverse=args.elite_diversity) if r['solved']]
            if elites:
                mean, sigma = elite_update(elites, mean, sigma)

            save_json(sp, {
                'next_gen': gen0 + 1,
                'mean': mean,
                'sigma': sigma,
                'best': best,
                'tc': tc,
                'rng_state': repr(rng.getstate()),
            })

            top = results[0]
            solved_n = sum(1 for r in results if r['solved'])
            total_sols = sum(r.get('num_solutions', 0) for r in results)
            elapsed = (time.time() - t_start) / 60
            print(
                f'[gen {gen0:>3}] {solved_n}/{len(results)} solved ({total_sols} boards)  '
                f'q={str(top.get("quality") or "—"):>8}  '
                f'mdl={top["signals"]["sol_mdl"]:.3f}  '
                f'proc={top["signals"].get("process_lz", 0.0):.3f}  '
                f'density={top["signals"].get("density_flow", 0.0):.3f}  '
                f'depth={top["best_partial_depth"]}  '
                f'uniq={len(all_unique)}  '
                f'{elapsed:.1f}min'
            )

            gen0 += 1

        print(f'\n{"=" * 70}')
        reason = 'interrupted' if interrupted['flag'] else 'deadline'
        print(f'[arena_v7] Done ({reason}). {gen0} gens, {tc} trials, {(time.time() - t_start) / 60:.1f} min')
        print(f'[arena_v7] Unique boards found: {len(all_unique)}')
        if best:
            print(f'Best: solved={best["solved"]} quality={best.get("quality")}')
            print(f'      solutions={best.get("num_solutions", 0)} nodes={best["nodes"]}')
            print()
            for row in best['board']:
                print(f'  {row}')
            ws = best['words']
            hinted = [w for w in ws if w['h']]
            unhinted = [w for w in ws if not w['h']]
            print(f'\n  Words: {len(ws)} ({len(hinted)} hinted, {len(unhinted)} unhinted)')
            for w in ws:
                mark = '✓' if w['h'] else '·'
                print(f'    {mark} {w["w"]:12s} (s={w["s"]:>2})  {w["h"][:45]}')
            sig = best['signals']
            print(
                f'\n  MDL: {sig["sol_mdl"]:.3f}  entropy: {sig["cross_entropy"]:.3f}  '
                f'procLZ: {sig.get("process_lz", 0.0):.3f}  density: {sig.get("density_flow", 0.0):.3f}  '
                f'cascade: {sig.get("mean_cascade_power", 0.0):.3f}  echo: {sig.get("mean_echo_gain", 0.0):.3f}'
            )

    finally:
        signal.signal(signal.SIGINT, old_handler)
        try:
            lock_path.unlink(missing_ok=True)
        except OSError:
            pass


if __name__ == '__main__':
    main()
