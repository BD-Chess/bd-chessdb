'use strict';

const fs = require('fs');
const path = require('path');

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function writeJson(filePath, obj) {
  ensureDir(path.dirname(filePath));
  fs.writeFileSync(filePath, JSON.stringify(obj, null, 2), 'utf8');
}

function csvEscape(v) {
  const s = String(v ?? '');
  if (/[",\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
  return s;
}

function writeCsv(filePath, rows) {
  if (!rows || !rows.length) {
    ensureDir(path.dirname(filePath));
    fs.writeFileSync(filePath, '', 'utf8');
    return;
  }
  const cols = Array.from(rows.reduce((set, row) => {
    Object.keys(row).forEach(k => set.add(k));
    return set;
  }, new Set()));
  const lines = [cols.join(',')];
  for (const row of rows) {
    lines.push(cols.map(c => csvEscape(row[c])).join(','));
  }
  ensureDir(path.dirname(filePath));
  fs.writeFileSync(filePath, lines.join('\n'), 'utf8');
}

function stampName(prefix, ext = '.json') {
  const d = new Date();
  const stamp = d.toISOString().replace(/[:.]/g, '-');
  return `${prefix}_${stamp}${ext}`;
}

module.exports = {
  ensureDir,
  writeJson,
  writeCsv,
  stampName,
};
