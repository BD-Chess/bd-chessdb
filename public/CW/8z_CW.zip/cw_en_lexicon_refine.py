#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable

WORD_RE = re.compile(r'^[A-Z]{3,15}$')
VOWELS = set('AEIOUY')
COMMON_ENDINGS = (
    'ING', 'ION', 'ERS', 'EST', 'ATE', 'ED', 'ER', 'AL', 'LY', 'NESS', 'MENT', 'TION', 'SION', 'ABLE'
)
UGLY_PATTERNS = (
    'QJ', 'JQ', 'QZ', 'ZX', 'XQ', 'JX', 'WX', 'VV', 'JJ', 'QQ', 'ZX', 'QY', 'YYY'
)
DEFAULT_BANLIST = {
    'SETT', 'SHAD', 'ETUI', 'OLEO', 'OLIO', 'OAST', 'EPEE', 'SLAG', 'HEDGER', 'YETI', 'INRI', 'ETA'
}


def normalize_entry(word: str, compact_phrases: bool = False) -> str:
    word = (word or '').upper().strip()
    if compact_phrases:
        word = re.sub(r'[^A-Z]', '', word)
    else:
        if re.search(r'[^A-Z]', word):
            return ''
    return word


def letter_diversity(word: str) -> float:
    return len(set(word)) / len(word)


def vowel_ratio(word: str) -> float:
    return sum(1 for ch in word if ch in VOWELS) / len(word)


def ugly_penalty(word: str) -> float:
    p = 0.0
    if word in DEFAULT_BANLIST:
        p += 25.0
    if any(x in word for x in UGLY_PATTERNS):
        p += 20.0
    if len(set(word)) <= max(2, len(word) // 3):
        p += 8.0
    vr = vowel_ratio(word)
    if vr < 0.18 or vr > 0.75:
        p += 6.0
    if word.endswith('S') and len(word) <= 4:
        p += 4.0
    return p


def lexical_bonus(word: str) -> float:
    b = 0.0
    if 0.35 <= vowel_ratio(word) <= 0.6:
        b += 5.0
    b += 8.0 * letter_diversity(word)
    if any(word.endswith(suf) for suf in COMMON_ENDINGS):
        b += 2.0
    return b


def load_base(base_path: Path) -> dict:
    with base_path.open('r', encoding='utf-8') as f:
        data = json.load(f)
    if not isinstance(data, dict) or 'words' not in data:
        raise ValueError('Expected base lexicon schema {lang, source, words}')
    return data


def iter_corpus_frequency_rows(paths: list[Path]) -> Iterable[tuple[str, int]]:
    for p in paths:
        with p.open('r', encoding='utf-8', newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    yield row.get('entry', ''), int(float(row.get('count', '1') or '1'))
                except Exception:
                    continue


def collect_corpus_paths(root: Path) -> list[Path]:
    out = []
    if root.is_file() and root.name == 'entry_frequency.csv':
        out.append(root)
    elif root.is_dir():
        out.extend(root.rglob('entry_frequency.csv'))
    return list(dict.fromkeys(out))


def score_candidate(word: str, corpus_count: int, source_count: int, base_score: int | None) -> int:
    base = base_score if base_score is not None else 64
    boost = 0.0
    boost += min(10.0, 2.5 * math.log2(1 + corpus_count))
    boost += min(8.0, 2.0 * math.log2(1 + source_count))
    score = base * 0.72 + 12.0 + boost + lexical_bonus(word) - ugly_penalty(word)
    score = round(max(35, min(95, score)))
    return int(score)


def main() -> None:
    ap = argparse.ArgumentParser(description='Refine cw_en_scored.json using crossword corpus frequencies.')
    ap.add_argument('--base', default='cw_en_scored.json')
    ap.add_argument('--roots', nargs='*', default=['cw_corpus', 'cw_corpus_v2'])
    ap.add_argument('--out', default='out/cw_en_scored_v2.json')
    ap.add_argument('--report', default='out/cw_en_scored_v2_report.json')
    ap.add_argument('--compact-phrases', action='store_true', help='Remove spaces/hyphens and keep phrase entries as single fill strings')
    ap.add_argument('--min-add-count', type=int, default=2)
    ap.add_argument('--min-add-score', type=int, default=72)
    ap.add_argument('--drop-bad-existing', action='store_true')
    ap.add_argument('--drop-threshold', type=int, default=52)
    args = ap.parse_args()

    base_path = Path(args.base)
    out_path = Path(args.out)
    report_path = Path(args.report)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)

    data = load_base(base_path)
    words_by_len = data['words']

    freq_paths = []
    for root_str in args.roots:
        freq_paths.extend(collect_corpus_paths(Path(root_str)))
    freq_paths = list(dict.fromkeys(freq_paths))
    if not freq_paths:
        raise SystemExit('No entry_frequency.csv files found in the provided roots.')

    corpus_freq: Counter[str] = Counter()
    source_hits: defaultdict[str, set[str]] = defaultdict(set)
    for p in freq_paths:
        with p.open('r', encoding='utf-8', newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                raw = row.get('entry', '')
                word = normalize_entry(raw, compact_phrases=args.compact_phrases)
                if not WORD_RE.match(word):
                    continue
                cnt = int(float(row.get('count', '1') or '1'))
                corpus_freq[word] += cnt
                source_hits[word].add(str(p))

    # Flatten base
    base_map: dict[str, dict] = {}
    base_buckets: dict[int, list[dict]] = defaultdict(list)
    for L_str, bucket in words_by_len.items():
        for e in bucket:
            w = normalize_entry(e.get('w', ''), compact_phrases=False)
            if not WORD_RE.match(w):
                continue
            entry = {'w': w, 'h': e.get('h', ''), 's': int(e.get('s', 60)), 't': int(e.get('t', 1))}
            base_map[w] = entry
            base_buckets[len(w)].append(entry)

    added = []
    boosted = []
    penalized = []
    dropped = []

    # Re-score existing
    new_buckets: dict[int, list[dict]] = defaultdict(list)
    for word, entry in base_map.items():
        count = corpus_freq.get(word, 0)
        src_ct = len(source_hits.get(word, set()))
        old_score = int(entry.get('s', 60))
        new_score = score_candidate(word, count, src_ct, old_score)
        # explicit penalty if corpus never saw it and it looks ugly
        if count == 0:
            new_score = max(35, new_score - 6)
        if word in DEFAULT_BANLIST:
            new_score = max(35, new_score - 12)
        new_entry = {'w': word, 'h': entry.get('h', ''), 's': int(new_score), 't': int(entry.get('t', 1))}
        if args.drop_bad_existing and count == 0 and new_score < args.drop_threshold:
            dropped.append({'w': word, 'old_s': old_score, 'new_s': new_score, 'reason': 'no corpus support + low rescored value'})
            continue
        new_buckets[len(word)].append(new_entry)
        if new_score >= old_score + 4:
            boosted.append({'w': word, 'old_s': old_score, 'new_s': new_score, 'count': count})
        elif new_score <= old_score - 4:
            penalized.append({'w': word, 'old_s': old_score, 'new_s': new_score, 'count': count})

    # Add new entries from corpus
    for word, count in corpus_freq.items():
        if word in base_map:
            continue
        src_ct = len(source_hits.get(word, set()))
        score = score_candidate(word, count, src_ct, None)
        if count < args.min_add_count or score < args.min_add_score:
            continue
        entry = {'w': word, 'h': '', 's': int(score), 't': 1}
        new_buckets[len(word)].append(entry)
        added.append({'w': word, 's': score, 'count': count, 'source_paths': src_ct})

    # sort and emit same schema
    out_words = {}
    for L in range(3, 16):
        bucket = new_buckets.get(L, [])
        bucket.sort(key=lambda e: (-int(e.get('s', 0)), e['w']))
        out_words[str(L)] = bucket

    out_data = {
        'lang': data.get('lang', 'en'),
        'source': str(data.get('source', 'scored+optimized')) + '+corpus_refined',
        'words': out_words,
    }
    with out_path.open('w', encoding='utf-8') as f:
        json.dump(out_data, f, ensure_ascii=False, indent=2)

    report = {
        'base': str(base_path),
        'roots': args.roots,
        'frequency_files': [str(p) for p in freq_paths],
        'compact_phrases': args.compact_phrases,
        'added_count': len(added),
        'boosted_count': len(boosted),
        'penalized_count': len(penalized),
        'dropped_count': len(dropped),
        'top_added': sorted(added, key=lambda x: (-x['s'], -x['count'], x['w']))[:100],
        'top_boosted': sorted(boosted, key=lambda x: (-(x['new_s'] - x['old_s']), -x['count'], x['w']))[:100],
        'top_penalized': sorted(penalized, key=lambda x: ((x['new_s'] - x['old_s']), x['count'], x['w']))[:100],
        'top_dropped': dropped[:100],
        'notes': {
            'policy': 'Conservative by default: keep existing words, re-score them, add corpus-supported entries, only drop when --drop-bad-existing is set.',
            'intended_use': 'Build Lexicon v2 first. Later move the penalty/boost logic into a learned or MDL-guided word-quality model.',
        },
    }
    with report_path.open('w', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    print('[cw_en_lexicon_refine] out=', out_path)
    print(json.dumps({
        'added_count': len(added),
        'boosted_count': len(boosted),
        'penalized_count': len(penalized),
        'dropped_count': len(dropped),
        'top_added_preview': sorted(added, key=lambda x: (-x['s'], -x['count'], x['w']))[:10],
    }, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
