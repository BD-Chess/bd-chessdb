'use strict';

const path = require('path');
const { loadPreparedSource, getCandidates, estimatePatternCount } = require('./cw_sources');
const { evaluateState } = require('./cw_mdl');
const { DCCGovernor } = require('./cw_dcc');
const {
  cloneMask,
  makeEmptyMask,
  extractSlots,
  buildCellMap,
  getOpenComponents,
  slotLengthsValid,
  blackRatio,
  buildGridFromAssignments,
  entriesFromAssignments,
  crossingStats,
} = require('./cw_metrics');

function clamp(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }

const POLICIES = {
  dense_first:  { name: 'dense_first',  style: 'corners',   maxBlackRatio: 0.24, maskAttempts: 7,  candidateBeam: 28, fillBeam: 18, splitAggression: 0.9, openAggression: 1.2 },
  bridge_first: { name: 'bridge_first', style: 'bridge',    maxBlackRatio: 0.26, maskAttempts: 8,  candidateBeam: 24, fillBeam: 16, splitAggression: 1.0, openAggression: 0.9 },
  safe_fill_first:{name:'safe_fill_first',style:'safe',      maxBlackRatio: 0.30, maskAttempts: 9,  candidateBeam: 22, fillBeam: 14, splitAggression: 1.2, openAggression: 0.8 },
  low_black_first:{name:'low_black_first',style:'minimal',   maxBlackRatio: 0.22, maskAttempts: 8,  candidateBeam: 30, fillBeam: 18, splitAggression: 0.8, openAggression: 1.3 },
  theme_first:  { name: 'theme_first',  style: 'bridge',    maxBlackRatio: 0.27, maskAttempts: 8,  candidateBeam: 24, fillBeam: 16, splitAggression: 1.0, openAggression: 1.0 },
  polish_first: { name: 'polish_first', style: 'safe',      maxBlackRatio: 0.28, maskAttempts: 10, candidateBeam: 26, fillBeam: 16, splitAggression: 1.1, openAggression: 1.1 },
};



const TEMPLATE_MASKS = {
  9: {
    corners: [
      ['......###','......###','.......##','.....#...','....#....','...#.....','##.......','###......','###......'],
      ['......###','......###','.......##','....#....','...###...','....#....','##.......','###......','###......'],
      ['......###','......###','.......##','...#.....','....#....','.....#...','##.......','###......','###......'],
      ['.........','.........','....#....','.........','..#####..','.........','....#....','.........','.........'],
    ],
    bridge: [
      ['......###','......###','.......##','.....#...','...###...','...#.....','##.......','###......','###......'],
      ['......###','......###','.......##','....##...','....#....','...##....','##.......','###......','###......'],
      ['.........','...#.....','.........','....#....','..###..##','....#....','.........','.....#...','.........'],
    ],
    safe: [
      ['......###','......###','.......##','....#....','...###...','....#....','##.......','###......','###......'],
      ['.........','.........','.........','...###...','....#....','...###...','.........','.........','.........'],
      ['.........','..#...#..','.........','...#.#...','.........','...#.#...','.........','..#...#..','.........'],
    ],
    minimal: [
      ['......###','......###','.......##','.....#...','....#....','...#.....','##.......','###......','###......'],
      ['.........','.........','.........','##.....##','.........','##.....##','.........','.........','.........'],
    ]
  },
  11: {
    corners: [
      ['##........#','##........#','...........','.....#.....','....###....','...........','....###....','.....#.....','...........','#........##','#........##'],
      ['##........#','##........#','...........','....#.#....','...........','...#####...','...........','....#.#....','...........','#........##','#........##'],
    ],
    bridge: [
      ['##........#','##........#','...........','....##.....','.....#.....','...#####...','.....#.....','.....##....','...........','#........##','#........##'],
      ['#.........#','##.......##','...........','.....#.....','....###....','...........','....###....','.....#.....','...........','##.......##','#.........#'],
    ],
    safe: [
      ['##........#','##........#','...........','.....#.....','....###....','...........','....###....','.....#.....','...........','#........##','#........##'],
      ['...........','...........','....###....','.....#.....','...........','...#####...','...........','.....#.....','....###....','...........','...........'],
    ],
    minimal: [
      ['...........','...........','...........','##.....##..','...........','.....#.....','...........','..##.....##','...........','...........','...........'],
      ['...........','...#...#...','...........','...........','....###....','...........','....###....','...........','...........','...#...#...','...........'],
    ]
  }
};



function deriveMaskTuning(size, source, policy) {
  const conservative = !!policy.conservativeMasks || (source && source.words && source.words.length < 500);
  if (conservative) {
    return {
      minBlackRatio: Math.max(0.14, Number(policy.maxBlackRatio || 0.28) - 0.10),
      maxBlackRatio: Number(policy.maxBlackRatio || 0.28),
      targetBlackRatio: Math.max(0.18, Number(policy.maxBlackRatio || 0.28) - 0.04),
      maxLongSlots: size <= 9 ? 6 : 8,
      maxHugeSlots: size <= 9 ? 3 : 4,
      minSlots: size <= 9 ? 12 : 16,
      aggressive: false,
    };
  }
  const baseMin = size <= 9 ? 0.20 : size <= 11 ? 0.18 : 0.17;
  const capMax = size <= 9 ? 0.28 : size <= 11 ? 0.26 : 0.25;
  const minByPolicy = {
    low_black_first: baseMin - 0.02,
    dense_first: baseMin + 0.01,
    safe_fill_first: baseMin + 0.01,
    bridge_first: baseMin,
    theme_first: baseMin,
    polish_first: baseMin,
  };
  const maxLongSlots = size <= 9 ? 2 : 3;
  const maxHugeSlots = size <= 9 ? 0 : 1;
  const minSlots = size <= 9 ? 16 : 18;
  const minBlackRatio = clamp(minByPolicy[policy.name] ?? baseMin, 0.16, 0.24);
  const maxBlackRatio = Math.min(Number(policy.maxBlackRatio || capMax), capMax);
  const targetBlackRatio = clamp((minBlackRatio + maxBlackRatio) / 2, minBlackRatio + 0.01, maxBlackRatio - 0.005);
  return { minBlackRatio, maxBlackRatio, targetBlackRatio, maxLongSlots, maxHugeSlots, minSlots, aggressive: true };
}

function slotProfile(mask) {
  const slots = extractSlots(mask);
  const lengths = slots.map(s => s.len);
  return {
    slots,
    lengths,
    slotCount: lengths.length,
    long7: lengths.filter(x => x >= 7).length,
    long8: lengths.filter(x => x >= 8).length,
    huge: lengths.filter(x => x >= Math.max(mask.length - 1, 8)).length,
    maxLen: lengths.length ? Math.max(...lengths) : 0,
    avgLen: lengths.length ? lengths.reduce((a, b) => a + b, 0) / lengths.length : 0,
    fullSpan: lengths.filter(x => x === mask.length).length,
  };
}

function maskShapePenalty(mask, tuning) {
  const black = blackRatio(mask);
  const comps = getOpenComponents(mask).length;
  const profile = slotProfile(mask);
  const openTooMuch = Math.max(0, tuning.minBlackRatio - black);
  const overBlack = Math.max(0, black - tuning.maxBlackRatio);
  const longSlots = Math.max(0, profile.long8 - tuning.maxLongSlots);
  const hugeSlots = Math.max(0, profile.huge - tuning.maxHugeSlots);
  const lowSlots = Math.max(0, tuning.minSlots - profile.slotCount);
  const fullSpan = profile.fullSpan;
  const dist = Math.abs(black - tuning.targetBlackRatio);
  return (
    comps * 500 +
    openTooMuch * 2200 +
    overBlack * 900 +
    longSlots * 60 +
    hugeSlots * 140 +
    lowSlots * 14 +
    fullSpan * 80 +
    dist * 220
  );
}

function acceptableMask(mask, tuning) {
  if (!slotLengthsValid(mask)) return false;
  if (getOpenComponents(mask).length !== 1) return false;
  const black = blackRatio(mask);
  if (black > tuning.maxBlackRatio + 0.02) return false;
  const profile = slotProfile(mask);
  if (profile.huge > tuning.maxHugeSlots + 1) return false;
  if (profile.slotCount < tuning.minSlots - 2) return false;
  return true;
}

function densifyMask(mask, rng, tuning, tries = 80) {
  let best = cloneMask(mask);
  let bestPenalty = maskShapePenalty(best, tuning);
  const cells = [];
  for (let r = 1; r < mask.length - 1; r++) {
    for (let c = 1; c < mask.length - 1; c++) cells.push([r, c]);
  }
  for (const [r, c] of shuffle(rng, cells)) {
    const trial = cloneMask(best);
    setSymBlack(trial, r, c, true);
    if (!acceptableMask(trial, tuning)) continue;
    const pen = maskShapePenalty(trial, tuning);
    if (pen < bestPenalty || blackRatio(best) < tuning.minBlackRatio) {
      best = trial;
      bestPenalty = pen;
      if (bestPenalty <= 5 && blackRatio(best) >= tuning.minBlackRatio) break;
    }
    if (--tries <= 0) break;
  }
  return best;
}

function maskFromRows(rows) {
  return rows.map(row => row.split('').map(ch => ch === '#'));
}

function mulberry32(seed) {
  let t = seed >>> 0;
  return function() {
    t += 0x6D2B79F5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

function hashSeed(value) {
  const s = String(value ?? '1');
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function choice(rng, arr) {
  return arr[Math.floor(rng() * arr.length)];
}

function shuffle(rng, arr) {
  const out = arr.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

function setSymBlack(mask, r, c, value = true) {
  const n = mask.length;
  const rr = n - 1 - r;
  const cc = n - 1 - c;
  mask[r][c] = value;
  mask[rr][cc] = value;
}

function maskCorpusStats(mask, source) {
  if (!source || !source.index || !source.index.byLen) {
    return { penalty: 0, weakPairs: 0, deadPairs: 0, scarceSlots: 0, avgPairRatio: 0 };
  }
  const { slots } = prepareSlots(mask);
  let penalty = 0;
  let weakPairs = 0;
  let deadPairs = 0;
  let scarceSlots = 0;
  let pairCount = 0;
  let ratioSum = 0;
  for (const slot of slots) {
    const pool = source.index.byLen.get(slot.len) || [];
    if (!pool.length) {
      penalty += 400;
      scarceSlots += 1;
    } else if (pool.length < (slot.len >= 8 ? 40 : slot.len >= 6 ? 70 : 30)) {
      penalty += 20;
      scarceSlots += 1;
    }
  }
  const seen = new Set();
  for (const slot of slots) {
    for (const edge of slot.crossings || []) {
      const key = slot.id < edge.otherId ? `${slot.id}|${edge.otherId}` : `${edge.otherId}|${slot.id}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const freqA = source.index.letterFreq.get(slot.len)?.[edge.pos] || new Map();
      const other = slots.find(s => s.id === edge.otherId);
      if (!other) continue;
      const freqB = source.index.letterFreq.get(other.len)?.[edge.otherPos] || new Map();
      const letters = new Set([...freqA.keys(), ...freqB.keys()]);
      let overlap = 0;
      for (const ch of letters) overlap += Math.min(freqA.get(ch) || 0, freqB.get(ch) || 0);
      const totalA = Math.max(1, (source.index.byLen.get(slot.len) || []).length);
      const totalB = Math.max(1, (source.index.byLen.get(other.len) || []).length);
      const ratio = overlap / Math.max(1, Math.min(totalA, totalB));
      ratioSum += ratio;
      pairCount += 1;
      if (overlap <= 0 || ratio < 0.01) {
        deadPairs += 1;
        penalty += 280;
      } else if (ratio < 0.045) {
        weakPairs += 1;
        penalty += 90;
      } else if (ratio < 0.08) {
        weakPairs += 1;
        penalty += 35;
      }
    }
  }
  return {
    penalty,
    weakPairs,
    deadPairs,
    scarceSlots,
    avgPairRatio: pairCount ? ratioSum / pairCount : 0,
  };
}

function maskCompositePenalty(mask, tuning, source = null) {
  return maskShapePenalty(mask, tuning) + maskCorpusStats(mask, source).penalty;
}

function createSeedMask(size, style, rng, policy, source = null) {
  const tuning = deriveMaskTuning(size, source, policy);
  let pool = TEMPLATE_MASKS[size] && TEMPLATE_MASKS[size][style];
  if (pool && pool.length) {
    if (policy && policy.conservativeMasks) pool = pool.slice(0, Math.min(2, pool.length));
    const ranked = pool
      .map(rows => {
        const mask = maskFromRows(rows);
        return {
          rows,
          mask,
          compositePenalty: maskCompositePenalty(mask, tuning, source),
          corpusStats: maskCorpusStats(mask, source),
        };
      })
      .filter(x => acceptableMask(x.mask, tuning))
      .sort((a, b) => a.compositePenalty - b.compositePenalty || a.corpusStats.deadPairs - b.corpusStats.deadPairs || a.corpusStats.weakPairs - b.corpusStats.weakPairs);
    if (ranked.length) {
      const shortlist = ranked.slice(0, Math.min(ranked.length, tuning.aggressive ? 3 : 2));
      return cloneMask(choice(rng, shortlist).mask);
    }
    return maskFromRows(choice(rng, pool));
  }
  const mask = makeEmptyMask(size, false);
  const presets = {
    corners: [[0,0],[0,1],[1,0],[0,size-2]],
    bridge:  [[0,0],[0,size-1],[Math.floor(size/2),1],[Math.floor(size/2),size-2]],
    safe:    [[0,0],[0,1],[1,0],[1,1],[0,size-1],[size-1,0]],
    minimal: [[0,0],[0,size-1]],
  };
  for (const [r,c] of presets[style] || []) setSymBlack(mask, r, c, true);

  let target = Math.floor(size * (style === 'minimal' ? 0.7 : style === 'safe' ? 1.4 : 1.0));
  const candidates = [];
  for (let r = 1; r < size - 1; r++) {
    for (let c = 1; c < size - 1; c++) {
      if (Math.abs(r - Math.floor(size / 2)) <= 1 && Math.abs(c - Math.floor(size / 2)) <= 1) continue;
      candidates.push([r, c]);
    }
  }
  for (const [r, c] of shuffle(rng, candidates)) {
    if (blackRatio(mask) >= tuning.targetBlackRatio) break;
    const trial = cloneMask(mask);
    setSymBlack(trial, r, c, true);
    if (slotLengthsValid(trial) && getOpenComponents(trial).length === 1) {
      setSymBlack(mask, r, c, true);
      if (--target <= 0) break;
    }
  }
  return legalizeMask(mask, rng, tuning);
}

function legalizeMask(mask, rng, tuning = { minBlackRatio: 0.18, maxBlackRatio: 0.28, targetBlackRatio: 0.22, maxLongSlots: 4, maxHugeSlots: 2, minSlots: 12 }) {
  let out = cloneMask(mask);
  for (let guard = 0; guard < 80; guard++) {
    let changed = false;
    if (getOpenComponents(out).length > 1) {
      out = bridgeComponents(out);
      changed = true;
    }
    const short = findShortRuns(out);
    if (short.length) {
      for (const run of short.slice(0, 4)) {
        const [r, c] = run.cells[Math.floor(run.cells.length / 2)];
        setSymBlack(out, r, c, false);
      }
      changed = true;
    }
    if (blackRatio(out) > tuning.maxBlackRatio) {
      const opened = openRandomBlack(out, rng);
      if (opened) changed = true;
    }
    if (!changed) break;
  }
  if (acceptableMask(out, tuning) && blackRatio(out) < tuning.minBlackRatio) {
    out = densifyMask(out, rng, tuning, 120);
  }
  if (!acceptableMask(out, tuning)) {
    const dense = densifyMask(out, rng, tuning, 140);
    if (acceptableMask(dense, tuning)) out = dense;
  }
  if (!acceptableMask(out, tuning)) {
    return fallbackMask(out.length, tuning);
  }
  return out;
}

function fallbackMask(size, tuning = null) {
  const mask = makeEmptyMask(size, false);
  setSymBlack(mask, 0, 0, true);
  setSymBlack(mask, 0, 1, true);
  setSymBlack(mask, 1, 0, true);
  setSymBlack(mask, size - 1, size - 1, true);
  setSymBlack(mask, Math.floor(size/2), 1, true);
  setSymBlack(mask, Math.floor(size/2), size - 2, true);
  return tuning ? densifyMask(mask, mulberry32(hashSeed(`fallback:${size}:${tuning.targetBlackRatio}`)), tuning, 120) : mask;
}

function findShortRuns(mask) {
  const n = mask.length;
  const out = [];
  for (let r = 0; r < n; r++) {
    let c = 0;
    while (c < n) {
      if (mask[r][c]) { c++; continue; }
      const s = c, cells = [];
      while (c < n && !mask[r][c]) { cells.push([r, c]); c++; }
      const len = c - s;
      if (len > 0 && len < 3) out.push({ dir: 'across', cells });
    }
  }
  for (let c = 0; c < n; c++) {
    let r = 0;
    while (r < n) {
      if (mask[r][c]) { r++; continue; }
      const s = r, cells = [];
      while (r < n && !mask[r][c]) { cells.push([r, c]); r++; }
      const len = r - s;
      if (len > 0 && len < 3) out.push({ dir: 'down', cells });
    }
  }
  return out;
}

function bridgeComponents(mask) {
  const out = cloneMask(mask);
  const comps = getOpenComponents(mask);
  if (comps.length <= 1) return out;
  const a = comps[0];
  const b = comps[1];
  let best = null;
  for (const ca of a) {
    for (const cb of b) {
      const dist = Math.abs(ca[0]-cb[0]) + Math.abs(ca[1]-cb[1]);
      if (!best || dist < best.dist) best = { a: ca, b: cb, dist };
    }
  }
  if (!best) return out;
  let [r, c] = best.a;
  const [tr, tc] = best.b;
  while (r !== tr) {
    out[r][c] = false;
    r += tr > r ? 1 : -1;
  }
  while (c !== tc) {
    out[r][c] = false;
    c += tc > c ? 1 : -1;
  }
  out[r][c] = false;
  return out;
}

function openRandomBlack(mask, rng) {
  const blacks = [];
  for (let r = 0; r < mask.length; r++) {
    for (let c = 0; c < mask.length; c++) if (mask[r][c]) blacks.push([r, c]);
  }
  for (const [r, c] of shuffle(rng, blacks)) {
    const trial = cloneMask(mask);
    setSymBlack(trial, r, c, false);
    if (slotLengthsValid(trial) && getOpenComponents(trial).length === 1) {
      setSymBlack(mask, r, c, false);
      return true;
    }
  }
  return false;
}

function prepareSlots(mask) {
  const slots = extractSlots(mask);
  const cellMap = buildCellMap(slots, mask.length);
  const slotMap = new Map(slots.map(s => [s.id, s]));
  for (const slot of slots) {
    slot.crossCount = 0;
    slot.crossIndices = [];
    slot.crossings = [];
    slot.crossingsByOther = new Map();
    slot.cells.forEach(([r, c], idx) => {
      if ((cellMap[r][c] || []).length > 1) {
        slot.crossCount++;
        slot.crossIndices.push(idx);
      }
    });
  }
  for (let r = 0; r < cellMap.length; r++) {
    for (let c = 0; c < cellMap.length; c++) {
      const refs = cellMap[r][c] || [];
      if (refs.length < 2) continue;
      for (let i = 0; i < refs.length; i++) {
        for (let j = i + 1; j < refs.length; j++) {
          const a = refs[i];
          const b = refs[j];
          const slotA = slotMap.get(a.slotId);
          const slotB = slotMap.get(b.slotId);
          if (!slotA || !slotB) continue;
          const edgeAB = { otherId: b.slotId, pos: a.pos, otherPos: b.pos, cell: [r, c] };
          const edgeBA = { otherId: a.slotId, pos: b.pos, otherPos: a.pos, cell: [r, c] };
          slotA.crossings.push(edgeAB);
          slotB.crossings.push(edgeBA);
          slotA.crossingsByOther.set(b.slotId, edgeAB);
          slotB.crossingsByOther.set(a.slotId, edgeBA);
        }
      }
    }
  }
  return { slots, cellMap };
}


function cloneAssignments(assignments) {
  const out = {};
  for (const [k, v] of Object.entries(assignments || {})) out[k] = v ? { ...v } : v;
  return out;
}

function spreadPick(arr, count) {
  if (!arr || !arr.length || count <= 0) return [];
  if (arr.length <= count) return arr.slice();
  const out = [];
  const seen = new Set();
  const stride = (arr.length - 1) / Math.max(1, count - 1);
  for (let i = 0; i < count; i++) {
    const idx = Math.max(0, Math.min(arr.length - 1, Math.round(i * stride)));
    const item = arr[idx];
    const key = item && (item.w || item.id || idx);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(item);
  }
  return out;
}

function scoreProgress(assignments, slots, backtracks = 0) {
  const filled = Object.values(assignments || {}).filter(Boolean);
  const fillCount = filled.length;
  const cross = filled.reduce((a, s) => a + Number(s.crossCount || 0), 0);
  const lexical = filled.reduce((a, s) => a + Number(s.score || 0) - Number(s.shapePenalty || 0), 0);
  return fillCount * 10000 + cross * 70 + lexical - Math.log1p(backtracks) * 12 - (slots.length - fillCount) * 25;
}

function diversifyCandidates(candidates, limit, depth = 0) {
  if (!candidates || !candidates.length) return [];
  const head = candidates.slice(0, Math.min(candidates.length, Math.max(limit * 2, 12)));
  if (head.length <= limit) return head;
  if (depth >= 3) return head.slice(0, limit);
  const top = head.slice(0, Math.ceil(limit * 0.55));
  const tail = spreadPick(head.slice(top.length), Math.max(0, limit - top.length));
  return [...top, ...tail].slice(0, limit);
}


function fillMask(mask, source, policy, opts = {}) {
  const { slots, cellMap } = prepareSlots(mask);
  const n = mask.length;
  const board = Array.from({ length: n }, (_, r) => Array.from({ length: n }, (_, c) => mask[r][c] ? '#' : null));
  const coverCount = Array.from({ length: n }, () => Array(n).fill(0));
  const assignments = {};
  const slotMap = new Map(slots.map(s => [s.id, s]));
  const usedWords = new Set();
  const allowReuse = !!opts.allowReuse;
  const candidateStats = [];
  const conservative = source.words.length < 500;
  const beamBase = conservative ? Math.max(Number(policy.candidateBeam || 24), 36) : Math.max(Number(policy.candidateBeam || 24), source.words.length > 9000 ? 132 : source.words.length > 4500 ? 104 : 72);
  const fillBeam = conservative ? Math.max(Number(policy.fillBeam || 16), 18) : Math.max(Number(policy.fillBeam || 16), source.words.length > 9000 ? 34 : source.words.length > 4500 ? 28 : 20);
  const domainProbe = conservative ? Math.max(beamBase * 2, 72) : Math.min(Math.max(beamBase * 4, 260), 540);
  const anchorBeam = conservative ? 3 : Math.max(4, Math.min(10, Math.floor(fillBeam / 2)));
  let backtracks = 0;
  let bestDepth = 0;
  let failInfo = null;
  let bestState = {
    progress: -Infinity,
    assignments: {},
    failInfo: null,
    depth: 0,
  };
  const candidateCache = new Map();

  function patternFor(slot) {
    return slot.cells.map(([r, c]) => board[r][c] || '?').join('');
  }

  function availableCandidates(slot, maxCandidates = beamBase) {
    const pattern = patternFor(slot);
    const cacheKey = `${slot.id}|${pattern}`;
    let cached = candidateCache.get(cacheKey);
    if (!cached) {
      cached = rankCandidatesForPolicy(slot, getCandidates(source.index, slot, pattern, new Set(), {
        maxCandidates: Math.max(maxCandidates, beamBase * 3),
        themeWords: opts.themeWords,
      }), policy.name);
      candidateCache.set(cacheKey, cached);
    }
    if (allowReuse) return cached.slice(0, maxCandidates);
    const out = [];
    for (const cand of cached) {
      if (usedWords.has(cand.w)) continue;
      out.push(cand);
      if (out.length >= maxCandidates) break;
    }
    return out;
  }

  function captureBest(reason = null, depth = Object.keys(assignments).length) {
    const progress = scoreProgress(assignments, slots, backtracks);
    if (progress > bestState.progress) {
      bestState = {
        progress,
        assignments: cloneAssignments(assignments),
        failInfo: reason ? { ...reason } : failInfo ? { ...failInfo } : null,
        depth,
      };
    }
    bestDepth = Math.max(bestDepth, depth);
  }

  function assign(slot, wordObj) {
    for (let i = 0; i < slot.len; i++) {
      const [r, c] = slot.cells[i];
      const ch = wordObj.w[i];
      if (board[r][c] && board[r][c] !== ch) return false;
    }
    for (let i = 0; i < slot.len; i++) {
      const [r, c] = slot.cells[i];
      board[r][c] = wordObj.w[i];
      coverCount[r][c] += 1;
    }
    assignments[slot.id] = { ...slot, ...wordObj, word: wordObj.w };
    if (!allowReuse) usedWords.add(wordObj.w);
    return true;
  }

  function unassign(slot) {
    const current = assignments[slot.id];
    if (!current) return;
    delete assignments[slot.id];
    if (!allowReuse) usedWords.delete(current.word);
    for (let i = 0; i < slot.len; i++) {
      const [r, c] = slot.cells[i];
      coverCount[r][c] -= 1;
      if (coverCount[r][c] <= 0) board[r][c] = null;
    }
  }


  function relatedUnassignedSlots(slot) {
    const seen = new Set();
    const related = [];
    for (const [r, c] of slot.cells) {
      for (const ref of cellMap[r][c]) {
        if (ref.slotId === slot.id) continue;
        if (assignments[ref.slotId]) continue;
        if (seen.has(ref.slotId)) continue;
        seen.add(ref.slotId);
        related.push(slotMap.get(ref.slotId));
      }
    }
    return related;
  }

  function slotDomainInfo(slot, maxCandidates = domainProbe) {
    const pattern = patternFor(slot);
    const approx = estimatePatternCount(source.index, slot.len, pattern);
    const cands = availableCandidates(slot, maxCandidates);
    return { pattern, approx, cands, domain: cands.length || approx || 0 };
  }

  function isClosureMode(depth = Object.keys(assignments).length) {
    const remaining = slots.length - depth;
    return remaining <= Math.max(7, Math.floor(slots.length * 0.32)) || depth / Math.max(1, slots.length) >= 0.58;
  }

  function candidateHasProjectedSupport(slot, cand, depthBudget = 1, parentId = null) {
    for (const edge of slot.crossings || []) {
      if (edge.otherId === parentId) continue;
      const otherAssigned = assignments[edge.otherId];
      if (otherAssigned) {
        if (otherAssigned.word[edge.otherPos] !== cand.w[edge.pos]) return false;
        continue;
      }
      const other = slotMap.get(edge.otherId);
      if (!other) continue;
      const info = slotDomainInfo(other, Math.min(domainProbe, depthBudget > 1 ? 72 : 40));
      let ok = false;
      let checked = 0;
      for (const oc of info.cands) {
        if (oc.w[edge.otherPos] !== cand.w[edge.pos]) continue;
        checked += 1;
        if (depthBudget > 1 && !candidateHasProjectedSupport(other, oc, depthBudget - 1, slot.id)) continue;
        ok = true;
        break;
      }
      if (!ok || !checked) return false;
    }
    return true;
  }

  function rankSlotForSearch(slot, info) {
    const pattern = info.pattern;
    const knownLetters = pattern.split('').filter(ch => ch && ch !== '?').length;
    const openness = (slot.len - knownLetters) / Math.max(1, slot.len);
    const related = relatedUnassignedSlots(slot).length;
    const idealLen = slot.len <= 5 ? 0 : Math.abs(slot.len - (mask.length <= 9 ? 6 : 7));
    const longPenalty = slot.len >= Math.max(8, mask.length - 1) ? 1 : 0;
    const domain = Math.max(1, Math.min(info.domain, info.approx || info.domain));
    const score = domain * 165 - knownLetters * 42 - slot.crossCount * 28 - related * 18 + idealLen * 12 + longPenalty * 44 + openness * 26;
    return { score, knownLetters, related };
  }

  function orderCandidatesForSlot(slot, candidates, depth = 0, closureMode = false) {
    const related = relatedUnassignedSlots(slot);
    const probeWidth = closureMode ? Math.min(Math.max(fillBeam * 4, 18), candidates.length) : Math.min(Math.max(fillBeam * 3, 10), candidates.length);
    const probeList = diversifyCandidates(candidates, probeWidth, depth);
    const scored = [];
    for (const cand of probeList) {
      if (!assign(slot, cand)) continue;
      let minDomain = Infinity;
      let sumDomain = 0;
      let zeroHit = false;
      let forced = 0;
      let viabilityBonus = 0;
      let supportedNeighbors = 0;
      for (const other of related) {
        const info = slotDomainInfo(other, Math.min(domainProbe, Math.max(fillBeam * 4, closureMode ? 120 : 84)));
        const dom = info.domain;
        if (!dom) { zeroHit = true; break; }
        if (dom < minDomain) minDomain = dom;
        sumDomain += Math.log2(dom + 1);
        if (dom === 1) forced += 1;
        const tightLetters = info.pattern.split('').filter(ch => ch && ch !== '?').length;
        viabilityBonus += tightLetters * 1.8 - Math.max(0, other.len - 7) * 1.5;
        const sampled = info.cands.slice(0, closureMode ? 18 : 10);
        let live = 0;
        for (const oc of sampled) {
          if (candidateHasProjectedSupport(other, oc, closureMode ? 2 : 1, slot.id)) live += 1;
        }
        if (!live && sampled.length) { zeroHit = true; break; }
        supportedNeighbors += live;
      }
      const selfProjected = candidateHasProjectedSupport(slot, cand, closureMode ? 2 : 1, null);
      unassign(slot);
      if (zeroHit || !selfProjected) continue;
      const opennessPenalty = slot.len >= 8 && depth <= 1 ? 24 : 0;
      const closureBonus = closureMode ? supportedNeighbors * 14 - forced * 5 : supportedNeighbors * 8 - forced * 8;
      const viability = (Number.isFinite(minDomain) ? minDomain : 1) * (closureMode ? 150 : 135) + sumDomain * 22 - forced * 8 + (cand.crossPotential || 0) * 44 + cand.fitScore * 0.32 + viabilityBonus + closureBonus - opennessPenalty;
      scored.push({ cand, viability });
    }
    if (!scored.length) return candidates.slice(0, closureMode ? Math.max(fillBeam * 2, 10) : fillBeam);
    scored.sort((a, b) => b.viability - a.viability || b.cand.fitScore - a.cand.fitScore || a.cand.w.localeCompare(b.cand.w));
    return scored.map(x => x.cand).slice(0, closureMode ? Math.max(fillBeam * 2, 10) : fillBeam);
  }

  function forwardCheck(slot, depth = 0, closureMode = false) {
    let minDomain = Infinity;
    let tightest = null;
    const related = relatedUnassignedSlots(slot);
    const scan = (!conservative && (depth <= 2 || closureMode))
      ? slots.filter(s => !assignments[s.id])
      : related;
    for (const other of scan) {
      const info = slotDomainInfo(other, Math.min(domainProbe, Math.max(beamBase * 2, 96)));
      const dom = info.domain;
      if (!dom) return { ok: false, deadSlot: other };
      if (dom < minDomain) {
        minDomain = dom;
        tightest = other;
      }
    }
    return { ok: true, minDomain, tightest };
  }

  function selectNextSlot(depth = Object.keys(assignments).length) {
    let best = null;
    for (const slot of slots) {
      if (assignments[slot.id]) continue;
      const info = slotDomainInfo(slot, Math.min(domainProbe, Math.max(beamBase * 2, 96)));
      candidateStats.push(info.domain);
      if (!info.domain || !info.cands.length) return { slot, candidates: [], dead: true };
      const rank = rankSlotForSearch(slot, info);
      const closureMode = isClosureMode(depth);
      const domainScore = closureMode ? info.domain * 220 - rank.knownLetters * 48 - slot.crossCount * 36 : rank.score;
      if (!best || domainScore < best.candidateScore || (domainScore === best.candidateScore && (rank.knownLetters > best.knownLetters || slot.crossCount > best.slot.crossCount))) {
        best = { slot, candidates: info.cands, candidateScore: domainScore, knownLetters: rank.knownLetters };
      }
    }
    return best;
  }

  function recurse(depth = 0) {
    captureBest(null, depth);
    if (depth === slots.length) return true;
    const closureMode = isClosureMode(depth);
    const next = selectNextSlot(depth);
    if (!next) return true;
    if (!next.candidates.length) {
      failInfo = { deadSlot: next.slot, reason: 'zero_candidates', depth };
      captureBest(failInfo, depth);
      return false;
    }
    const cands = diversifyCandidates(next.candidates, closureMode ? Math.max(fillBeam * 2, 12) : Math.max(fillBeam, 8), depth);
    const orderedCands = orderCandidatesForSlot(next.slot, cands, depth, closureMode);
    for (const cand of orderedCands) {
      if (!assign(next.slot, cand)) continue;
      captureBest(null, depth + 1);
      const fwd = forwardCheck(next.slot, depth + 1, closureMode);
      if (fwd.ok && recurse(depth + 1)) return true;
      if (!fwd.ok) {
        failInfo = { deadSlot: fwd.deadSlot, reason: 'forward_zero', depth: depth + 1 };
        captureBest(failInfo, depth + 1);
      }
      unassign(next.slot);
      backtracks++;
    }
    return false;
  }

  function anchorPlans() {
    const slotInfos = slots
      .slice()
      .map(slot => {
        const info = slotDomainInfo(slot, Math.min(domainProbe, Math.max(anchorBeam * 12, 120)));
        const idealGap = Math.abs(slot.len - (mask.length <= 9 ? 6 : 7));
        const openness = 1 - (info.pattern.split('').filter(ch => ch && ch !== '?').length / Math.max(1, slot.len));
        const rank = info.domain * 20 + idealGap * 18 - slot.crossCount * 32 + openness * 16 + (slot.len >= Math.max(8, mask.length - 1) ? 40 : 0);
        return { slot, info, rank };
      })
      .filter(x => x.info.domain > 0 && x.slot.crossCount >= 2)
      .sort((a, b) => a.rank - b.rank || a.info.domain - b.info.domain || b.slot.crossCount - a.slot.crossCount);
    const plans = [null];
    const headSlots = slotInfos.slice(0, conservative ? 1 : Math.min(6, slotInfos.length));
    for (const entry of headSlots) {
      const slot = entry.slot;
      const cands = entry.info.cands.filter(c => {
        if (slot.len >= 8 && (c.crossPotential || 0) < 0.18) return false;
        if (slot.len >= Math.max(mask.length - 1, 8) && (c.shapePenalty || 0) > 6) return false;
        return true;
      });
      const picked = spreadPick(cands, anchorBeam)
        .sort((a, b) => (b.crossPotential || 0) - (a.crossPotential || 0) || b.fitScore - a.fitScore || a.w.localeCompare(b.w));
      for (const cand of picked) plans.push({ slot, cand });
    }
    return plans;
  }

  let solved = false;
  for (const plan of anchorPlans()) {
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (!mask[r][c]) board[r][c] = null;
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) coverCount[r][c] = 0;
    for (const k of Object.keys(assignments)) delete assignments[k];
    usedWords.clear();

    let depth0 = 0;
    if (plan) {
      if (!assign(plan.slot, plan.cand)) continue;
      depth0 = 1;
      captureBest(null, depth0);
      const fwd = forwardCheck(plan.slot, depth0);
      if (!fwd.ok) {
        failInfo = { deadSlot: fwd.deadSlot, reason: 'anchor_forward_zero', depth: depth0 };
        captureBest(failInfo, depth0);
        unassign(plan.slot);
        continue;
      }
    }
    if (recurse(depth0)) {
      solved = true;
      break;
    }
  }

  const finalAssignments = solved ? assignments : bestState.assignments;
  const avgEntropy = candidateStats.length ? candidateStats.reduce((a, b) => a + Math.log2(Math.max(1, b)), 0) / candidateStats.length : 0;
  return {
    solved,
    assignments: cloneAssignments(finalAssignments),
    slots,
    backtracks,
    bestDepth: Math.max(bestDepth, bestState.depth || 0),
    failInfo: solved ? failInfo : (bestState.failInfo || failInfo),
    avgEntropy,
    fillRatio: Object.keys(finalAssignments).length / Math.max(1, slots.length),
  };
}



function rankCandidatesForPolicy(slot, candidates, policyName) {
  return candidates
    .map(c => {
      let bonus = 0;
      const balance = Math.abs(0.42 - Number(c.vowelRatio || 0)) * -8;
      const crossBonus = slot.crossCount * 0.7;
      if (policyName === 'dense_first') bonus += slot.crossCount * 1.8 + (slot.len >= 6 ? 2 : 0);
      else if (policyName === 'bridge_first') bonus += slot.crossCount * 2.4 + (slot.len >= 5 ? 1.2 : 0);
      else if (policyName === 'safe_fill_first') bonus += c.score * 0.04 - c.shapePenalty * 1.05 + balance;
      else if (policyName === 'low_black_first') bonus += slot.len * 0.8 + c.score * 0.03 + balance * 0.5;
      else if (policyName === 'theme_first') bonus += (c.topic ? 8 : 0) + crossBonus;
      else if (policyName === 'polish_first') bonus += c.score * 0.05 - c.shapePenalty * 0.5 + balance + crossBonus;
      return { ...c, rankScore: c.fitScore + bonus + crossBonus };
    })
    .sort((a, b) => b.rankScore - a.rankScore || b.fitScore - a.fitScore || a.w.localeCompare(b.w));
}


function snapshotFor(mask, assignments, solve, policy, governor) {
  const slots = solve.slots || Object.values(assignments);
  const cross = crossingStats(mask, slots);
  const filled = Object.values(assignments).filter(s => s && s.word);
  const garbageRatio = filled.length ? filled.filter(s => (s.score || 0) < 65 || (s.shapePenalty || 0) > 8 || (s.tier || 1) > 1).length / filled.length : 1;
  return {
    components: getOpenComponents(mask).length,
    invalidSlots: slotLengthsValid(mask) ? 0 : 1,
    fillRatio: solve.fillRatio || 0,
    blackRatio: blackRatio(mask),
    crossingDensity: cross.crossingDensity,
    deadPressure: solve.failInfo ? 1 : 0,
    garbageRatio,
    solved: solve.solved,
    targetBlackRatio: policy.targetBlackRatio ?? policy.maxBlackRatio,
  };
}

function mutateMask(mask, phase, solve, rng, policy, source = null) {
  const tuning = policy.maskTuning || deriveMaskTuning(mask.length, source, policy);
  const trial = cloneMask(mask);
  if (phase === 'seed') {
    return createSeedMask(mask.length, policy.style, rng, policy, { words: Array(tuning.aggressive ? 1000 : 100) });
  }

  if ((phase === 'densify' || phase === 'repair') && blackRatio(mask) < tuning.minBlackRatio) {
    const denser = densifyMask(mask, rng, tuning, 160);
    if (maskCompositePenalty(denser, tuning, source) <= maskCompositePenalty(mask, tuning, source)) return denser;
  }

  if ((phase === 'bridge' || phase === 'densify' || phase === 'repair') && solve.failInfo && solve.failInfo.deadSlot) {
    const deadSlot = solve.failInfo.deadSlot;
    const options = deadSlot.cells.slice(1, -1);
    for (const [r, c] of shuffle(rng, options)) {
      const candidate = cloneMask(mask);
      setSymBlack(candidate, r, c, true);
      if (acceptableMask(candidate, tuning) && blackRatio(candidate) <= tuning.maxBlackRatio + 0.02) {
        return candidate;
      }
    }
  }

  if (phase === 'polish') {
    const blacks = [];
    for (let r = 0; r < mask.length; r++) for (let c = 0; c < mask.length; c++) if (mask[r][c]) blacks.push([r, c]);
    for (const [r, c] of shuffle(rng, blacks)) {
      const candidate = cloneMask(mask);
      setSymBlack(candidate, r, c, false);
      if (acceptableMask(candidate, tuning) && blackRatio(candidate) >= tuning.minBlackRatio - 0.02 && blackRatio(candidate) <= tuning.maxBlackRatio + 0.02) {
        return candidate;
      }
    }
  }

  const cells = [];
  for (let r = 1; r < mask.length - 1; r++) {
    for (let c = 1; c < mask.length - 1; c++) cells.push([r, c]);
  }
  for (const [r, c] of shuffle(rng, cells)) {
    const candidate = cloneMask(mask);
    setSymBlack(candidate, r, c, !candidate[r][c]);
    if (acceptableMask(candidate, tuning) && blackRatio(candidate) >= tuning.minBlackRatio - 0.02 && blackRatio(candidate) <= tuning.maxBlackRatio + 0.02) {
      return candidate;
    }
  }
  return trial;
}

function improveAssignments(mask, source, solveResult, policy, opts = {}) {
  const assignments = { ...solveResult.assignments };
  const weak = Object.values(assignments)
    .filter(Boolean)
    .sort((a, b) => (a.score + (a.shapePenalty || 0) * -2) - (b.score + (b.shapePenalty || 0) * -2));
  if (!weak.length) return assignments;

  const slotsById = new Map((solveResult.slots || []).map(s => [s.id, s]));
  const board = buildGridFromAssignments(mask, assignments);
  for (const slot of weak.slice(0, 4)) {
    const base = slotsById.get(slot.id) || slot;
    const pattern = base.cells.map(([r, c], idx) => {
      const ch = board[r][c];
      if (ch === '#') return '?';
      let keep = ch;
      const same = slot.word[idx];
      if (keep !== same) return keep;
      // allow changing non-forced letters if cell is not crossing
      let isCross = false;
      for (const other of (solveResult.slots || [])) {
        if (other.id === slot.id) continue;
        if (other.cells.some(([rr, cc]) => rr === r && cc === c)) { isCross = true; break; }
      }
      return isCross ? keep : '?';
    }).join('');

    const used = new Set(Object.values(assignments).filter(Boolean).map(x => x.word));
    used.delete(slot.word);
    const alts = getCandidates(source.index, base, pattern, used, { maxCandidates: 40, themeWords: opts.themeWords })
      .filter(x => x.w !== slot.word)
      .sort((a, b) => (b.score - (b.shapePenalty || 0)) - (a.score - (a.shapePenalty || 0)));
    if (alts.length && alts[0].score - (alts[0].shapePenalty || 0) > slot.score - (slot.shapePenalty || 0) + 4) {
      assignments[slot.id] = { ...base, ...alts[0], word: alts[0].w };
    }
  }
  return assignments;
}

function generateWithPolicy(source, opts = {}) {
  const size = Number(opts.size || 9);
  let policy = typeof opts.policy === 'string' ? POLICIES[opts.policy] : (opts.policy || POLICIES.dense_first);
  if (!policy) throw new Error(`Unknown policy: ${opts.policy}`);
  policy = { ...policy, conservativeMasks: source.words.length < 500 };
  policy.maskTuning = deriveMaskTuning(size, source, policy);
  policy.targetBlackRatio = policy.maskTuning.targetBlackRatio;
  policy.maxBlackRatio = Math.min(policy.maxBlackRatio, policy.maskTuning.maxBlackRatio);
  const seed = hashSeed(`${opts.seed || 1}:${size}:${policy.name}:${source.lang}`);
  const rng = mulberry32(seed);
  const governor = new DCCGovernor(policy.name, opts);
  const themeWords = new Set((opts.themeWords || []).map(x => String(x).toUpperCase()));
  let mask = createSeedMask(size, policy.style, rng, policy, source);
  let best = null;
  let totalBacktracks = 0;
  let fillAttempts = 0;
  let maskMutations = 0;

  for (let attempt = 0; attempt < policy.maskAttempts; attempt++) {
    fillAttempts++;
    let solve = fillMask(mask, source, policy, { themeWords, allowReuse: false });
    if (!solve.solved) {
      const fallbackSolve = fillMask(mask, source, policy, { themeWords, allowReuse: true });
      if (fallbackSolve.solved || fallbackSolve.fillRatio > solve.fillRatio) solve = fallbackSolve;
    }
    totalBacktracks += solve.backtracks;
    let assignments = solve.assignments;
    if (solve.solved && policy.name === 'polish_first') {
      assignments = improveAssignments(mask, source, solve, policy, { themeWords });
    }
    const maskDiagnostics = maskCorpusStats(mask, source);
    const traceMeta = {
      backtracks: totalBacktracks,
      maskMutations,
      fillAttempts,
      deadSlots: solve.failInfo ? 1 : 0,
      avgEntropy: solve.avgEntropy,
      bestDepth: solve.bestDepth,
      slotCount: solve.slots.length,
      slotLens: solve.slots.map(s => s.len),
      maskWeakPairs: maskDiagnostics.weakPairs,
      maskDeadPairs: maskDiagnostics.deadPairs,
      maskAvgPairRatio: Number((maskDiagnostics.avgPairRatio || 0).toFixed(4)),
    };
    const evalResult = evaluateState(mask, assignments, traceMeta, opts);
    const snap = snapshotFor(mask, assignments, solve, policy, governor);
    snap.totalScore = evalResult.total;
    governor.observe(snap);
    const phase = governor.pickPhase(snap);

    const candidate = {
      solved: solve.solved,
      policy: policy.name,
      seed,
      size,
      mask: cloneMask(mask),
      assignments,
      slots: solve.slots,
      traceMeta,
      governorTrace: governor.trace.slice(),
      score: evalResult,
      grid: buildGridFromAssignments(mask, assignments),
      entries: entriesFromAssignments(assignments),
    };

    if (!best || (candidate.solved && !best.solved) || (candidate.solved === best.solved && candidate.score.total < best.score.total)) best = candidate;
    if (solve.solved && phase === 'commit') break;
    mask = mutateMask(mask, phase, solve, rng, policy, source);
    maskMutations++;
  }

  best.traceMeta.backtracks = totalBacktracks;
  best.traceMeta.fillAttempts = fillAttempts;
  best.traceMeta.maskMutations = maskMutations;
  return best;
}

function comparePolicies(source, opts = {}) {
  const policies = opts.policies && opts.policies.length ? opts.policies : Object.keys(POLICIES);
  const results = [];
  for (const name of policies) {
    results.push(generateWithPolicy(source, { ...opts, policy: name }));
  }
  results.sort((a, b) => Number(b.solved) - Number(a.solved) || Number(a.score.total) - Number(b.score.total));
  return {
    winner: results[0],
    ranking: results.map((r, idx) => ({
      rank: idx + 1,
      policy: r.policy,
      solved: r.solved,
      totalScore: r.score.total,
      blackRatio: r.score.metrics.blackRatio,
      crossingDensity: r.score.metrics.crossingDensity,
      averageWordScore: r.score.metrics.averageWordScore,
      fillRatio: r.score.metrics.fillRatio,
      uncheckedLetters: r.score.metrics.uncheckedLetters,
      bestDepth: r.traceMeta.bestDepth ?? 0,
      maskMutations: r.traceMeta.maskMutations,
      fillAttempts: r.traceMeta.fillAttempts,
      backtracks: r.traceMeta.backtracks,
    })),
    results,
  };
}

function renderGrid(grid) {
  return grid.map(row => row.join('')).join('\n');
}

function puzzleJson(result, source, opts = {}) {
  return {
    metadata: {
      engine: 'cw_bun_v1',
      runtime_target: 'bun-first / plain-js',
      verified_runtime_here: 'node-compatible',
      generated_at: new Date().toISOString(),
      policy: result.policy,
      seed: opts.seed,
      source_name: source.sourceName,
      source_path: source.sourcePath,
    },
    language: source.lang,
    sourceInfo: {
      name: source.sourceName,
      path: source.sourcePath,
      word_count: source.words.length,
    },
    size: result.size,
    grid: result.grid.map(row => row.slice()),
    gridText: renderGrid(result.grid),
    mask: result.mask.map(row => row.map(v => v ? 1 : 0)),
    acrossEntries: result.entries.across,
    downEntries: result.entries.down,
    metrics: result.score.metrics,
    finalScoreSummary: result.score,
    dccPhaseTrace: result.governorTrace,
    winningStrategy: result.policy,
    traceMeta: result.traceMeta,
    solved: result.solved,
  };
}

function loadSourceAndRun(opts = {}) {
  const source = loadPreparedSource({
    lang: opts.lang,
    source: opts.source,
    baseDir: opts.baseDir || process.cwd(),
    includeTopics: opts.includeTopics,
    excludeTopics: opts.excludeTopics,
    ageProfile: opts.ageProfile,
    minScore: opts.minScore,
    merge: opts.merge,
    maxPerLength: opts.maxPerLength,
  });
  return { source, result: generateWithPolicy(source, opts) };
}

module.exports = {
  POLICIES,
  hashSeed,
  renderGrid,
  createSeedMask,
  fillMask,
  generateWithPolicy,
  comparePolicies,
  puzzleJson,
  loadSourceAndRun,
};
