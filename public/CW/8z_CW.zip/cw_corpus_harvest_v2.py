#!/usr/bin/env python3
"""
cw_corpus_harvest_v2.py

Focused harvester for two separate goals:
1) entry corpus / lexicon building
2) full solved-grid corpus / MDL research

Improvements over v1:
- better default sources for FULL solved grids
- optional GitHub tree-API downloader for repos with many raw JSON puzzle files
- optional nested archive extraction
- optional IPUZ parsing via `pip install ipuz`
- JSONL / NDJSON support
- richer normalization summary

Default policy:
- open / cleaner sources only
- mixed/unclear-rights sources require --include-risky

Typical use:
    python cw_corpus_harvest_v2.py --out cw_corpus_v2
    python cw_corpus_harvest_v2.py --out cw_corpus_v2 --include-risky
    python cw_corpus_harvest_v2.py --out cw_corpus_v2 --include-risky --github-token YOURTOKEN
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import re
import sys
import tarfile
import time
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass, asdict
from html.parser import HTMLParser
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple, Any
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen

UA = "Mozilla/5.0 (compatible; cw-corpus-harvest-v2/1.0; +local-research)"
TIMEOUT = 60

DEFAULT_MANIFEST = {
    "sources": [
        {
            "id": "nzfeng_crossword_dataset",
            "enabled": True,
            "risk": "open",
            "type": "github_repo_zip",
            "owner": "nzfeng",
            "repo": "crossword-dataset",
            "ref": "main",
            "notes": "Curated crossword entry dataset; mainly for lexicon enrichment"
        },
        {
            "id": "viresh_public_puzzles_repo",
            "enabled": True,
            "risk": "open",
            "type": "github_repo_zip",
            "owner": "viresh-ratnakar",
            "repo": "viresh-ratnakar.github.io",
            "ref": "master",
            "notes": "Public-use served crossword pages with many *-solved.html Exolve puzzles"
        },
        {
            "id": "jw_allen_puzzles_repo",
            "enabled": True,
            "risk": "open",
            "type": "github_repo_zip",
            "owner": "jw-allen",
            "repo": "puzzles-and-quizzes",
            "ref": "main",
            "notes": "Small public repo with PUZ/ODT/PDF crossword artifacts"
        },
        {
            "id": "nyt_crosswords_archive_optin",
            "enabled": False,
            "risk": "unclear",
            "type": "github_tree_raw",
            "owner": "doshea",
            "repo": "nyt_crosswords",
            "ref": "master",
            "include_exts": [".json"],
            "path_regex": r"^\d{4}/\d{2}/\d{2}\.json$",
            "max_files": 5000,
            "notes": "Public GitHub NYT JSON archive; provenance/rights unclear, opt-in only"
        },
        {
            "id": "crosswordqa_hf_optin",
            "enabled": False,
            "risk": "mixed",
            "type": "hf_file",
            "repo_id": "albertxu/CrosswordQA",
            "file_path": "data/train-00000-of-00001.parquet",
            "notes": "Large clue-answer dataset; provenance mixed; disabled by default"
        }
    ]
}

ENTRY_CLEAN_RE = re.compile(r"[^A-Z ]+")
MULTISPACE_RE = re.compile(r"\s+")
EXOLVE_BLOCK_RE = re.compile(r"exolve-begin(.*?)exolve-end", flags=re.DOTALL | re.IGNORECASE)
JSON_LINE_START = re.compile(r"\s*[\{\[]")
RAW_GITHUB = "https://raw.githubusercontent.com"

def log(*args):
    print(*args, file=sys.stderr)

def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def fetch_bytes(url: str, token: Optional[str] = None) -> bytes:
    headers = {"User-Agent": UA}
    if token and "api.github.com" in url:
        headers["Authorization"] = f"Bearer {token}"
    req = Request(url, headers=headers)
    with urlopen(req, timeout=TIMEOUT) as resp:
        return resp.read()

def safe_name(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", s)

def norm_entry(s: str) -> str:
    s = s.upper().replace("-", " ").replace("_", " ")
    s = ENTRY_CLEAN_RE.sub("", s)
    s = MULTISPACE_RE.sub(" ", s).strip()
    return s

def load_manifest(path: Optional[Path], out_dir: Path) -> dict:
    manifest = DEFAULT_MANIFEST if path is None else json.loads(path.read_text(encoding="utf-8"))
    (out_dir / "manifest_used.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest

def iter_enabled_sources(manifest: dict, include_risky: bool):
    for src in manifest.get("sources", []):
        if not src.get("enabled", True):
            continue
        risk = src.get("risk", "open")
        if risk in {"mixed", "unclear"} and not include_risky:
            log(f"[skip] {src['id']} risk={risk}; use --include-risky to enable")
            continue
        yield src

class LinkExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag.lower() == "a" and "href" in attrs:
            self.links.append(attrs["href"])

def load_optional_puz():
    try:
        import puz  # type: ignore
        return puz
    except Exception:
        return None

def load_optional_ipuz():
    try:
        import ipuz  # type: ignore
        return ipuz
    except Exception:
        return None

PUZ = load_optional_puz()
IPUZ = load_optional_ipuz()

def github_tree_paths(owner: str, repo: str, ref: str, token: Optional[str]) -> Tuple[List[dict], bool]:
    url = f"https://api.github.com/repos/{owner}/{repo}/git/trees/{ref}?recursive=1"
    data = fetch_bytes(url, token=token)
    obj = json.loads(data.decode("utf-8", errors="ignore"))
    return obj.get("tree", []), bool(obj.get("truncated", False))

def download_source(src: dict, raw_dir: Path, token: Optional[str]) -> List[Path]:
    stype = src["type"]
    source_id = src["id"]
    target_dir = raw_dir / safe_name(source_id)
    ensure_dir(target_dir)
    outputs: List[Path] = []

    if stype == "github_repo_zip":
        owner, repo, ref = src["owner"], src["repo"], src.get("ref", "main")
        url = f"https://codeload.github.com/{owner}/{repo}/zip/refs/heads/{ref}"
        out_path = target_dir / f"{repo}-{ref}.zip"
        log(f"[download] {source_id} <- {url}")
        out_path.write_bytes(fetch_bytes(url, token=token))
        extract_dir = target_dir / "extracted"
        ensure_dir(extract_dir)
        with zipfile.ZipFile(out_path, "r") as zf:
            zf.extractall(extract_dir)
        outputs.append(extract_dir)

    elif stype == "github_tree_raw":
        owner, repo, ref = src["owner"], src["repo"], src.get("ref", "main")
        include_exts = tuple(x.lower() for x in src.get("include_exts", []))
        path_regex = re.compile(src["path_regex"]) if src.get("path_regex") else None
        max_files = int(src.get("max_files", 5000))
        log(f"[download] {source_id} tree API listing {owner}/{repo}@{ref}")
        tree, truncated = github_tree_paths(owner, repo, ref, token)
        if truncated:
            log(f"[warn] {source_id}: GitHub tree listing truncated; results may be incomplete")
        count = 0
        for node in tree:
            if node.get("type") != "blob":
                continue
            path = node.get("path", "")
            ext = Path(path).suffix.lower()
            if include_exts and ext not in include_exts:
                continue
            if path_regex and not path_regex.search(path):
                continue
            raw_url = f"{RAW_GITHUB}/{owner}/{repo}/{ref}/{path}"
            out_path = target_dir / Path(path)
            ensure_dir(out_path.parent)
            try:
                out_path.write_bytes(fetch_bytes(raw_url, token=token))
                outputs.append(out_path)
                count += 1
                if count >= max_files:
                    break
            except Exception as e:
                log(f"[raw-skip] {raw_url}: {e}")
        log(f"[download] {source_id} downloaded {count} raw files")

    elif stype == "hf_file":
        repo_id, file_path = src["repo_id"], src["file_path"].lstrip("/")
        url = f"https://huggingface.co/datasets/{repo_id}/resolve/main/{file_path}?download=1"
        out_path = target_dir / Path(file_path).name
        log(f"[download] {source_id} <- {url}")
        out_path.write_bytes(fetch_bytes(url, token=token))
        outputs.append(out_path)

    elif stype == "generic_url":
        url = src["url"]
        out_path = target_dir / (Path(urlparse(url).path).name or "download.bin")
        log(f"[download] {source_id} <- {url}")
        out_path.write_bytes(fetch_bytes(url, token=token))
        outputs.append(out_path)

    elif stype == "site_crawl":
        outputs.extend(crawl_site_source(src, target_dir, token=token))

    else:
        raise ValueError(f"Unknown source type: {stype}")

    return outputs

def crawl_site_source(src: dict, target_dir: Path, token: Optional[str]) -> List[Path]:
    seed_urls = list(src.get("seed_urls", []))
    allowed_domains = set(src.get("allowed_domains", []))
    file_exts = tuple(src.get("file_exts", [".puz", ".ipuz", ".json", ".xd", ".html", ".htm", ".js"]))
    max_pages = int(src.get("max_pages", 100))
    max_files = int(src.get("max_files", 500))

    queue = list(seed_urls)
    seen = set()
    files: List[Path] = []
    pages = 0

    while queue and pages < max_pages and len(files) < max_files:
        url = queue.pop(0)
        if url in seen:
            continue
        seen.add(url)
        try:
            data = fetch_bytes(url, token=token)
        except Exception as e:
            log(f"[crawl-skip] {url}: {e}")
            continue
        pages += 1
        parsed = urlparse(url)

        if url.lower().endswith(file_exts):
            fname = safe_name(parsed.path.strip("/")) or f"file_{len(files)}"
            out_path = target_dir / fname
            out_path.write_bytes(data)
            files.append(out_path)
            continue

        text = data.decode("utf-8", errors="ignore")
        ex = LinkExtractor()
        try:
            ex.feed(text)
        except Exception:
            pass

        for href in ex.links:
            absu = urljoin(url, href)
            pu = urlparse(absu)
            if pu.scheme not in {"http", "https"}:
                continue
            if allowed_domains and pu.netloc not in allowed_domains:
                continue
            if absu not in seen:
                queue.append(absu)

        if "exolve-begin" in text.lower():
            fname = safe_name(parsed.path.strip("/")) + ".html"
            out_path = target_dir / fname
            out_path.write_text(text, encoding="utf-8")
            files.append(out_path)
    return files

def extract_entries_from_rows(rows: List[str]) -> List[str]:
    entries = []
    h = len(rows)
    w = len(rows[0]) if rows else 0
    for r in range(h):
        for seg in rows[r].split("#"):
            e = norm_entry(seg)
            if len(e.replace(" ", "")) >= 3:
                entries.append(e)
    for c in range(w):
        col = "".join(rows[r][c] for r in range(h))
        for seg in col.split("#"):
            e = norm_entry(seg)
            if len(e.replace(" ", "")) >= 3:
                entries.append(e)
    return entries

def standardize_rows(rows: List[str]) -> Optional[List[str]]:
    rows2 = []
    widths = set()
    for row in rows:
        row = row.strip()
        if not row:
            continue
        row = row.replace(".", "#").replace("0", "#").upper()
        if not re.fullmatch(r"[A-Z#0-9]+", row):
            return None
        rows2.append(row)
        widths.add(len(row))
    if not rows2 or len(widths) != 1:
        return None
    return rows2

def parse_puz(path: Path) -> Optional[dict]:
    if PUZ is None:
        return None
    try:
        p = PUZ.read(str(path))
        width, height = p.width, p.height
        sol = p.solution
        rows = [sol[i*width:(i+1)*width].replace(".", "#").upper() for i in range(height)]
        rows = standardize_rows(rows)
        if not rows:
            return None
        return {
            "kind": "puzzle_full_grid",
            "title": getattr(p, "title", None),
            "author": getattr(p, "author", None),
            "rows": rows,
            "entries": sorted(set(extract_entries_from_rows(rows))),
        }
    except Exception:
        return None

def parse_ipuz_file(path: Path) -> Optional[dict]:
    if IPUZ is None:
        return None
    try:
        obj = IPUZ.read(str(path))
        return parse_ipuz_like(obj)
    except Exception:
        return None

def parse_ipuz_like(obj: dict) -> Optional[dict]:
    sol = obj.get("solution") or obj.get("grid")
    if not sol:
        return None
    rows = []
    try:
        if isinstance(sol, list) and sol and isinstance(sol[0], list):
            for row in sol:
                chars = []
                for cell in row:
                    if isinstance(cell, str):
                        chars.append("#" if cell in {"#", ".", "0"} else cell.upper())
                    elif isinstance(cell, dict):
                        value = cell.get("value") or cell.get("cell") or "#"
                        chars.append("#" if str(value) in {"#", ".", "0"} else str(value).upper())
                    elif isinstance(cell, int):
                        chars.append("#" if cell == 0 else str(cell))
                    else:
                        chars.append("#")
                rows.append("".join(chars))
        elif isinstance(sol, list) and all(isinstance(x, str) for x in sol):
            rows = [str(x).replace(".", "#").upper() for x in sol]
        rows = standardize_rows(rows)
        if not rows:
            return None
        return {
            "kind": "puzzle_full_grid",
            "title": obj.get("title") or obj.get("metadata", {}).get("title"),
            "author": obj.get("author") or obj.get("metadata", {}).get("author"),
            "rows": rows,
            "entries": sorted(set(extract_entries_from_rows(rows))),
        }
    except Exception:
        return None

def parse_nyt_json_like(obj: dict) -> Optional[dict]:
    if "grid" in obj:
        g = obj["grid"]
        size = obj.get("size", {})
        rows = []
        if isinstance(g, list) and g and all(isinstance(x, str) for x in g):
            if len(set(map(len, g))) == 1 and len(g) > 1:
                rows = [r.replace(".", "#").upper() for r in g]
            else:
                cols = size.get("cols")
                rows_n = size.get("rows")
                if cols and rows_n and len(g) == cols * rows_n:
                    for r in range(rows_n):
                        row = "".join("#" if str(g[r*cols+c]) in {".", "#", "0"} else str(g[r*cols+c]).upper()
                                      for c in range(cols))
                        rows.append(row)
        rows = standardize_rows(rows)
        if rows:
            return {
                "kind": "puzzle_full_grid",
                "title": obj.get("title"),
                "author": obj.get("author"),
                "date": obj.get("date"),
                "rows": rows,
                "entries": sorted(set(extract_entries_from_rows(rows))),
            }
    ans = obj.get("answers")
    if isinstance(ans, dict):
        entries = []
        for k in ("across", "down"):
            part = ans.get(k, [])
            if isinstance(part, list):
                entries.extend(norm_entry(x) for x in part if isinstance(x, str))
            elif isinstance(part, dict):
                entries.extend(norm_entry(v) for v in part.values() if isinstance(v, str))
        entries = [e for e in entries if len(e.replace(" ", "")) >= 3]
        if entries:
            return {
                "kind": "clue_answer_or_entries",
                "title": obj.get("title"),
                "author": obj.get("author"),
                "date": obj.get("date"),
                "entries": sorted(set(entries)),
            }
    return None

def parse_exolve_text(text: str, title_fallback: Optional[str] = None) -> Optional[dict]:
    blocks = EXOLVE_BLOCK_RE.findall(text)
    if not blocks:
        return None
    for block in blocks:
        title = title_fallback
        tm = re.search(r'^\s*exolve-title:\s*(.+)$', block, flags=re.MULTILINE | re.IGNORECASE)
        if tm:
            title = tm.group(1).strip()
        width_m = re.search(r'^\s*exolve-width:\s*(\d+)\s*$', block, flags=re.MULTILINE | re.IGNORECASE)
        height_m = re.search(r'^\s*exolve-height:\s*(\d+)\s*$', block, flags=re.MULTILINE | re.IGNORECASE)
        grid_m = re.search(r'^\s*exolve-grid:\s*(.*?)(?:^\s*exolve-[a-z]|^\s*exolve-end)',
                           block, flags=re.DOTALL | re.MULTILINE | re.IGNORECASE)
        if not grid_m:
            continue
        rows = []
        for line in grid_m.group(1).splitlines():
            line = line.strip()
            if re.fullmatch(r"[A-Za-z.#0-9]+", line):
                rows.append(line)
        rows = standardize_rows(rows)
        if not rows:
            continue
        if width_m and height_m:
            try:
                if len(rows) != int(height_m.group(1)) or len(rows[0]) != int(width_m.group(1)):
                    pass
            except Exception:
                pass
        return {
            "kind": "puzzle_full_grid",
            "title": title,
            "rows": rows,
            "entries": sorted(set(extract_entries_from_rows(rows))),
        }
    return None

def parse_json_objects_from_text(text: str) -> List[Any]:
    objs = []
    stripped = text.strip()
    if not stripped:
        return objs
    # normal JSON first
    try:
        obj = json.loads(stripped)
        objs.append(obj)
        return objs
    except Exception:
        pass
    # NDJSON / JSONL
    for line in text.splitlines():
        line = line.strip()
        if not line or not JSON_LINE_START.match(line):
            continue
        try:
            objs.append(json.loads(line))
        except Exception:
            continue
    return objs

def parse_json_or_jsonl_file(path: Path) -> List[dict]:
    text = path.read_text(encoding="utf-8", errors="ignore")
    out = []
    for obj in parse_json_objects_from_text(text):
        if isinstance(obj, dict):
            for parser in (parse_ipuz_like, parse_nyt_json_like):
                rec = parser(obj)
                if rec:
                    out.append(rec)
                    break
    return out

def parse_csv_entries(path: Path) -> List[str]:
    with path.open("r", encoding="utf-8", errors="ignore", newline="") as f:
        rdr = csv.reader(f)
        header = next(rdr, None)
        if not header:
            return []
        header_l = [str(h).strip().lower() for h in header]
        ans_idx = None
        for key in ("answer", "answers", "entry", "entries", "solution"):
            if key in header_l:
                ans_idx = header_l.index(key)
                break
        if ans_idx is None:
            return []
        out = []
        for row in rdr:
            if ans_idx < len(row):
                e = norm_entry(row[ans_idx])
                if len(e.replace(" ", "")) >= 3:
                    out.append(e)
        return out

def parse_text_wordlist(path: Path) -> List[str]:
    out = []
    with path.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            s = norm_entry(line.strip())
            if len(s.replace(" ", "")) >= 3:
                out.append(s)
    return out

def maybe_extract_nested_archive(path: Path, extract_root: Path) -> List[Path]:
    files = []
    try:
        if path.suffix.lower() == ".zip":
            dest = extract_root / (safe_name(path.stem) + "_nested")
            ensure_dir(dest)
            with zipfile.ZipFile(path, "r") as zf:
                zf.extractall(dest)
            files.append(dest)
        elif path.suffix.lower() in {".tgz", ".gz", ".tar"} or path.name.endswith(".tar.gz"):
            dest = extract_root / (safe_name(path.stem) + "_nested")
            ensure_dir(dest)
            mode = "r:gz" if path.name.endswith(".gz") or path.suffix.lower() == ".tgz" else "r"
            with tarfile.open(path, mode) as tf:
                tf.extractall(dest)
            files.append(dest)
    except Exception:
        pass
    return files

@dataclass
class HarvestStats:
    source_files: int = 0
    full_grids: int = 0
    entry_records: int = 0
    parse_failures: int = 0
    nested_archives_extracted: int = 0
    kinds: Dict[str, int] = None

    def __post_init__(self):
        if self.kinds is None:
            self.kinds = defaultdict(int)

def normalize_downloads(download_roots: List[Path], norm_dir: Path, extract_nested: bool) -> HarvestStats:
    ensure_dir(norm_dir)
    full_grid_path = norm_dir / "full_grids.jsonl"
    entry_path = norm_dir / "entries.jsonl"
    catalog_path = norm_dir / "catalog.jsonl"
    entries_counter: Counter[str] = Counter()
    seen_grid_hashes = set()
    stats = HarvestStats()

    fg = full_grid_path.open("w", encoding="utf-8")
    ep = entry_path.open("w", encoding="utf-8")
    cp = catalog_path.open("w", encoding="utf-8")

    def write_catalog(rec):
        cp.write(json.dumps(rec, ensure_ascii=False) + "\n")

    pending_roots = list(download_roots)

    while pending_roots:
        root = pending_roots.pop(0)
        files = [root] if root.is_file() else [p for p in root.rglob("*") if p.is_file()]
        for path in files:
            stats.source_files += 1
            suffix = path.suffix.lower()
            parsed_records: List[dict] = []

            try:
                if suffix == ".puz":
                    rec = parse_puz(path)
                    if rec:
                        parsed_records = [rec]
                elif suffix == ".ipuz":
                    rec = parse_ipuz_file(path) or next(iter(parse_json_or_jsonl_file(path)), None)
                    if rec:
                        parsed_records = [rec]
                elif suffix in {".json", ".jsonl", ".ndjson"}:
                    parsed_records = parse_json_or_jsonl_file(path)
                elif suffix in {".html", ".htm", ".xd", ".js", ".md"}:
                    text = path.read_text(encoding="utf-8", errors="ignore")
                    rec = parse_exolve_text(text, title_fallback=path.name)
                    if rec:
                        parsed_records = [rec]
                elif suffix == ".txt":
                    text = path.read_text(encoding="utf-8", errors="ignore")
                    rec = parse_exolve_text(text, title_fallback=path.name)
                    if rec:
                        parsed_records = [rec]
                    else:
                        words = parse_text_wordlist(path)
                        if words:
                            parsed_records = [{
                                "kind": "wordlist",
                                "entries": words,
                                "title": path.name,
                            }]
                elif suffix == ".csv":
                    words = parse_csv_entries(path)
                    if words:
                        parsed_records = [{
                            "kind": "clue_answer_csv",
                            "entries": words,
                            "title": path.name,
                        }]
                elif extract_nested and (suffix in {".zip", ".tgz", ".tar"} or path.name.endswith(".tar.gz")):
                    new_roots = maybe_extract_nested_archive(path, norm_dir / "_nested")
                    if new_roots:
                        pending_roots.extend(new_roots)
                        stats.nested_archives_extracted += len(new_roots)
                    continue
            except Exception:
                parsed_records = []

            if not parsed_records:
                stats.parse_failures += 1
                continue

            for parsed in parsed_records:
                kind = parsed["kind"]
                stats.kinds[kind] += 1
                entries = parsed.get("entries", [])
                if kind == "puzzle_full_grid":
                    rows = parsed.get("rows") or []
                    if not rows:
                        continue
                    grid_hash = sha256_bytes("\n".join(rows).encode("utf-8"))
                    if grid_hash in seen_grid_hashes:
                        continue
                    seen_grid_hashes.add(grid_hash)
                    out = dict(parsed)
                    out["path"] = str(path)
                    out["grid_hash"] = grid_hash
                    fg.write(json.dumps(out, ensure_ascii=False) + "\n")
                    stats.full_grids += 1
                    write_catalog({
                        "kind": kind,
                        "path": str(path),
                        "title": parsed.get("title"),
                        "entries_count": len(entries),
                    })
                    for w in entries:
                        entries_counter[w] += 1
                        ep.write(json.dumps({"entry": w, "source_path": str(path), "grid_hash": grid_hash}, ensure_ascii=False) + "\n")
                    stats.entry_records += len(entries)
                else:
                    if not entries:
                        continue
                    write_catalog({
                        "kind": kind,
                        "path": str(path),
                        "title": parsed.get("title"),
                        "entries_count": len(entries),
                    })
                    for w in entries:
                        entries_counter[w] += 1
                        ep.write(json.dumps({"entry": w, "source_path": str(path)}, ensure_ascii=False) + "\n")
                    stats.entry_records += len(entries)

    fg.close(); ep.close(); cp.close()

    entries_txt = norm_dir / "entries_unique.txt"
    entries_csv = norm_dir / "entry_frequency.csv"
    with entries_txt.open("w", encoding="utf-8") as f:
        for w in sorted(entries_counter):
            f.write(w + "\n")
    with entries_csv.open("w", encoding="utf-8", newline="") as f:
        wr = csv.writer(f)
        wr.writerow(["entry", "count"])
        for w, c in entries_counter.most_common():
            wr.writerow([w, c])

    summary = {
        "source_files": stats.source_files,
        "full_grids": stats.full_grids,
        "entry_records": stats.entry_records,
        "unique_entries": len(entries_counter),
        "parse_failures": stats.parse_failures,
        "nested_archives_extracted": stats.nested_archives_extracted,
        "puz_support": PUZ is not None,
        "ipuz_support": IPUZ is not None,
        "kinds": dict(stats.kinds),
    }
    (norm_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return stats

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", type=Path, default=None)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--include-risky", action="store_true")
    ap.add_argument("--download-only", action="store_true")
    ap.add_argument("--extract-nested", action="store_true", help="Extract nested zip/tar archives found inside downloaded repos")
    ap.add_argument("--github-token", type=str, default=os.environ.get("GITHUB_TOKEN"))
    args = ap.parse_args()

    out_dir = args.out
    raw_dir = out_dir / "raw"
    norm_dir = out_dir / "normalized"
    ensure_dir(out_dir); ensure_dir(raw_dir); ensure_dir(norm_dir)

    manifest = load_manifest(args.manifest, out_dir)
    download_roots: List[Path] = []

    for src in iter_enabled_sources(manifest, include_risky=args.include_risky):
        try:
            download_roots.extend(download_source(src, raw_dir, token=args.github_token))
        except HTTPError as e:
            log(f"[error] {src['id']}: HTTP {e.code}")
        except URLError as e:
            log(f"[error] {src['id']}: {e}")
        except Exception as e:
            log(f"[error] {src['id']}: {e}")

    if args.download_only:
        print(json.dumps({"download_roots": [str(p) for p in download_roots]}, indent=2))
        return

    stats = normalize_downloads(download_roots, norm_dir, extract_nested=args.extract_nested)
    print(json.dumps({
        "out": str(out_dir),
        "download_roots": [str(p) for p in download_roots],
        "summary_file": str(norm_dir / "summary.json"),
        "full_grids_file": str(norm_dir / "full_grids.jsonl"),
        "entries_file": str(norm_dir / "entries_unique.txt"),
        "entry_frequency_file": str(norm_dir / "entry_frequency.csv"),
        "puz_support": PUZ is not None,
        "ipuz_support": IPUZ is not None,
        "stats": asdict(stats),
    }, indent=2))

if __name__ == "__main__":
    main()
