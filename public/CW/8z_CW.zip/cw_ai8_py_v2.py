#!/usr/bin/env python3
import argparse, json, math, os, re, time
from collections import defaultdict, deque, Counter
from typing import Dict, Set, List, Optional

MASKS = {
    'dense9_a': [
        '......###',
        '......###',
        '.......##',
        '....#....',
        '...###...',
        '....#....',
        '##.......',
        '###......',
        '###......',
    ]
}

BASE_WEIRD_WORDS = {'EEO', 'DPI', 'TRUG', 'INRI', 'ETA', 'PTA', 'SETT', 'SLAG', 'HEDGER'}


class SolverV2:
    def __init__(
        self,
        source_path: str,
        mask_name: str = 'dense9_a',
        quality_seconds: float = 20.0,
        trace_max: int = 300,
        quality_profile: str = 'balanced',
        banned_words: Optional[Set[str]] = None,
    ):
        with open(source_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        self.source_path = source_path
        self.lang = data.get('lang', 'en')
        self.source_name = data.get('source', source_path)
        self.bylen = {int(k): list(v) for k, v in data['words'].items()}
        for l, arr in self.bylen.items():
            arr.sort(key=lambda x: (-(x.get('s', 0)), -(1 if x.get('h') else 0), x['w']))
        self.words_by_len = {l: [x['w'] for x in arr] for l, arr in self.bylen.items()}
        self.mask_name = mask_name
        self.mask = MASKS[mask_name]
        self.R = len(self.mask)
        self.C = len(self.mask[0])
        self.slots = self.build_slots()
        self.nbrs = {s['id']: set(sid2 for _, sid2, _ in s['cross']) for s in self.slots}
        self.allsets = {l: set(range(len(arr))) for l, arr in self.words_by_len.items()}
        self.quality_seconds = quality_seconds
        self.trace_max = trace_max
        self.quality_profile = quality_profile
        self.banned_words = {w.upper() for w in (banned_words or set())}

        self.start = 0.0
        self.nodes = 0
        self.best_quality = -10**18
        self.best_assigned: Optional[Dict[int, int]] = None
        self.best_partial_depth = 0
        self.best_partial_assigned: Optional[Dict[int, int]] = None
        self.trace: List[dict] = []
        self.rejections = Counter()
        self.letter_pos_freq = self.build_letter_pos_freq()
        self.first_solved_at: Optional[float] = None

    def build_slots(self) -> List[dict]:
        slots = []
        for orient in 'AD':
            if orient == 'A':
                for r in range(self.R):
                    c = 0
                    while c < self.C:
                        if self.mask[r][c] != '#' and (c == 0 or self.mask[r][c - 1] == '#'):
                            c2 = c
                            while c2 < self.C and self.mask[r][c2] != '#':
                                c2 += 1
                            if c2 - c >= 3:
                                slots.append({'id': len(slots), 'o': 'A', 'cells': [(r, cc) for cc in range(c, c2)], 'len': c2 - c})
                            c = c2
                        else:
                            c += 1
            else:
                for c in range(self.C):
                    r = 0
                    while r < self.R:
                        if self.mask[r][c] != '#' and (r == 0 or self.mask[r - 1][c] == '#'):
                            r2 = r
                            while r2 < self.R and self.mask[r2][c] != '#':
                                r2 += 1
                            if r2 - r >= 3:
                                slots.append({'id': len(slots), 'o': 'D', 'cells': [(rr, c) for rr in range(r, r2)], 'len': r2 - r})
                            r = r2
                        else:
                            r += 1
        cellmap = defaultdict(list)
        for s in slots:
            for pos, cell in enumerate(s['cells']):
                cellmap[cell].append((s['id'], pos))
        for s in slots:
            cross = []
            for pos, cell in enumerate(s['cells']):
                for sid2, pos2 in cellmap[cell]:
                    if sid2 != s['id']:
                        cross.append((pos, sid2, pos2))
            s['cross'] = cross
        return slots

    def build_letter_pos_freq(self):
        freq = defaultdict(lambda: defaultdict(Counter))
        for l, arr in self.bylen.items():
            for meta in arr:
                w = meta['w']
                weight = 1.0 + max(0.0, meta.get('s', 0) / 100.0)
                if meta.get('h'):
                    weight += 0.35
                for i, ch in enumerate(w):
                    freq[l][i][ch] += weight
        return freq

    def log(self, event: str, force: bool = False, **payload):
        if len(self.trace) >= self.trace_max and not force:
            return
        item = {'t': round(time.time() - self.start, 4), 'event': event}
        item.update(payload)
        self.trace.append(item)

    def weird_penalty(self, meta: dict) -> float:
        w = meta['w']
        h = meta.get('h', '')
        p = 0.0
        weird_words = set(BASE_WEIRD_WORDS)
        weird_words.update(self.banned_words)
        if not h:
            p += 18.0
        vowels = sum(ch in 'AEIOUY' for ch in w)
        if len(w) <= 4 and vowels <= 1:
            p += 12.0
        if re.search(r'(.)\1\1', w):
            p += 8.0
        if len(set(w)) <= 2:
            p += 8.0
        if w in weird_words:
            p += 22.0
        if self.quality_profile == 'clean':
            if len(w) <= 4 and not h:
                p += 10.0
            if len(w) == 3 and w.endswith('A') and not h:
                p += 4.0
        return p

    def lexical_quality(self, meta: dict) -> float:
        w = meta['w']
        score = meta.get('s', 0) + (14 if meta.get('h') else 0)
        score -= self.weird_penalty(meta)
        score += 4.0 * len(set(w)) / len(w)
        pos_support = 0.0
        for i, ch in enumerate(w):
            pos_support += self.letter_pos_freq[len(w)][i][ch]
        score += 0.04 * pos_support / max(1, len(w))
        return score

    def make_board(self, assigned: Dict[int, int]) -> List[str]:
        board = [list(r) for r in self.mask]
        for sid, idx in assigned.items():
            slot = self.slots[sid]
            w = self.words_by_len[slot['len']][idx]
            for (r, c), ch in zip(slot['cells'], w):
                board[r][c] = ch
        return [''.join(r) for r in board]

    def solution_quality(self, assigned: Dict[int, int]) -> float:
        return sum(self.lexical_quality(self.bylen[self.slots[sid]['len']][idx]) for sid, idx in assigned.items())

    def solution_metrics(self, assigned: Dict[int, int]) -> dict:
        words = [self.bylen[self.slots[sid]['len']][idx] for sid, idx in assigned.items()]
        ugly = []
        hinted = 0
        score_sum = 0.0
        for meta in words:
            score_sum += meta.get('s', 0)
            if meta.get('h'):
                hinted += 1
            if self.weird_penalty(meta) >= 22:
                ugly.append(meta['w'])
        return {
            'word_count': len(words),
            'hinted_count': hinted,
            'hinted_ratio': round(hinted / max(1, len(words)), 4),
            'avg_source_score': round(score_sum / max(1, len(words)), 2),
            'ugly_words': sorted(set(ugly)),
            'ugly_count': len(set(ugly)),
        }

    def consistent_domain(self, slot, domains, assigned, used):
        sid = slot['id']
        if sid in assigned:
            return {assigned[sid]}
        arr = self.words_by_len[slot['len']]
        out = set()
        for idx in domains[sid]:
            w = arr[idx]
            if w in used or w in self.banned_words:
                continue
            ok = True
            for pos, sid2, pos2 in slot['cross']:
                if sid2 in assigned:
                    if w[pos] != self.words_by_len[self.slots[sid2]['len']][assigned[sid2]][pos2]:
                        ok = False
                        break
            if ok:
                out.add(idx)
        return out

    def revise(self, domains, xi, xj, used, assigned):
        crosses = [(pi, pj) for pi, sid2, pj in self.slots[xi]['cross'] if sid2 == xj]
        if not crosses:
            return False
        dom_i = self.consistent_domain(self.slots[xi], domains, assigned, used)
        dom_j = self.consistent_domain(self.slots[xj], domains, assigned, used)
        if not dom_i or not dom_j:
            domains[xi] = set()
            return True
        arr_i = self.words_by_len[self.slots[xi]['len']]
        arr_j = self.words_by_len[self.slots[xj]['len']]
        support = []
        for pi, pj in crosses:
            letters = set(arr_j[j][pj] for j in dom_j)
            support.append((pi, letters))
        rem = {i for i in dom_i if any(arr_i[i][pi] not in letters for pi, letters in support)}
        if rem:
            domains[xi] = dom_i - rem
            return True
        domains[xi] = dom_i
        return False

    def ac3(self, domains, used, assigned):
        q = deque((xi, xj) for xi in range(len(self.slots)) for xj in self.nbrs[xi])
        while q:
            xi, xj = q.popleft()
            if self.revise(domains, xi, xj, used, assigned):
                if not domains[xi]:
                    self.rejections['ac3_empty'] += 1
                    return False
                for xk in self.nbrs[xi] - {xj}:
                    q.append((xk, xi))
        return True

    def choose_slot(self, domains, assigned, used):
        best_sid = None
        best_key = None
        for slot in self.slots:
            sid = slot['id']
            if sid in assigned:
                continue
            dom = self.consistent_domain(slot, domains, assigned, used)
            domains[sid] = dom
            filled = sum(1 for _, sid2, _ in slot['cross'] if sid2 in assigned)
            key = (len(dom), -filled, -slot['len'])
            if best_key is None or key < best_key:
                best_key = key
                best_sid = sid
        return best_sid

    def support_count(self, other_sid, pos_needed, ch, domains, assigned, used):
        other = self.slots[other_sid]
        arr = self.words_by_len[other['len']]
        cnt = 0
        for j in self.consistent_domain(other, domains, assigned, used):
            if arr[j][pos_needed] == ch:
                cnt += 1
        return cnt

    def order_candidates(self, sid, domains, assigned, used):
        slot = self.slots[sid]
        dom = self.consistent_domain(slot, domains, assigned, used)
        scored = []
        preview = []
        for idx in dom:
            meta = self.bylen[slot['len']][idx]
            w = meta['w']
            val = self.lexical_quality(meta)
            minsup = 999999
            total = 0
            zero = False
            forced = 0
            for pos, sid2, pos2 in slot['cross']:
                if sid2 in assigned:
                    continue
                cnt = self.support_count(sid2, pos2, w[pos], domains, assigned, used)
                if cnt == 0:
                    zero = True
                    break
                if cnt == 1:
                    forced += 1
                total += cnt
                minsup = min(minsup, cnt)
            if zero:
                self.rejections['zero_support'] += 1
                continue
            val += 3 * math.log(total + 1) + 2 * math.log(minsup + 1) + 1.5 * forced
            scored.append((val, idx, minsup, total, forced))
        scored.sort(reverse=True)
        depth = len(assigned)
        topn = 80 if depth < 10 else 120
        top = scored[:topn]
        for val, idx, minsup, total, forced in top[:5]:
            preview.append({
                'w': self.bylen[slot['len']][idx]['w'],
                'rank_score': round(val, 2),
                'minsup': minsup,
                'support_total': total,
                'forced': forced,
            })
        self.log('slot_choice', depth=depth, sid=sid, orient=slot['o'], length=slot['len'], domain=len(dom), top=preview)
        return [idx for _, idx, _, _, _ in top]

    def search(self, domains, assigned, used):
        self.nodes += 1
        if len(assigned) > self.best_partial_depth:
            self.best_partial_depth = len(assigned)
            self.best_partial_assigned = dict(assigned)
            self.log('best_partial', depth=self.best_partial_depth)
        if len(assigned) == len(self.slots):
            q = self.solution_quality(assigned)
            if self.first_solved_at is None:
                self.first_solved_at = time.time() - self.start
            if q > self.best_quality:
                self.best_quality = q
                self.best_assigned = dict(assigned)
                self.log('solved', force=True, quality=round(q, 2))
            return False
        if time.time() - self.start > self.quality_seconds:
            self.log('budget_stop', force=True, depth=len(assigned))
            return True

        sid = self.choose_slot(domains, assigned, used)
        if sid is None or not domains[sid]:
            self.rejections['empty_domain'] += 1
            return False
        for idx in self.order_candidates(sid, domains, assigned, used):
            w = self.words_by_len[self.slots[sid]['len']][idx]
            if w in used:
                self.rejections['reuse_word'] += 1
                continue
            d2 = {k: set(v) for k, v in domains.items()}
            a2 = dict(assigned)
            u2 = set(used)
            a2[sid] = idx
            u2.add(w)
            d2[sid] = {idx}
            self.log('assign', depth=len(assigned), sid=sid, word=w)
            ok = True
            for pos, sid2, pos2 in self.slots[sid]['cross']:
                if sid2 in a2:
                    continue
                arr2 = self.words_by_len[self.slots[sid2]['len']]
                dom2 = {j for j in self.consistent_domain(self.slots[sid2], d2, a2, u2) if arr2[j][pos2] == w[pos]}
                d2[sid2] = dom2
                if not dom2:
                    ok = False
                    self.rejections['cross_empty'] += 1
                    self.log('reject_cross_empty', depth=len(assigned), sid=sid, word=w, other=sid2)
                    break
            if not ok:
                continue
            if not self.ac3(d2, u2, a2):
                self.log('reject_ac3', depth=len(assigned), sid=sid, word=w)
                continue
            if self.search(d2, a2, u2):
                return True
            self.log('backtrack', depth=len(assigned), sid=sid, word=w)
        return False

    def run(self):
        domains = {s['id']: set(self.allsets[s['len']]) for s in self.slots}
        assigned, used = {}, set()
        if not self.ac3(domains, used, assigned):
            raise RuntimeError('Initial AC-3 failed.')
        self.start = time.time()
        self.search(domains, assigned, used)
        solved = self.best_assigned is not None
        final_assigned = self.best_assigned if solved else self.best_partial_assigned or {}
        board = self.make_board(final_assigned)
        slot_words = []
        for sid, idx in sorted(final_assigned.items()):
            meta = self.bylen[self.slots[sid]['len']][idx]
            slot_words.append({
                'sid': sid,
                'orient': self.slots[sid]['o'],
                'len': self.slots[sid]['len'],
                'word': meta['w'],
                'hint': meta.get('h', ''),
                'score': meta.get('s', 0),
                'quality': round(self.lexical_quality(meta), 2),
            })
        return {
            'engine': 'cw_ai8_py_v2',
            'mask_name': self.mask_name,
            'lang': self.lang,
            'source': self.source_name,
            'solved': solved,
            'seconds': round(time.time() - self.start, 3),
            'nodes': self.nodes,
            'best_partial_depth': self.best_partial_depth,
            'solution_quality': round(self.best_quality, 2) if solved else None,
            'first_solved_at': round(self.first_solved_at, 3) if self.first_solved_at is not None else None,
            'quality_profile': self.quality_profile,
            'banned_words': sorted(self.banned_words),
            'metrics': self.solution_metrics(final_assigned),
            'rejections': dict(self.rejections),
            'board': board,
            'slot_words': slot_words,
            'trace': self.trace,
        }


def parse_banned_words(raw: str) -> Set[str]:
    if not raw:
        return set()
    return {x.strip().upper() for x in raw.split(',') if x.strip()}


def main():
    ap = argparse.ArgumentParser(description='Python exact-CSP crossword engine v2 with trace-grounded logging.')
    ap.add_argument('--source', required=True)
    ap.add_argument('--mask', default='dense9_a', choices=sorted(MASKS))
    ap.add_argument('--quality-seconds', type=float, default=20.0)
    ap.add_argument('--quality-profile', choices=['balanced', 'clean'], default='balanced')
    ap.add_argument('--trace-max', type=int, default=300)
    ap.add_argument('--ban-words', default='', help='Comma-separated words to ban for this solve.')
    ap.add_argument('--out', default='')
    args = ap.parse_args()

    solver = SolverV2(
        args.source,
        mask_name=args.mask,
        quality_seconds=args.quality_seconds,
        trace_max=args.trace_max,
        quality_profile=args.quality_profile,
        banned_words=parse_banned_words(args.ban_words),
    )
    result = solver.run()
    print('[cw_ai8_py_v2] solved=', result['solved'], 'seconds=', result['seconds'], 'nodes=', result['nodes'])
    for row in result['board']:
        print(row)
    if result['solved']:
        print('solution_quality=', result['solution_quality'])
    print('metrics=', json.dumps(result['metrics'], ensure_ascii=False))
    if args.out:
        out_dir = os.path.dirname(args.out)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        with open(args.out, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)


if __name__ == '__main__':
    main()
