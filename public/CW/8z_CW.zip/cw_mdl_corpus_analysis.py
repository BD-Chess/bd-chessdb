#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import random
import re
import statistics
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

WORD_RE = re.compile(r'^[A-Z]+$')


def lz76_complexity(seq: str) -> int:
    """LZ76 phrase count; lower = more compressible/structured."""
    if not seq:
        return 0
    n = len(seq)
    i = 0
    c = 0
    dictionary = set()
    while i < n:
        l = 1
        while i + l <= n and seq[i:i + l] in dictionary:
            l += 1
        dictionary.add(seq[i:i + l])
        c += 1
        i += l
    return c


def normalize_word(word: str) -> str:
    word = (word or '').upper().strip()
    word = re.sub(r'[^A-Z]', '', word)
    return word


def standardize_rows(rows: list[str]) -> list[str]:
    rows2 = []
    for r in rows:
        r2 = ''.join('#' if ch == '#' else normalize_word(ch) if len(ch) == 1 else ch for ch in r)
        r2 = r2.upper()
        # keep only A-Z and # at char level
        clean = ''.join(ch if ch == '#' or ('A' <= ch <= 'Z') else '#' for ch in r2)
        rows2.append(clean)
    widths = {len(r) for r in rows2 if r}
    if not rows2 or len(widths) != 1:
        raise ValueError('rows have inconsistent widths')
    return rows2


def extract_entries_from_rows(rows: list[str]) -> list[str]:
    h = len(rows)
    w = len(rows[0])
    out: list[str] = []
    # across
    for r in range(h):
        c = 0
        while c < w:
            while c < w and rows[r][c] == '#':
                c += 1
            start = c
            while c < w and rows[r][c] != '#':
                c += 1
            if c - start >= 3:
                out.append(rows[r][start:c])
    # down
    for c in range(w):
        r = 0
        while r < h:
            while r < h and rows[r][c] == '#':
                r += 1
            start = r
            while r < h and rows[r][c] != '#':
                r += 1
            if r - start >= 3:
                out.append(''.join(rows[i][c] for i in range(start, r)))
    return out


def rowcol_serialization(rows: list[str]) -> str:
    h = len(rows)
    w = len(rows[0])
    row_str = '|'.join(r.replace('#', '') for r in rows)
    cols = []
    for c in range(w):
        cols.append(''.join(rows[r][c] for r in range(h) if rows[r][c] != '#'))
    return row_str + '||' + '|'.join(cols)


def word_serialization(entries: list[str]) -> str:
    return '|'.join(entries)


def mask_bitstring(rows: list[str]) -> str:
    return ''.join('1' if ch == '#' else '0' for row in rows for ch in row)


def crossing_positions(rows: list[str]) -> list[tuple[int, int, int, int, int, int]]:
    h = len(rows)
    w = len(rows[0])
    across_info = {}
    down_info = {}
    # across info per cell: (length, pos)
    for r in range(h):
        c = 0
        while c < w:
            while c < w and rows[r][c] == '#':
                c += 1
            s = c
            while c < w and rows[r][c] != '#':
                c += 1
            if c - s >= 3:
                L = c - s
                for j in range(L):
                    across_info[(r, s + j)] = (L, j)
    # down info per cell: (length, pos)
    for c in range(w):
        r = 0
        while r < h:
            while r < h and rows[r][c] == '#':
                r += 1
            s = r
            while r < h and rows[r][c] != '#':
                r += 1
            if r - s >= 3:
                L = r - s
                for i in range(L):
                    down_info[(s + i, c)] = (L, i)
    out = []
    for key in across_info.keys() & down_info.keys():
        (a_len, a_pos), (d_len, d_pos) = across_info[key], down_info[key]
        out.append((key[0], key[1], a_len, a_pos, d_len, d_pos))
    return out


@dataclass
class CorpusStats:
    entry_freq: Counter
    by_len_total: dict[int, int]
    pos_letter_freq: dict[int, list[Counter]]
    global_letter_freq: Counter


def build_corpus_stats(entry_frequency_paths: list[Path]) -> CorpusStats:
    entry_freq: Counter[str] = Counter()
    for p in entry_frequency_paths:
        with p.open('r', encoding='utf-8', newline='') as f:
            reader = csv.DictReader(f)
            # expected columns: entry, count
            for row in reader:
                word = normalize_word(row.get('entry', ''))
                if not WORD_RE.match(word):
                    continue
                cnt = int(float(row.get('count', '1') or '1'))
                entry_freq[word] += cnt
    by_len_total: dict[int, int] = Counter()
    pos_letter_freq: dict[int, list[Counter]] = {}
    global_letter_freq: Counter[str] = Counter()
    for word, cnt in entry_freq.items():
        L = len(word)
        by_len_total[L] += cnt
        if L not in pos_letter_freq:
            pos_letter_freq[L] = [Counter() for _ in range(L)]
        for i, ch in enumerate(word):
            pos_letter_freq[L][i][ch] += cnt
            global_letter_freq[ch] += cnt
    if not global_letter_freq:
        global_letter_freq.update({ch: 1 for ch in 'ETAOINSHRDLU'})
    return CorpusStats(entry_freq, dict(by_len_total), pos_letter_freq, global_letter_freq)


def crossing_entropy(rows: list[str], stats: CorpusStats) -> float:
    total = 0.0
    for r, c, a_len, a_pos, d_len, d_pos in crossing_positions(rows):
        ch = rows[r][c]
        a_total = max(1, stats.by_len_total.get(a_len, 1))
        d_total = max(1, stats.by_len_total.get(d_len, 1))
        a_freq = stats.pos_letter_freq.get(a_len, [])
        d_freq = stats.pos_letter_freq.get(d_len, [])
        pa = (a_freq[a_pos][ch] / a_total) if a_pos < len(a_freq) else 1e-6
        pd = (d_freq[d_pos][ch] / d_total) if d_pos < len(d_freq) else 1e-6
        p = max(1e-6, min(pa, pd))
        total += -math.log2(p)
    return total


def avg_entry_surprisal(entries: list[str], stats: CorpusStats) -> float:
    vals = []
    total = sum(stats.entry_freq.values()) or 1
    for w in entries:
        cnt = stats.entry_freq.get(w, 0)
        p = max(cnt / total, 1e-12)
        vals.append(-math.log2(p))
    return statistics.mean(vals) if vals else 0.0


def shuffle_control(rows: list[str], rng: random.Random) -> list[str]:
    letters = [ch for row in rows for ch in row if ch != '#']
    rng.shuffle(letters)
    it = iter(letters)
    out = []
    for row in rows:
        out.append(''.join('#' if ch == '#' else next(it) for ch in row))
    return out


def freq_weighted_control(rows: list[str], stats: CorpusStats, rng: random.Random) -> list[str]:
    letters, weights = zip(*sorted(stats.global_letter_freq.items()))
    out = []
    for row in rows:
        chars = []
        for ch in row:
            if ch == '#':
                chars.append('#')
            else:
                chars.append(rng.choices(letters, weights=weights, k=1)[0])
        out.append(''.join(chars))
    return out


def serial_metrics(rows: list[str], stats: CorpusStats) -> dict[str, float]:
    entries = extract_entries_from_rows(rows)
    return {
        'mask_lz': lz76_complexity(mask_bitstring(rows)),
        'rowcol_lz': lz76_complexity(rowcol_serialization(rows)),
        'word_lz': lz76_complexity(word_serialization(entries)),
        'cross_entropy': crossing_entropy(rows, stats),
        'avg_entry_surprisal': avg_entry_surprisal(entries, stats),
        'entry_count': len(entries),
    }


def safe_mean(vals: list[float]) -> float:
    return round(statistics.mean(vals), 6) if vals else 0.0


def safe_median(vals: list[float]) -> float:
    return round(statistics.median(vals), 6) if vals else 0.0


def collect_corpus_paths(root: Path) -> tuple[list[Path], list[Path]]:
    full_grid_paths = []
    entry_freq_paths = []
    if root.is_file() and root.name.endswith('full_grids.jsonl'):
        full_grid_paths.append(root)
    elif root.is_dir():
        for p in root.rglob('full_grids.jsonl'):
            full_grid_paths.append(p)
        for p in root.rglob('entry_frequency.csv'):
            entry_freq_paths.append(p)
    return full_grid_paths, entry_freq_paths


def iter_full_grids(paths: list[Path]) -> Iterable[dict]:
    for p in paths:
        with p.open('r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except Exception:
                    continue
                rows = obj.get('rows')
                if not rows:
                    continue
                try:
                    obj['rows'] = standardize_rows(rows)
                except Exception:
                    continue
                yield obj


def make_weight_suggestions(per_grid: list[dict]) -> dict[str, float]:
    # Use average separation against weighted-random control as a practical starter.
    comps = {
        'rowcol_lz': [],
        'word_lz': [],
        'cross_entropy': [],
        'avg_entry_surprisal': [],
    }
    for g in per_grid:
        comps['rowcol_lz'].append(g['freq_delta_rowcol_lz'])
        comps['word_lz'].append(g['freq_delta_word_lz'])
        comps['cross_entropy'].append(g['freq_delta_cross_entropy'])
        comps['avg_entry_surprisal'].append(g['freq_delta_entry_surprisal'])
    raw = {k: max(0.0, safe_mean(v)) for k, v in comps.items()}
    total = sum(raw.values()) or 1.0
    norm = {k: round(v / total, 4) for k, v in raw.items()}
    return norm


def main() -> None:
    ap = argparse.ArgumentParser(description='Analyze crossword corpora for MDL×DCC compression signals.')
    ap.add_argument('--roots', nargs='*', default=['cw_corpus', 'cw_corpus_v2'], help='Corpus roots or direct full_grids.jsonl files')
    ap.add_argument('--outdir', default='out/cw_mdl_analysis', help='Output directory')
    ap.add_argument('--seed', type=int, default=42)
    args = ap.parse_args()

    roots = [Path(x) for x in args.roots]
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    full_grid_paths: list[Path] = []
    entry_freq_paths: list[Path] = []
    for root in roots:
        fg, ef = collect_corpus_paths(root)
        full_grid_paths.extend(fg)
        entry_freq_paths.extend(ef)

    # de-dup path list while preserving order
    full_grid_paths = list(dict.fromkeys(full_grid_paths))
    entry_freq_paths = list(dict.fromkeys(entry_freq_paths))

    if not entry_freq_paths:
        raise SystemExit('No entry_frequency.csv found in the provided roots.')

    stats = build_corpus_stats(entry_freq_paths)
    rng = random.Random(args.seed)

    grids = list(iter_full_grids(full_grid_paths))
    per_grid = []

    for idx, obj in enumerate(grids, start=1):
        rows = obj['rows']
        entries = extract_entries_from_rows(rows)
        real = serial_metrics(rows, stats)
        shuf_rows = shuffle_control(rows, rng)
        shuf = serial_metrics(shuf_rows, stats)
        freq_rows = freq_weighted_control(rows, stats, rng)
        freq = serial_metrics(freq_rows, stats)
        per_grid.append({
            'index': idx,
            'path': obj.get('path', ''),
            'title': obj.get('title', ''),
            'author': obj.get('author', ''),
            'height': len(rows),
            'width': len(rows[0]),
            'entry_count': len(entries),
            'real_mask_lz': real['mask_lz'],
            'real_rowcol_lz': real['rowcol_lz'],
            'real_word_lz': real['word_lz'],
            'real_cross_entropy': round(real['cross_entropy'], 6),
            'real_avg_entry_surprisal': round(real['avg_entry_surprisal'], 6),
            'shuffle_rowcol_lz': shuf['rowcol_lz'],
            'shuffle_word_lz': shuf['word_lz'],
            'shuffle_cross_entropy': round(shuf['cross_entropy'], 6),
            'shuffle_avg_entry_surprisal': round(shuf['avg_entry_surprisal'], 6),
            'freq_rowcol_lz': freq['rowcol_lz'],
            'freq_word_lz': freq['word_lz'],
            'freq_cross_entropy': round(freq['cross_entropy'], 6),
            'freq_avg_entry_surprisal': round(freq['avg_entry_surprisal'], 6),
            'shuffle_delta_rowcol_lz': shuf['rowcol_lz'] - real['rowcol_lz'],
            'shuffle_delta_word_lz': shuf['word_lz'] - real['word_lz'],
            'shuffle_delta_cross_entropy': round(shuf['cross_entropy'] - real['cross_entropy'], 6),
            'shuffle_delta_entry_surprisal': round(shuf['avg_entry_surprisal'] - real['avg_entry_surprisal'], 6),
            'freq_delta_rowcol_lz': freq['rowcol_lz'] - real['rowcol_lz'],
            'freq_delta_word_lz': freq['word_lz'] - real['word_lz'],
            'freq_delta_cross_entropy': round(freq['cross_entropy'] - real['cross_entropy'], 6),
            'freq_delta_entry_surprisal': round(freq['avg_entry_surprisal'] - real['avg_entry_surprisal'], 6),
            'real_beats_shuffle_rowcol': int(real['rowcol_lz'] < shuf['rowcol_lz']),
            'real_beats_shuffle_word': int(real['word_lz'] < shuf['word_lz']),
            'real_beats_freq_rowcol': int(real['rowcol_lz'] < freq['rowcol_lz']),
            'real_beats_freq_word': int(real['word_lz'] < freq['word_lz']),
        })

    summary = {
        'roots': [str(r) for r in roots],
        'full_grid_files_found': [str(p) for p in full_grid_paths],
        'entry_frequency_files_found': [str(p) for p in entry_freq_paths],
        'grid_count': len(per_grid),
        'entry_freq_count': len(stats.entry_freq),
        'avg_real_rowcol_lz': safe_mean([x['real_rowcol_lz'] for x in per_grid]),
        'avg_real_word_lz': safe_mean([x['real_word_lz'] for x in per_grid]),
        'avg_shuffle_delta_rowcol_lz': safe_mean([x['shuffle_delta_rowcol_lz'] for x in per_grid]),
        'avg_shuffle_delta_word_lz': safe_mean([x['shuffle_delta_word_lz'] for x in per_grid]),
        'avg_shuffle_delta_cross_entropy': safe_mean([x['shuffle_delta_cross_entropy'] for x in per_grid]),
        'avg_freq_delta_rowcol_lz': safe_mean([x['freq_delta_rowcol_lz'] for x in per_grid]),
        'avg_freq_delta_word_lz': safe_mean([x['freq_delta_word_lz'] for x in per_grid]),
        'avg_freq_delta_cross_entropy': safe_mean([x['freq_delta_cross_entropy'] for x in per_grid]),
        'avg_freq_delta_entry_surprisal': safe_mean([x['freq_delta_entry_surprisal'] for x in per_grid]),
        'real_beats_shuffle_rowcol_count': sum(x['real_beats_shuffle_rowcol'] for x in per_grid),
        'real_beats_shuffle_word_count': sum(x['real_beats_shuffle_word'] for x in per_grid),
        'real_beats_freq_rowcol_count': sum(x['real_beats_freq_rowcol'] for x in per_grid),
        'real_beats_freq_word_count': sum(x['real_beats_freq_word'] for x in per_grid),
        'weight_suggestions': make_weight_suggestions(per_grid),
        'interpretation': {
            'direction': 'Lower LZ / lower entropy / lower surprisal is better (more compressible, more crossword-natural).',
            'next_use': 'Use weight_suggestions as a start for MDL candidate ranking, then re-fit against engine closure results.',
        },
    }

    with (outdir / 'mdl_corpus_summary.json').open('w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    if per_grid:
        fieldnames = list(per_grid[0].keys())
        with (outdir / 'mdl_corpus_per_grid.csv').open('w', encoding='utf-8', newline='') as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            w.writerows(per_grid)

    # Useful extra output: positional letter stats for engine scoring.
    pos_stats_out = {}
    for L, counters in stats.pos_letter_freq.items():
        pos_stats_out[str(L)] = [{k: v for k, v in ctr.most_common()} for ctr in counters]
    with (outdir / 'mdl_positional_letter_stats.json').open('w', encoding='utf-8') as f:
        json.dump({
            'by_len_total': stats.by_len_total,
            'pos_letter_freq': pos_stats_out,
            'global_letter_freq': dict(stats.global_letter_freq.most_common()),
        }, f, ensure_ascii=False, indent=2)

    print('[cw_mdl_corpus_analysis] grids=', len(per_grid), 'outdir=', outdir)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
