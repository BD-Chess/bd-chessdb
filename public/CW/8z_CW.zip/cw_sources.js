'use strict';

const fs = require('fs');
const path = require('path');
const { normalizeWord, getLangPack, wordShapePenalty, commonnessBoost } = require('./cw_lang');

function parseArgsList(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value.filter(Boolean);
  return String(value)
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);
}

function loadJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function resolveSourcePath(sourcePath, baseDir = process.cwd()) {
  if (!sourcePath) return null;
  const candidates = [
    sourcePath,
    path.join(baseDir, sourcePath),
    path.join(baseDir, 'data', sourcePath),
    path.join(__dirname, sourcePath),
    path.join(__dirname, 'data', sourcePath),
  ];
  for (const c of candidates) {
    if (fs.existsSync(c)) return c;
  }
  return null;
}

function defaultSourceName(lang) {
  return `cw_${lang}_scored.json`;
}

function loadSourceFile(lang, sourcePath, baseDir = process.cwd()) {
  const resolved = resolveSourcePath(sourcePath || defaultSourceName(lang), baseDir);
  if (!resolved) {
    throw new Error(`Source file not found for lang=${lang}: ${sourcePath || defaultSourceName(lang)}`);
  }
  return { path: resolved, data: loadJson(resolved) };
}

function flattenWordBuckets(data, lang) {
  const pack = getLangPack(lang);
  const words = [];
  const buckets = data.words || {};
  let id = 0;
  for (const [lenKey, arr] of Object.entries(buckets)) {
    const len = Number(lenKey);
    for (const item of arr) {
      const w = normalizeWord(item.w, lang);
      if (!w || w.length !== len) continue;
      const baseScore = Number(item.s || item.score || 50);
      const shapePenalty = wordShapePenalty(w, lang);
      const vowelRatio = countVowels(w, pack.vowels) / w.length;
      const crossBase = initialCrossScore(w, lang, pack);
      words.push({
        id: id++,
        w,
        len,
        h: item.h || '',
        score: baseScore,
        tier: Number(item.t || 1),
        lang,
        topic: item.topic || null,
        tags: Array.isArray(item.tags) ? item.tags : [],
        age: item.age || null,
        freq: item.freq || null,
        shapePenalty,
        vowelRatio,
        crossBase,
        source: data.source || 'unknown',
      });
    }
  }
  return words;
}

function countVowels(word, vowels) {
  let n = 0;
  for (const ch of word) if (vowels.has(ch)) n++;
  return n;
}

function countRareLetters(word, lang) {
  const rareSets = {
    en: new Set('JQXZ'.split('')),
    sl: new Set('QWXY'.split('')),
  };
  const rare = rareSets[lang] || new Set();
  let n = 0;
  for (const ch of word) if (rare.has(ch)) n++;
  return n;
}

function consonantClusterPenalty(word, vowels) {
  let longest = 0;
  let run = 0;
  for (const ch of word) {
    if (vowels.has(ch)) run = 0;
    else {
      run += 1;
      if (run > longest) longest = run;
    }
  }
  if (longest <= 3) return 0;
  return (longest - 3) * 3;
}

function letterVarietyScore(word) {
  if (!word || !word.length) return 0;
  return new Set(word.split('')).size / word.length;
}

function initialCrossScore(word, lang, pack) {
  const vowel = countVowels(word, pack.vowels) / Math.max(1, word.length);
  const variety = letterVarietyScore(word);
  const common = commonnessBoost(word, pack);
  const rarePenalty = countRareLetters(word, lang) * 3.5;
  const clusterPenalty = consonantClusterPenalty(word, pack.vowels);
  const edgePenalty = Math.abs(0.42 - vowel) * 14;
  return common * 2.4 + variety * 18 - rarePenalty - clusterPenalty - edgePenalty;
}

function filterWords(words, opts = {}) {
  const includeTopics = new Set(parseArgsList(opts.includeTopics).map(x => x.toLowerCase()));
  const excludeTopics = new Set(parseArgsList(opts.excludeTopics).map(x => x.toLowerCase()));
  const ageProfile = opts.ageProfile ? String(opts.ageProfile).toLowerCase() : null;
  const minScore = Number(opts.minScore || 0);

  return words.filter(w => {
    if (w.score < minScore) return false;
    const tags = [w.topic, ...(w.tags || [])].filter(Boolean).map(x => String(x).toLowerCase());
    if (includeTopics.size && !tags.some(t => includeTopics.has(t))) return false;
    if (excludeTopics.size && tags.some(t => excludeTopics.has(t))) return false;
    if (ageProfile && w.age && String(w.age).toLowerCase() !== ageProfile) return false;
    return true;
  });
}


function crosswordTuneWords(words, opts = {}) {
  const lang = String(opts.lang || 'en').toLowerCase();
  const aggressive = !!opts.crosswordTune;
  const byLen = new Map();
  for (const w of words) {
    const lexical = w.score - w.shapePenalty + (w.crossBase || 0) - (w.tier > 1 ? 4 : 0);
    const tuned = { ...w, lexicalFit: lexical };
    if (!byLen.has(w.len)) byLen.set(w.len, []);
    byLen.get(w.len).push(tuned);
  }
  const out = [];
  for (const [length, arr] of byLen.entries()) {
    arr.sort((a, b) => b.lexicalFit - a.lexicalFit || b.score - a.score || a.w.localeCompare(b.w));
    let keep = arr;
    if (aggressive && lang === 'en' && arr.length > 600) {
      const frac = length <= 5 ? 0.9 : length <= 7 ? 0.78 : 0.62;
      const cap = length <= 5 ? 1200 : length <= 7 ? 950 : 650;
      const limit = Math.max(180, Math.min(cap, Math.floor(arr.length * frac)));
      keep = arr.slice(0, limit);
    }
    out.push(...keep);
  }
  return out;
}

function mergeSources(primary, extraWords = []) {
  const seen = new Set();
  const out = [];
  for (const w of [...primary, ...extraWords]) {
    const key = `${w.lang}:${w.w}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(w);
  }
  return out;
}

function buildIndex(words) {
  const byLen = new Map();
  const byWord = new Map();
  for (const w of words) {
    if (!byLen.has(w.len)) byLen.set(w.len, []);
    byLen.get(w.len).push(w);
    byWord.set(w.w, w);
  }

  const posIndex = new Map();
  const letterFreq = new Map();
  for (const [len, arr] of byLen.entries()) {
    const pmap = [];
    const freq = [];
    for (let p = 0; p < len; p++) { pmap[p] = new Map(); freq[p] = new Map(); }
    for (const word of arr) {
      for (let p = 0; p < len; p++) {
        const ch = word.w[p];
        if (!pmap[p].has(ch)) pmap[p].set(ch, []);
        pmap[p].get(ch).push(word);
        freq[p].set(ch, (freq[p].get(ch) || 0) + 1);
      }
    }
    const denom = Math.max(1, arr.length);
    for (const word of arr) {
      let posCommon = 0;
      for (let p = 0; p < len; p++) posCommon += (freq[p].get(word.w[p]) || 0) / denom;
      word.crossPotential = Number((posCommon / len).toFixed(4));
      word.lexicalFit = Number(((word.lexicalFit ?? (word.score - word.shapePenalty + (word.crossBase || 0))) + word.crossPotential * 14).toFixed(4));
    }
    for (let p = 0; p < len; p++) {
      for (const arr2 of pmap[p].values()) {
        arr2.sort((a, b) => (b.lexicalFit ?? b.score) - (a.lexicalFit ?? a.score) || b.score - a.score || a.shapePenalty - b.shapePenalty || a.w.localeCompare(b.w));
      }
    }
    letterFreq.set(len, freq);
    posIndex.set(len, pmap);
    arr.sort((a, b) => (b.lexicalFit ?? b.score) - (a.lexicalFit ?? a.score) || b.score - a.score || a.shapePenalty - b.shapePenalty || a.w.localeCompare(b.w));
  }

  return { words, byLen, byWord, posIndex, letterFreq };
}


function estimatePatternCount(index, len, pattern) {
  const arr = index.byLen.get(len) || [];
  if (!arr.length) return 0;
  const pmap = index.posIndex.get(len) || [];
  const known = [];
  for (let i = 0; i < pattern.length; i++) {
    const ch = pattern[i];
    if (ch && ch !== '?') known.push([i, ch]);
  }
  if (!known.length) return arr.length;
  let count = Infinity;
  for (const [pos, ch] of known) {
    const bucket = pmap[pos]?.get(ch);
    const n = bucket ? bucket.length : 0;
    if (n < count) count = n;
    if (count === 0) return 0;
  }
  return Number.isFinite(count) ? count : arr.length;
}


function suffixKey(word, n = 3) {
  return word.length <= n ? word : word.slice(-n);
}

function prefixKey(word, n = 3) {
  return word.length <= n ? word : word.slice(0, n);
}

function cvPattern(word, vowels) {
  let out = '';
  for (const ch of word) out += vowels.has(ch) ? 'V' : 'C';
  return out;
}

function diversifyWordPool(cands, maxCandidates, lang) {
  if (cands.length <= maxCandidates) return cands.slice();
  const pack = getLangPack(lang);
  const chosen = [];
  const suffixSeen = new Map();
  const prefixSeen = new Map();
  const shapeSeen = new Map();
  const bucket = new Map();
  for (const cand of cands) {
    const suf = suffixKey(cand.w, Math.min(4, Math.max(2, Math.floor(cand.w.length / 2))));
    const pre = prefixKey(cand.w, Math.min(3, Math.max(2, Math.floor(cand.w.length / 3))));
    const shp = cvPattern(cand.w, pack.vowels);
    const key = `${cand.len}|${suf}|${pre}|${shp}`;
    if (!bucket.has(key)) bucket.set(key, []);
    bucket.get(key).push(cand);
  }
  const orderedBuckets = [...bucket.values()].sort((a, b) => (b[0].fitScore || 0) - (a[0].fitScore || 0));
  while (chosen.length < maxCandidates) {
    let progressed = false;
    for (const arr of orderedBuckets) {
      while (arr.length) {
        const cand = arr.shift();
        const suf = suffixKey(cand.w, Math.min(4, Math.max(2, Math.floor(cand.w.length / 2))));
        const pre = prefixKey(cand.w, Math.min(3, Math.max(2, Math.floor(cand.w.length / 3))));
        const shp = cvPattern(cand.w, pack.vowels);
        const sN = suffixSeen.get(suf) || 0;
        const pN = prefixSeen.get(pre) || 0;
        const hN = shapeSeen.get(shp) || 0;
        if (sN >= 2 || pN >= 3 || hN >= Math.max(4, Math.floor(maxCandidates / 6))) continue;
        chosen.push(cand);
        suffixSeen.set(suf, sN + 1);
        prefixSeen.set(pre, pN + 1);
        shapeSeen.set(shp, hN + 1);
        progressed = true;
        break;
      }
      if (chosen.length >= maxCandidates) break;
    }
    if (!progressed) break;
  }
  if (chosen.length < maxCandidates) {
    const seen = new Set(chosen.map(x => x.w));
    for (const cand of cands) {
      if (seen.has(cand.w)) continue;
      chosen.push(cand);
      if (chosen.length >= maxCandidates) break;
    }
  }
  return chosen.slice(0, maxCandidates);
}

function getCandidates(index, slot, pattern, usedWords = new Set(), opts = {}) {
  const len = slot.len;
  const arr = index.byLen.get(len) || [];
  if (!arr.length) return [];
  const pmap = index.posIndex.get(len) || [];
  const known = [];
  for (let i = 0; i < pattern.length; i++) {
    const ch = pattern[i];
    if (ch && ch !== '?') known.push([i, ch]);
  }

  let pool = arr;
  if (known.length) {
    const lists = known
      .map(([pos, ch]) => pmap[pos]?.get(ch) || [])
      .sort((a, b) => a.length - b.length);
    pool = lists[0] || [];
    for (let i = 1; i < lists.length; i++) {
      const set = new Set(lists[i].map(w => w.w));
      pool = pool.filter(w => set.has(w.w));
      if (!pool.length) break;
    }
  }

  const themeWords = opts.themeWords || new Set();
  const maxCandidates = Number(opts.maxCandidates || 120);
  const openness = pattern.split('').filter(ch => ch === '?').length / Math.max(1, pattern.length);
  const rawLimit = Math.min(pool.length, Math.max(maxCandidates * (openness > 0.6 ? 8 : 5), known.length ? 220 : 320));
  const scored = [];
  for (const w of pool) {
    if (usedWords.has(w.w)) continue;
    let ok = true;
    for (let i = 0; i < pattern.length; i++) {
      const ch = pattern[i];
      if (ch !== '?' && ch !== w.w[i]) { ok = false; break; }
    }
    if (!ok) continue;
    const bias = themeWords.has(w.w) ? 12 : 0;
    const opennessPenalty = openness > 0.55 && w.len >= 8 ? 4 + (w.len - 7) * 1.5 : 0;
    const fitScore = (w.lexicalFit ?? (w.score - w.shapePenalty + (w.crossBase || 0))) + bias - (w.tier > 1 ? 4 : 0) + (w.crossPotential || 0) * 10 - opennessPenalty;
    scored.push({ ...w, fitScore });
    if (scored.length >= rawLimit) break;
  }

  scored.sort((a, b) => b.fitScore - a.fitScore || (b.crossPotential || 0) - (a.crossPotential || 0) || b.score - a.score || a.shapePenalty - b.shapePenalty);
  return diversifyWordPool(scored, maxCandidates, slot.lang || opts.lang || 'en');
}


function limitPerLength(words, maxPerLength = 500) {
  const buckets = new Map();
  for (const w of words) {
    if (!buckets.has(w.len)) buckets.set(w.len, []);
    buckets.get(w.len).push(w);
  }
  const out = [];
  for (const arr of buckets.values()) {
    arr.sort((a, b) => (b.lexicalFit ?? b.score) - (a.lexicalFit ?? a.score) || b.score - a.score || a.shapePenalty - b.shapePenalty || a.w.localeCompare(b.w));
    out.push(...diversifyWordPool(arr, maxPerLength, arr[0]?.lang || 'en'));
  }
  return out;
}

function loadPreparedSource(opts = {}) {
  const lang = String(opts.lang || 'en').toLowerCase();
  const primary = loadSourceFile(lang, opts.source, opts.baseDir);
  let words = flattenWordBuckets(primary.data, lang);
  if (opts.merge) {
    for (const item of parseArgsList(opts.merge)) {
      const extra = loadSourceFile(lang, item, opts.baseDir);
      words = mergeSources(words, flattenWordBuckets(extra.data, lang));
    }
  }
  words = filterWords(words, opts);
  words = crosswordTuneWords(words, { lang, crosswordTune: opts.crosswordTune !== false && words.length > 3000 });
  words = limitPerLength(words, Number(opts.maxPerLength || 500));
  return {
    lang,
    sourcePath: primary.path,
    sourceName: path.basename(primary.path),
    words,
    index: buildIndex(words),
  };
}

module.exports = {
  parseArgsList,
  loadJson,
  loadSourceFile,
  flattenWordBuckets,
  filterWords,
  mergeSources,
  buildIndex,
  estimatePatternCount,
  getCandidates,
  loadPreparedSource,
  limitPerLength,
  crosswordTuneWords,
};
