'use strict';

function lz76(str) {
  if (!str || str.length <= 1) return str ? str.length : 0;
  let c = 1, l = 1, i = 0, k = 1, kmax = 1;
  while (true) {
    if (str[i + k - 1] === str[l + k - 1]) {
      k++;
      if (l + k > str.length) { c++; break; }
    } else {
      if (k > kmax) kmax = k;
      i++;
      if (i === l) {
        c++; l += kmax;
        if (l >= str.length) break;
        i = 0; k = 1; kmax = 1;
      } else {
        k = 1;
      }
    }
  }
  return c;
}

function evalSeqStability(seq) {
  if (!seq || seq.length < 3) return 0.5;
  const deltas = seq.slice(1).map((v, i) => {
    const d = v - seq[i];
    if (d > 8) return 'A';
    if (d > 2) return 'B';
    if (d > -2) return 'C';
    if (d > -8) return 'D';
    return 'E';
  }).join('');
  const raw = lz76(deltas) / Math.max(1, deltas.length);
  return Math.max(0, Math.min(1, 1 - raw));
}

function adsrAnalysis(seq) {
  if (!seq || seq.length < 2) return { attack: 0, decay: 0, sustain: 0, release: 0, shape: 'unknown', label: '?' };
  const baseline = seq[0];
  const deltas = seq.map(v => v - baseline);
  const peak = Math.max(...deltas);
  const peakIdx = deltas.indexOf(peak);
  const valley = Math.min(...deltas.slice(peakIdx));
  const attack = peak;
  const decay = peak - valley;
  const sustainSlice = deltas.slice(Math.max(1, Math.floor(deltas.length * 0.2)), Math.max(2, Math.floor(deltas.length * 0.8)));
  const sustain = sustainSlice.length ? sustainSlice.reduce((a, b) => a + b, 0) / sustainSlice.length : 0;
  const release = deltas[deltas.length - 1] - sustain;
  let shape = 'mixed', label = '◆';
  if (Math.abs(attack) < 3 && Math.abs(decay) < 3) { shape = 'sustained'; label = '▬'; }
  else if (attack < -6) { shape = 'collapse'; label = '▼'; }
  else if (attack > 10 && decay > 8) { shape = 'spike'; label = '⚡'; }
  else if (attack > 6 && Math.abs(decay) < 5 && release > -3) { shape = 'building'; label = '▲'; }
  else if (Math.abs(decay) > 10) { shape = 'volatile'; label = '〜'; }
  return { attack, decay, sustain, release, shape, label };
}

class DCCGovernor {
  constructor(policyName, opts = {}) {
    this.policyName = policyName;
    this.opts = opts;
    this.phase = 'seed';
    this.scoreHistory = [];
    this.sensorHistory = [];
    this.trace = [];
    this.dropThreshold = -8;
    this.riseThreshold = 2;
  }

  observe(snapshot) {
    this.sensorHistory.push(snapshot);
    this.scoreHistory.push(snapshot.totalScore);
    if (this.sensorHistory.length > 200) this.sensorHistory = this.sensorHistory.slice(-120);
    if (this.scoreHistory.length > 200) this.scoreHistory = this.scoreHistory.slice(-120);
    this.recalibrate();
  }

  recalibrate() {
    if (this.scoreHistory.length < 6) return;
    const deltas = [];
    for (let i = 1; i < this.scoreHistory.length; i++) deltas.push(this.scoreHistory[i] - this.scoreHistory[i - 1]);
    const s = [...deltas].sort((a, b) => a - b);
    this.dropThreshold = s[Math.floor(s.length * 0.2)] ?? this.dropThreshold;
    this.riseThreshold = s[Math.floor(s.length * 0.75)] ?? this.riseThreshold;
  }

  pickPhase(snapshot) {
    const seq = this.scoreHistory;
    const stability = evalSeqStability(seq);
    const adsr = adsrAnalysis(seq);
    const stagnation = this.computeStagnation();

    let phase = this.phase;
    if (snapshot.components > 1 || snapshot.invalidSlots > 0) phase = 'bridge';
    else if (!snapshot.solved && snapshot.fillRatio < 0.45) phase = 'seed';
    else if (!snapshot.solved && (snapshot.deadPressure > 0 || snapshot.fillRatio < 0.95)) phase = 'densify';
    else if (snapshot.solved && snapshot.garbageRatio > 0.22) phase = 'repair';
    else if (snapshot.solved && (snapshot.blackRatio > snapshot.targetBlackRatio || snapshot.crossingDensity < 0.6)) phase = 'polish';
    else if (stagnation > 0.75 && adsr.shape === 'collapse') phase = 'repair';
    else if (stagnation > 0.75 && stability < 0.25) phase = 'bridge';
    else if (snapshot.solved) phase = 'commit';
    else phase = 'densify';

    this.phase = phase;
    const note = {
      tick: this.trace.length,
      phase,
      stability: round3(stability),
      adsr: adsr.shape,
      stagnation: round3(stagnation),
      score: round2(snapshot.totalScore),
      fillRatio: round3(snapshot.fillRatio),
      blackRatio: round3(snapshot.blackRatio),
      deadPressure: round3(snapshot.deadPressure),
      garbageRatio: round3(snapshot.garbageRatio),
    };
    this.trace.push(note);
    return phase;
  }

  computeStagnation() {
    if (this.scoreHistory.length < 6) return 0;
    const recent = this.scoreHistory.slice(-6);
    const deltas = recent.slice(1).map((v, i) => v - recent[i]);
    const absMean = deltas.reduce((a, b) => a + Math.abs(b), 0) / deltas.length;
    const stability = evalSeqStability(recent);
    return Math.max(0, Math.min(1, (stability + (absMean < 1.2 ? 0.7 : 0)) / 1.7));
  }
}

function round2(x) { return Math.round(x * 100) / 100; }
function round3(x) { return Math.round(x * 1000) / 1000; }

module.exports = {
  lz76,
  evalSeqStability,
  adsrAnalysis,
  DCCGovernor,
};
