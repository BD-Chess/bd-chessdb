# CW Arena — Cross-Domain Transfer Analysis G · v7 build note

**GPT / AIM³ Lab · April 2026**

## What I read before building v7

- `cw_arena_v6c.py`
- `cw_arena_v6g.py`
- `CW_cross_domain_transfer_C.md`
- `az_sensors.py`, `az_laws.py`, `az_partitioners.py` from `8Z TSP arena.zip`
- `nas_sensors.py`, `nas_laws.py` from `8z NAS arena v20.zip`
- `BD-Sudoku.html`

Important honesty note:
I did **not** find Claude's actual v7 code file in the current project uploads.
I found Claude's transfer document, not Claude's v7 Python arena.
So this v7 is built from:
- the current v6 code state,
- Claude's written transfer analysis,
- my own earlier crossword seeds,
- direct reading of TSP / NAS / Sudoku source materials.

---

## Build decision

I did **not** want another tiny v6.x tuning pass.
I also did **not** want to throw away the proven v6 closure spine.

So v7 is:

**v6 closure spine + overbuilt cross-domain sensor layer**

That means:
- AC-3 / MRV / support-counting spine stays fixed
- core short-unhint ban stays fixed in early stage
- arena gets many new tunable signals around that spine
- bad signals can be zeroed or inverted by CMA

This matches BD's request:
**put in a lot, even uncertain things, and let the arena decide**.

---

## What I put into arena v7

### 1. TSP → DCC delta on partial description stream
**Where:** `_order`

For each candidate word, v7 measures a crude LZ delta on the partial assignment description stream:
- current partial signature
- current + candidate signature
- delta becomes a tunable candidate signal

Why:
This is the closest cheap crossword analogue to the TSP LZBinary / LZDual / DCC-delta family.
Not guaranteed right sign. Arena can invert it.

---

### 2. TSP / NAS → echo gain
**Where:** `_order`

For each open crossing neighbor, v7 measures how much a candidate word narrows the neighbor domain:
- previous domain size
- remaining matching words after the crossing letter
- log reduction = echo gain

Why:
This is a good crossword analogue of echo / corridor / downstream-support thinking.
A good move should not only fit now; it should send a useful signal forward.

---

### 3. TSP / CCH → resonance on crossing letters
**Where:** `_order`

I precompute letter surprisal by `(length, position, char)` from the lexicon.
A candidate gets a resonance score from the surprise/informativeness of the letters it contributes at open crossings.

Why:
This is the cheapest real implementation of your “resonance / informative crossing” intuition.
It is not mystical. It is letter-position surprisal.

---

### 4. Sudoku → cascade depth
**Where:** `_order`

For each candidate, v7 counts when a crossing neighbor is driven down to:
- 1 legal word left
- 2 legal words left

This becomes `cascade_depth`.

Why:
Closest crossword analogue to Sudoku cascade.
A good fill should trigger downstream determination.

---

### 5. Sudoku → cascade power
**Where:** `_order` and trial signals

Beyond plain depth, v7 also computes weighted cascade power:
- domain reduction amount
- extra reward when a large domain collapses sharply

Why:
Claude was right that plain depth is weaker than weighted cascade.
This is closer to Sudoku `cascade_power` than just “count of forced neighbors.”

---

### 6. TSP → keystone / pyramid / cluster / edge sensitivity
**Where:** `_choose`

I precompute slot structure fields:
- `slot_keystone`
- `slot_cluster`
- `slot_criticality`

Then `_choose` still uses MRV first, but the tie-break layer is now tunable with:
- `choose_keystone`
- `choose_cluster`
- `choose_critical`
- `choose_frozen`

Why:
This is the cheapest real transfer of:
- MSTD / pyramid intuition
- edge criticality
- cluster-first reasoning
without inventing fake geometry.

---

### 7. NAS → flood & drain dynamic gating
**Where:** `_gate`

I added dynamic threshold adjustment based on current average unresolved domain size:
- if domains are wide/open → relax gating a bit
- if domains are narrow/flowing → tighten gating a bit

Tunable:
- `fd_relax`
- `fd_tighten`

Why:
This is the cleanest way to bring Flood/Drain into the current CSP shape without rewriting the solver.

---

### 8. Sudoku → process LZ
**Where:** trial-level `signals()` and `quality()`

v7 records the attempted decision token stream during the run and computes LZ76 over it.

Why:
Sudoku showed that process metrics can be more revealing than static state metrics.
This one is especially worth testing.

---

### 9. Sudoku → density-flow LZ
**Where:** trial-level `signals()` and `quality()`

v7 records the total unresolved domain mass sequence and computes LZ76 over that sequence.

Why:
This is a cheap first pass at “smoothness of solving flow.”
It is not identical to the Sudoku version, but it is close enough to test.

---

### 10. TSP ADSR / dead-branch sensing
**Where:** `_search`

I added a conservative, zeroable prune:
- look at recent path domain-mass history
- if it is too flat for too long after a certain depth
- prune the branch as “dead / non-flowing”

Tunable:
- `adsr_depth_start`
- `adsr_window`
- `adsr_flat_tol`

Why:
This is a real but cautious import of ADSR-style dead-branch detection.
Not strong enough to be called a full control law.
But enough to let the arena test whether stagnation sensing helps.

---

### 11. Trial-level quality got wider
**Where:** `quality()`

Besides the v6 board quality terms, v7 can now also weight:
- `q_process_lz`
- `q_density_flow`
- `q_mean_cascade`
- `q_mean_echo`

Why:
If “beautiful crossword” partly means “beautiful solving process,” the arena needs access to process-side signals too.

---

### 12. Kept from v6

I intentionally kept:
- v6 closure spine
- v6 elite diversity path
- v6 weird penalty in quality
- v6 narrow/conservative operational style
- lock/checkpoint/resume structure

Because closure is already real and I did not want to destroy it by rewriting the engine from zero.

---

## What I did **not** put into v7

### 1. Counterfactual beam
**Reason:**
Needs a real search rewrite, not a small sensor patch.
I think it is promising, but it is a structural move, not a safe add-on.

### 2. Quality ratchet
**Reason:**
Interesting, but unsafe without a trustworthy partial-quality upper bound.
Otherwise it risks killing closure by pruning good branches too early.

### 3. Basin discovery inside the solver
**Reason:**
This is post-hoc diagnostics first.
It should become a separate analysis tool, not be guessed into solver code blindly.

### 4. Style coherence
**Reason:**
Current lexicon format does not appear to carry style labels.
Without a real `style` field, any “style coherence” added now would be fake.

### 5. Heavy geometric TSP sensors
Not added:
- Voronoi / triangle / simplex / radial / fold-distance style sensors
- hyperdimensional partitioners
- quantum-inspired sensors

**Reason:**
On current crossword representation they would be decorative, not grounded.

### 6. Full NAS law system
Not added:
- staged macro allocators
- family routers
- complex probe laws

**Reason:**
Current crossword solver is DFS+CSP, not an outer iterative controller like NAS arena.
The analogues need to be translated carefully, not pasted in by name.

---

## My actual judgment

Claude's document was good on **closure-side transfer**.
It was too conservative on **process sensors** and too deferential about pushing more ideas into v7.

So my v7 choice was:
- keep Claude's strong closure imports,
- add more process-side imports now,
- leave only the clearly unsafe structural rewrites out.

So this v7 is intentionally **fatter** than Claude's written v7 plan.
That was on purpose.

---

## Risk profile of this v7

It may:
- improve quality discrimination,
- improve unique-board discovery,
- discover that some of these signals are useless,
- or temporarily hurt closure until CMA learns what to zero.

That is acceptable.
That is exactly why we have the arena.

The only thing I protected hard was the solver spine.
Everything else is there to be tested, killed, inverted, or kept.

---

## Suggested first test

```bash
python cw_arena_v7g.py --source lex\cw_en_scored.json --outdir out\cw_arena_v7g_1h --hours 1 --quality-seconds 30 --population 12 --elite 4 --workers 5 --fresh
```

Good longer test:

```bash
python cw_arena_v7g.py --source lex\cw_en_scored.json --outdir out\cw_arena_v7g_overnight --hours 7 --quality-seconds 35 --population 12 --elite 4 --workers 6 --fresh
```

---

## What I expect to matter most

My own ranking before testing:

1. **echo gain**
2. **cascade power**
3. **process LZ**
4. **flood & drain**
5. **resonance**

The most uncertain ones are:
- DCC delta on partial description stream
- ADSR dead-branch prune

But they are in because the arena should decide, not me.

---

## Final stance

v7 is **not** the final crossword engine.
It is the first version where the arena begins to feel more like **our cross-domain lab** and less like “just a tuned crossword CSP.”

That is the real point.
