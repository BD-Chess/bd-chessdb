'use strict';

const PACKS = {
  sl: {
    code: 'sl',
    name: 'Slovenščina',
    alphabet: new Set('AÁBCČDEFGHIJKLMNOPRSŠTUVZŽQWXY'.split('')),
    vowels: new Set('AEIOU'.split('')),
    commonBigrams: ['JE', 'NA', 'RA', 'RE', 'NI', 'ST', 'PR', 'PO', 'LA', 'NE'],
    rareBigrams: ['Q', 'W', 'XY'],
    rareTrigrams: ['SCH', 'TCH', 'GHT', 'FTH', 'QWX'],
    uglySuffixes: ['SKEGA', 'SKEMU', 'SKIM', 'SKIH', 'SKIMI', 'AJOČ', 'IRAJOČ', 'IRANJE', 'ANJE', 'ENJE', 'EGA', 'EMU'],
    digraphs: ['ČR', 'ŠT', 'TR', 'PR', 'ST', 'RA'],
    normalizeChar(ch) {
      return ch.toUpperCase();
    },
    shapeHooks(word) {
      let penalty = 0;
      const vow = vowelRatio(word, this.vowels);
      if (vow < 0.25 || vow > 0.68) penalty += 8;
      if (/[QWX]/.test(word)) penalty += 30;
      if (this.rareTrigrams.some(x => word.includes(x))) penalty += 10;
      if (this.uglySuffixes.some(x => word.endsWith(x))) penalty += 8;
      return penalty;
    }
  },
  en: {
    code: 'en',
    name: 'English',
    alphabet: new Set('ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')),
    vowels: new Set('AEIOUY'.split('')),
    commonBigrams: ['TH', 'ER', 'IN', 'AN', 'RE', 'ON', 'AT', 'EN', 'ST', 'NT'],
    rareBigrams: ['QJ', 'QZ', 'ZX', 'JQ'],
    rareTrigrams: ['QZX', 'QJ', 'ZXQ'],
    uglySuffixes: ['NESSLY', 'ATIONS'],
    digraphs: ['TH', 'CH', 'SH', 'PH', 'WH', 'CK'],
    normalizeChar(ch) {
      return ch.toUpperCase();
    },
    shapeHooks(word) {
      let penalty = 0;
      const vow = vowelRatio(word, this.vowels);
      if (vow < 0.20 || vow > 0.75) penalty += 8;
      if (this.rareBigrams.some(x => word.includes(x))) penalty += 10;
      if (this.rareTrigrams.some(x => word.includes(x))) penalty += 12;
      return penalty;
    }
  }
};

function getLangPack(code) {
  const key = String(code || 'en').toLowerCase();
  if (!PACKS[key]) throw new Error(`Unsupported language pack: ${code}`);
  return PACKS[key];
}

function normalizeWord(word, langCode) {
  const pack = getLangPack(langCode);
  const raw = String(word || '').trim().toUpperCase();
  let out = '';
  for (const ch of raw) {
    const n = pack.normalizeChar(ch);
    if (pack.alphabet.has(n)) out += n;
  }
  return out;
}

function vowelRatio(word, vowels) {
  if (!word || !word.length) return 0;
  let count = 0;
  for (const ch of word) if (vowels.has(ch)) count++;
  return count / word.length;
}

function repeatedRunPenalty(word) {
  if (!word) return 0;
  let pen = 0;
  let run = 1;
  for (let i = 1; i < word.length; i++) {
    if (word[i] === word[i - 1]) {
      run++;
      if (run >= 2) pen += 1 + (run - 2) * 2;
    } else {
      run = 1;
    }
  }
  return pen;
}

function commonnessBoost(word, pack) {
  let score = 0;
  for (const bg of pack.commonBigrams) {
    if (word.includes(bg)) score += 0.8;
  }
  for (const dg of pack.digraphs) {
    if (word.includes(dg)) score += 0.5;
  }
  return Math.min(6, score);
}

function wordShapePenalty(word, langCode) {
  const pack = getLangPack(langCode);
  let penalty = 0;
  penalty += repeatedRunPenalty(word);
  penalty += pack.shapeHooks(word);
  const uniqueRatio = new Set(word.split('')).size / Math.max(1, word.length);
  if (uniqueRatio < 0.45) penalty += 5;
  if (/[^A-ZČŠŽ]/.test(word)) penalty += 50;
  penalty -= commonnessBoost(word, pack);
  return Math.max(0, penalty);
}

module.exports = {
  PACKS,
  getLangPack,
  normalizeWord,
  vowelRatio,
  wordShapePenalty,
  commonnessBoost,
};
