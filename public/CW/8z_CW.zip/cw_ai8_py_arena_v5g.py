#!/usr/bin/env python3
"""
cw_ai8_py_arena_v5.py — Crossword Arena v5 fusion

Design goal:
- keep the solver-core behavior that actually closes reliably on the base lexicon
- keep the operational safety/features we need for long runs (resume default, lock file,
  atomic writes, manifest, graceful checkpoint on Ctrl+C)
- optimize ONLY staged lexicon gating + solved-board quality scoring + elite diversity
- never mutate AC-3 / MRV / support-counting internals

This is intentionally conservative. The point is not to be clever.
The point is to preserve the winning search spine, loosen the brittle core gate,
and push the arena toward cleaner and more diverse solved boards.
"""

import argparse
import ast
import concurrent.futures as cf
import json
import math
import os
import random
import re
import signal
import statistics
import sys
import time
from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Set

MASKS = {
    'dense9_a': [
        '......###', '......###', '.......##',
        '....#....', '...###...', '....#....',
        '##.......', '###......', '###......',
    ],
}

VOWELS = set('AEIOUY')
WEIRD_BASE = {'EEO', 'DPI', 'TRUG', 'INRI', 'ETA', 'PTA'}
EPS = 1e-9
MAX_PER_LEN = 4000


def lz76_safe(s: str) -> float:
    if not s or len(s) <= 1:
        return len(s) if s else 0.0
    c = 0
    seen = set()
    i = 0
    n = len(s)
    while i < n:
        j = i + 1
        while j <= n and s[i:j] in seen:
            j += 1
        seen.add(s[i:j])
        c += 1
        i = j
    return c / max(1.0, n / max(1.0, math.log2(n + 1.0)))


def shannon(chars: str) -> float:
    if not chars:
        return 0.0
    cnt = Counter(chars)
    n = len(chars)
    return -sum((v / n) * math.log2(v / n + EPS) for v in cnt.values())


@dataclass
class Params:
    # staged gating
    stage1_depth: int = 5
    stage2_depth: int = 14
    core_min_score: float = 72.0
    balanced_min_score: float = 40.0
    core_short_unhint_delta: float = 10.0

    # solved-board quality scoring
    q_ugly_w: float = 25.0
    q_hinted_w: float = 30.0
    q_avg_score_w: float = 3.0
    q_mdl_w: float = 10.0
    q_entropy_w: float = 5.0
    q_short_unhint_w: float = 10.0
    q_weird_w: float = 14.0


PARAM_BOUNDS = {
    'stage1_depth': (2, 10),
    'stage2_depth': (8, 20),
    'core_min_score': (50.0, 92.0),
    'balanced_min_score': (10.0, 70.0),
    'core_short_unhint_delta': (4.0, 18.0),
    'q_ugly_w': (5.0, 60.0),
    'q_hinted_w': (5.0, 80.0),
    'q_avg_score_w': (0.5, 10.0),
    'q_mdl_w': (0.0, 30.0),
    'q_entropy_w': (0.0, 20.0),
    'q_short_unhint_w': (0.0, 30.0),
    'q_weird_w': (0.0, 30.0),
}

PARAM_SEED = {
    'stage1_depth': 5.0,
    'stage2_depth': 14.0,
    'core_min_score': 72.0,
    'balanced_min_score': 40.0,
    'core_short_unhint_delta': 10.0,
    'q_ugly_w': 25.0,
    'q_hinted_w': 30.0,
    'q_avg_score_w': 3.0,
    'q_mdl_w': 10.0,
    'q_entropy_w': 5.0,
    'q_short_unhint_w': 10.0,
    'q_weird_w': 14.0,
}


class Solver:
    """Claude v3c winning solver core, kept stable."""

    def __init__(self, source_path, params=None, mask_name='dense9_a',
                 quality_seconds=25.0, banned=None, seed=0, quality_profile='balanced',
                 weird_mode='soft', core_hint_mode='auto'):
        with open(source_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        self.lang = data.get('lang', 'en')
        self.bylen = {int(k): list(v) for k, v in data['words'].items()}
        for l, arr in self.bylen.items():
            arr.sort(key=lambda x: (-(x.get('s', 0)), -(1 if x.get('h') else 0), x['w']))
            if len(arr) > MAX_PER_LEN:
                self.bylen[l] = arr[:MAX_PER_LEN]
        self.words_by_len = {l: [x['w'] for x in arr] for l, arr in self.bylen.items()}
        self.mask = MASKS[mask_name]
        self.R = len(self.mask)
        self.C = len(self.mask[0])
        self.slots = self._build_slots()
        self.nbrs = {s['id']: set(sid2 for _, sid2, _ in s['cross']) for s in self.slots}
        self.allsets = {l: set(range(len(arr))) for l, arr in self.words_by_len.items()}
        self.banned = {w.upper() for w in (banned or set())}
        self.params = params or Params()
        self.quality_seconds = quality_seconds
        self.quality_profile = quality_profile
        self.weird_mode = weird_mode
        self.core_hint_mode = core_hint_mode
        self.start = 0.0
        self.nodes = 0
        self.solutions = []
        self.best_partial_depth = 0
        self.best_partial = None
        self.first_solved_at = None
        self.rejections = Counter()
        self.rng = random.Random(seed)

    def _build_slots(self):
        slots = []
        for orient in 'AD':
            if orient == 'A':
                for r in range(self.R):
                    c = 0
                    while c < self.C:
                        if self.mask[r][c] != '#' and (c == 0 or self.mask[r][c - 1] == '#'):
                            c2 = c
                            while c2 < self.C and self.mask[r][c2] != '#':
                                c2 += 1
                            if c2 - c >= 3:
                                slots.append({'id': len(slots), 'o': 'A', 'cells': [(r, cc) for cc in range(c, c2)], 'len': c2 - c})
                            c = c2
                        else:
                            c += 1
            else:
                for c in range(self.C):
                    r = 0
                    while r < self.R:
                        if self.mask[r][c] != '#' and (r == 0 or self.mask[r - 1][c] == '#'):
                            r2 = r
                            while r2 < self.R and self.mask[r2][c] != '#':
                                r2 += 1
                            if r2 - r >= 3:
                                slots.append({'id': len(slots), 'o': 'D', 'cells': [(rr, c) for rr in range(r, r2)], 'len': r2 - r})
                            r = r2
                        else:
                            r += 1
        cellmap = defaultdict(list)
        for s in slots:
            for pos, cell in enumerate(s['cells']):
                cellmap[cell].append((s['id'], pos))
        for s in slots:
            s['cross'] = [(pos, sid2, pos2) for pos, cell in enumerate(s['cells']) for sid2, pos2 in cellmap[cell] if sid2 != s['id']]
        return slots

    def _stage(self, depth):
        s1 = int(self.params.stage1_depth)
        s2 = int(max(self.params.stage2_depth, s1 + 1))
        if depth < s1:
            return 'core'
        if depth < s2:
            return 'balanced'
        return 'extended'

    def _gate_ok(self, meta, depth):
        w = meta['w']
        if w in self.banned:
            return False
        if self.weird_mode == 'hard' and w in WEIRD_BASE:
            return False
        stage = self._stage(depth)
        s = meta.get('s', 0)
        has_hint = bool(meta.get('h'))
        if stage == 'core':
            threshold = self.params.core_min_score
            if len(w) <= 4 and not has_hint:
                if self.core_hint_mode == 'on':
                    return False
                if self.core_hint_mode == 'auto':
                    threshold += self.params.core_short_unhint_delta
            if s < threshold:
                return False
        elif stage == 'balanced':
            if s < self.params.balanced_min_score:
                return False
        return True

    def _cd(self, slot, domains, assigned, used):
        sid = slot['id']
        if sid in assigned:
            return {assigned[sid]}
        arr = self.words_by_len[slot['len']]
        out = set()
        for idx in domains[sid]:
            w = arr[idx]
            if w in used or w in self.banned:
                continue
            ok = True
            for pos, sid2, pos2 in slot['cross']:
                if sid2 in assigned:
                    if w[pos] != self.words_by_len[self.slots[sid2]['len']][assigned[sid2]][pos2]:
                        ok = False
                        break
            if ok:
                out.add(idx)
        return out

    def _revise(self, domains, xi, xj, used, assigned):
        crosses = [(pi, pj) for pi, sid2, pj in self.slots[xi]['cross'] if sid2 == xj]
        if not crosses:
            return False
        di = self._cd(self.slots[xi], domains, assigned, used)
        dj = self._cd(self.slots[xj], domains, assigned, used)
        if not di or not dj:
            domains[xi] = set()
            return True
        ai = self.words_by_len[self.slots[xi]['len']]
        aj = self.words_by_len[self.slots[xj]['len']]
        sup = [(pi, set(aj[j][pj] for j in dj)) for pi, pj in crosses]
        rem = {i for i in di if any(ai[i][pi] not in letters for pi, letters in sup)}
        if rem:
            domains[xi] = di - rem
            return True
        domains[xi] = di
        return False

    def _ac3(self, domains, used, assigned):
        q = deque((xi, xj) for xi in range(len(self.slots)) for xj in self.nbrs[xi])
        while q:
            xi, xj = q.popleft()
            if self._revise(domains, xi, xj, used, assigned):
                if not domains[xi]:
                    return False
                for xk in self.nbrs[xi] - {xj}:
                    q.append((xk, xi))
        return True

    def _choose(self, domains, assigned, used):
        best_sid, best_key = None, None
        for slot in self.slots:
            sid = slot['id']
            if sid in assigned:
                continue
            dom = self._cd(slot, domains, assigned, used)
            domains[sid] = dom
            filled = sum(1 for _, sid2, _ in slot['cross'] if sid2 in assigned)
            key = (len(dom), -filled, -slot['len'])
            if best_key is None or key < best_key:
                best_key = key
                best_sid = sid
        return best_sid

    def _sc(self, sid2, pos2, ch, domains, assigned, used):
        arr = self.words_by_len[self.slots[sid2]['len']]
        return sum(1 for j in self._cd(self.slots[sid2], domains, assigned, used) if arr[j][pos2] == ch)

    def _order(self, sid, domains, assigned, used):
        slot = self.slots[sid]
        depth = len(assigned)
        dom = self._cd(slot, domains, assigned, used)
        scored = []
        for idx in dom:
            meta = self.bylen[slot['len']][idx]
            if not self._gate_ok(meta, depth):
                self.rejections['gated'] += 1
                continue
            w = meta['w']
            val = meta.get('s', 0) + (14 if meta.get('h') else 0) + 4.0 * len(set(w)) / len(w)
            if not meta.get('h'):
                val -= 18
            if len(w) <= 4 and sum(c in VOWELS for c in w) <= 1:
                val -= 12
            if re.search(r'(.)\1\1', w):
                val -= 8
            if len(set(w)) <= 2:
                val -= 8
            if w in self.banned:
                val -= 22
            if self.weird_mode == 'soft' and w in WEIRD_BASE:
                val -= 22
            # optional clean profile penalty — still mild, but more lexical than v4
            if self.quality_profile == 'clean':
                if len(w) <= 4 and not meta.get('h'):
                    val -= 8
                if len(w) == 3 and w.count('A') >= 2:
                    val -= 2
                if w in WEIRD_BASE:
                    val -= 8

            minsup, total, zero = 999999, 0, False
            for pos, sid2, pos2 in slot['cross']:
                if sid2 in assigned:
                    continue
                cnt = self._sc(sid2, pos2, w[pos], domains, assigned, used)
                if cnt == 0:
                    zero = True
                    break
                total += cnt
                minsup = min(minsup, cnt)
            if zero:
                self.rejections['zero_sup'] += 1
                continue
            val += 3.0 * math.log(total + 1) + 2.0 * math.log(minsup + 1)
            scored.append((val, idx))
        scored.sort(reverse=True)
        topn = 80 if depth < 10 else 120
        return [idx for _, idx in scored[:topn]]

    def _search(self, domains, assigned, used):
        self.nodes += 1
        if len(assigned) > self.best_partial_depth:
            self.best_partial_depth = len(assigned)
            self.best_partial = dict(assigned)
        if len(assigned) == len(self.slots):
            self.solutions.append(dict(assigned))
            if self.first_solved_at is None:
                self.first_solved_at = time.time() - self.start
            return False
        if time.time() - self.start > self.quality_seconds:
            return True
        sid = self._choose(domains, assigned, used)
        if sid is None or not domains[sid]:
            return False
        for idx in self._order(sid, domains, assigned, used):
            w = self.words_by_len[self.slots[sid]['len']][idx]
            if w in used:
                continue
            d2 = {k: set(v) for k, v in domains.items()}
            a2 = dict(assigned)
            u2 = set(used)
            a2[sid] = idx
            u2.add(w)
            d2[sid] = {idx}
            ok = True
            for pos, sid2, pos2 in self.slots[sid]['cross']:
                if sid2 in a2:
                    continue
                arr2 = self.words_by_len[self.slots[sid2]['len']]
                dom2 = {j for j in self._cd(self.slots[sid2], d2, a2, u2) if arr2[j][pos2] == w[pos]}
                d2[sid2] = dom2
                if not dom2:
                    ok = False
                    break
            if not ok:
                continue
            if not self._ac3(d2, u2, a2):
                continue
            if self._search(d2, a2, u2):
                return True
        return False

    def make_board(self, assigned):
        b = [list(r) for r in self.mask]
        for sid, idx in assigned.items():
            sl = self.slots[sid]
            w = self.words_by_len[sl['len']][idx]
            for (r, c), ch in zip(sl['cells'], w):
                b[r][c] = ch
        return [''.join(r) for r in b]

    def get_words(self, assigned):
        out = []
        for sid, idx in sorted(assigned.items()):
            m = self.bylen[self.slots[sid]['len']][idx]
            out.append({'sid': sid, 'o': self.slots[sid]['o'], 'len': self.slots[sid]['len'],
                        'w': m['w'], 'h': m.get('h', ''), 's': m.get('s', 0)})
        return out

    def board_signals(self, assigned):
        board = self.make_board(assigned)
        rows_s = '|'.join(''.join(c for c in row if c != '#') for row in board)
        cols_s = '|'.join(''.join(board[r][c] for r in range(self.R) if board[r][c] != '#') for c in range(self.C))
        sol_mdl = lz76_safe(rows_s + '||' + cols_s)
        all_let = ''.join(c for row in board for c in row if c not in '.#')
        return {
            'sol_mdl': round(sol_mdl, 4),
            'cross_entropy': round(shannon(all_let), 4),
            'fill_ratio': round(sum(1 for row in board for c in row if c not in '.#') / max(1, sum(1 for row in board for c in row if c != '#')), 4),
        }

    def quality_score(self, assigned):
        words = self.get_words(assigned)
        p = self.params
        hinted = sum(1 for w in words if w['h'])
        avg_s = sum(w['s'] for w in words) / max(1, len(words))
        ugly = sum(1 for w in words if w['s'] < 65 and not w['h'])
        short_unhint = sum(1 for w in words if len(w['w']) <= 4 and not w['h'])
        weird_n = sum(1 for w in words if w['w'] in WEIRD_BASE)
        sig = self.board_signals(assigned)
        score = 0.0
        score -= p.q_ugly_w * ugly
        score -= p.q_short_unhint_w * short_unhint
        score -= p.q_weird_w * weird_n
        score += p.q_hinted_w * (hinted / max(1, len(words)))
        score += p.q_avg_score_w * (avg_s / 100.0)
        score -= p.q_mdl_w * sig['sol_mdl']
        score -= p.q_entropy_w * sig['cross_entropy']
        if self.quality_profile == 'clean':
            score -= 0.5 * p.q_short_unhint_w * short_unhint
            score -= 0.5 * p.q_weird_w * weird_n
        return score

    def run(self):
        domains = {s['id']: set(self.allsets[s['len']]) for s in self.slots}
        if not self._ac3(domains, set(), {}):
            return {'solved': False, 'error': 'AC-3 fail'}
        self.start = time.time()
        self._search(domains, {}, set())
        solved = len(self.solutions) > 0
        best_assigned = None
        best_q = -1e18
        for a in self.solutions:
            q = self.quality_score(a)
            if q > best_q:
                best_q = q
                best_assigned = a
        if not solved:
            best_assigned = self.best_partial or {}
        return {
            'solved': solved,
            'num_solutions': len(self.solutions),
            'seconds': round(time.time() - self.start, 3),
            'nodes': self.nodes,
            'best_partial_depth': self.best_partial_depth,
            'first_solved_at': round(self.first_solved_at, 3) if self.first_solved_at else None,
            'quality': round(best_q, 4) if solved else None,
            'board': self.make_board(best_assigned),
            'words': self.get_words(best_assigned),
            'signals': self.board_signals(best_assigned),
            'rejections': dict(self.rejections),
        }


def clamp(name, val):
    lo, hi = PARAM_BOUNDS[name]
    return max(lo, min(hi, float(val)))


def sample_params(mean, sigma, rng):
    vals = {k: clamp(k, rng.gauss(mean[k], max(EPS, sigma[k]))) for k in PARAM_BOUNDS}
    vals['stage1_depth'] = int(round(vals['stage1_depth']))
    vals['stage2_depth'] = int(round(max(vals['stage2_depth'], vals['stage1_depth'] + 1)))
    return Params(**{k: (int(round(vals[k])) if k in ('stage1_depth', 'stage2_depth') else vals[k]) for k in PARAM_BOUNDS})


def elite_update(elites, mean, sigma, frac=0.35):
    nm, ns = {}, {}
    for k in PARAM_BOUNDS:
        vals = [e['params'][k] for e in elites]
        m = statistics.fmean(vals)
        s = statistics.pstdev(vals) if len(vals) > 1 else sigma[k] * 0.9
        span = PARAM_BOUNDS[k][1] - PARAM_BOUNDS[k][0]
        nm[k] = (1 - frac) * mean[k] + frac * m
        ns[k] = max(span * 0.03, (1 - frac) * sigma[k] + frac * max(s, span * 0.05))
    return nm, ns


def atomic_save_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def append_jsonl(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'a', encoding='utf-8') as f:
        f.write(json.dumps(obj, ensure_ascii=False) + '\n')


def load_state(path: Path):
    if not path.exists():
        return None
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def build_manifest(args, banned_words):
    return {
        'engine': 'cw_ai8_py_arena_v5',
        'source': args.source,
        'mask': args.mask,
        'quality_profile': args.quality_profile,
        'weird_mode': args.weird_mode,
        'core_hint_mode': args.core_hint_mode,
        'elite_diversity': args.elite_diversity,
        'hours': args.hours,
        'quality_seconds': args.quality_seconds,
        'population': args.population,
        'elite': args.elite,
        'workers': args.workers,
        'seed': args.seed,
        'banned_words': sorted(banned_words),
        'created_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    }


def run_trial(job):
    p = Params(**{k: (int(round(job['params'][k])) if k in ('stage1_depth', 'stage2_depth') else job['params'][k])
                  for k in PARAM_BOUNDS})
    s = Solver(
        job['source'], params=p, mask_name=job['mask'],
        quality_seconds=job['quality_seconds'], banned=set(job.get('banned', [])),
        seed=job['seed'], quality_profile=job.get('quality_profile', 'balanced'),
        weird_mode=job.get('weird_mode', 'soft'), core_hint_mode=job.get('core_hint_mode', 'auto')
    )
    r = s.run()
    return {
        'trial_id': job['trial_id'], 'gen': job['gen'], 'seed': job['seed'],
        'params': {k: float(job['params'][k]) for k in PARAM_BOUNDS},
        **r,
    }


def board_signature(result):
    if result.get('solved'):
        return tuple(result.get('board', []))
    return ('partial', result.get('best_partial_depth', 0), tuple(result.get('board', [])))


def select_elites(results, elite_n, diverse=False):
    solved = [r for r in results if r.get('solved')]
    if not solved or elite_n <= 0:
        return []
    solved.sort(key=lambda r: (r.get('quality') or -1e18), reverse=True)
    if not diverse:
        return solved[:elite_n]
    picked = []
    seen = set()
    for r in solved:
        sig = board_signature(r)
        if sig in seen:
            continue
        picked.append(r)
        seen.add(sig)
        if len(picked) >= elite_n:
            return picked
    for r in solved:
        if len(picked) >= elite_n:
            break
        if r not in picked:
            picked.append(r)
    return picked


def main():
    ap = argparse.ArgumentParser(description='Crossword arena v5: keep closure, separate cleanliness, add elite diversity.')
    ap.add_argument('--source', required=True)
    ap.add_argument('--mask', default='dense9_a', choices=sorted(MASKS))
    ap.add_argument('--outdir', required=True)
    ap.add_argument('--hours', type=float, default=1.0)
    ap.add_argument('--quality-seconds', type=float, default=25.0)
    ap.add_argument('--population', type=int, default=8)
    ap.add_argument('--elite', type=int, default=3)
    ap.add_argument('--workers', type=int, default=1)
    ap.add_argument('--quality-profile', choices=['balanced', 'clean'], default='balanced')
    ap.add_argument('--weird-mode', choices=['soft', 'hard'], default='soft')
    ap.add_argument('--core-hint-mode', choices=['auto', 'on', 'off'], default='auto')
    ap.add_argument('--elite-diversity', action='store_true')
    ap.add_argument('--ban-words', default='')
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--fresh', action='store_true')
    args = ap.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    state_path = outdir / 'arena_state.json'
    leaderboard_path = outdir / 'leaderboard.jsonl'
    manifest_path = outdir / 'run_manifest.json'
    lock_path = outdir / 'arena.lock'

    banned_words = {w.strip().upper() for w in args.ban_words.split(',') if w.strip()}
    atomic_save_json(manifest_path, build_manifest(args, banned_words))

    if lock_path.exists():
        raise SystemExit(f'lock exists for {outdir}; do not run same outdir twice at once')
    atomic_save_json(lock_path, {'pid': os.getpid(), 'created': time.strftime('%Y-%m-%d %H:%M:%S')})

    interrupted = {'flag': False}

    def _sigint_handler(signum, frame):
        interrupted['flag'] = True
        print('\n[cw_ai8_py_arena_v5] Ctrl+C received. Will checkpoint after current generation...')

    old_handler = signal.signal(signal.SIGINT, _sigint_handler)

    try:
        state = None if args.fresh else load_state(state_path)
        rng = random.Random(args.seed)
        if state:
            mean, sigma = state['mean'], state['sigma']
            gen0 = state['next_gen']
            best = state.get('best')
            tc = state.get('tc', 0)
            rng.setstate(ast.literal_eval(state['rng_state']))
            print(f'[cw_ai8_py_arena_v5] resume default: continuing from gen={gen0} trial_counter={tc} in {outdir}')
        else:
            mean = {k: float(PARAM_SEED[k]) for k in PARAM_BOUNDS}
            sigma = {k: (PARAM_BOUNDS[k][1] - PARAM_BOUNDS[k][0]) * 0.15 for k in PARAM_BOUNDS}
            gen0 = 0
            best = None
            tc = 0
            print(f'[cw_ai8_py_arena_v5] fresh start in {outdir}')

        deadline = time.time() + args.hours * 3600
        print(f'[cw_ai8_py_arena_v5] source={args.source} mask={args.mask} hours={args.hours} pop={args.population}')
        print(f'[cw_ai8_py_arena_v5] weird_mode={args.weird_mode} core_hint_mode={args.core_hint_mode} elite_diversity={args.elite_diversity}')
        print(f'[cw_ai8_py_arena_v5] fixed solver-core; staged gating + solved-board quality evolve.\n')

        while time.time() < deadline and not interrupted['flag']:
            jobs = []
            for i in range(args.population):
                p = sample_params(mean, sigma, rng)
                jobs.append({
                    'trial_id': tc + i,
                    'gen': gen0,
                    'seed': rng.randint(0, 2**31 - 1),
                    'source': args.source,
                    'mask': args.mask,
                    'quality_seconds': args.quality_seconds,
                    'quality_profile': args.quality_profile,
                    'weird_mode': args.weird_mode,
                    'core_hint_mode': args.core_hint_mode,
                    'banned': sorted(banned_words),
                    'params': {k: float(getattr(p, k)) for k in PARAM_BOUNDS},
                })
            tc += len(jobs)

            if args.workers <= 1:
                results = [run_trial(j) for j in jobs]
            else:
                with cf.ProcessPoolExecutor(max_workers=args.workers) as ex:
                    results = list(ex.map(run_trial, jobs))

            # solved always outranks unsolved
            results.sort(key=lambda r: ((1 if r['solved'] else 0), r.get('quality') or -1e9, r['best_partial_depth']), reverse=True)

            for r in results:
                rec = {k: r[k] for k in ('trial_id', 'gen', 'seed', 'solved', 'num_solutions', 'nodes',
                                         'seconds', 'quality', 'best_partial_depth', 'first_solved_at', 'signals', 'rejections', 'board', 'words', 'params')}
                append_jsonl(leaderboard_path, rec)
                if best is None or (r['solved'] and not best.get('solved')) or \
                   (r['solved'] == best.get('solved') and (r.get('quality') or -1e9) > (best.get('quality') or -1e9)):
                    best = r
                    atomic_save_json(outdir / 'best_result.json', rec)

            elite_rows = select_elites(results, args.elite, diverse=args.elite_diversity)
            elites = [{'params': r['params'], 'score': r.get('quality', 0)} for r in elite_rows]
            if elites:
                mean, sigma = elite_update(elites, mean, sigma)

            top = results[0]
            solved_n = sum(1 for r in results if r['solved'])
            total_sols = sum(r.get('num_solutions', 0) for r in results)
            print(f'[gen {gen0:>3}] {solved_n}/{len(results)} solved ({total_sols} total)  '
                  f'q={top.get("quality", "n/a")}  mdl={top["signals"]["sol_mdl"]:.3f}  '
                  f'depth={top["best_partial_depth"]}  nodes={top["nodes"]}')

            atomic_save_json(state_path, {
                'next_gen': gen0 + 1,
                'mean': mean,
                'sigma': sigma,
                'best': best,
                'tc': tc,
                'rng_state': repr(rng.getstate()),
            })
            gen0 += 1

        print(f'\n{"=" * 60}')
        print(f'[cw_ai8_py_arena_v5] Done. {gen0} gens, {tc} trials')
        if best:
            print(f'Best: solved={best["solved"]} quality={best.get("quality")} solutions={best.get("num_solutions", 0)}')
            for row in best['board']:
                print(f'  {row}')
            hinted = [w for w in best['words'] if w['h']]
            print(f'\n  Hinted: {len(hinted)}/{len(best["words"])}')
            for w in hinted:
                print(f'    {w["w"]:12s} → {w["h"]}')
            print(f'  MDL: {best["signals"]["sol_mdl"]:.3f}  entropy: {best["signals"]["cross_entropy"]:.3f}')
    finally:
        signal.signal(signal.SIGINT, old_handler)
        try:
            if lock_path.exists():
                lock_path.unlink()
        except OSError:
            pass


if __name__ == '__main__':
    main()
