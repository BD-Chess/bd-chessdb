# CW Arena — Cross-Domain Sensor Transfer Analysis v2

**Črt / AIM³ Lab · April 2026 · C+G merged**

Source codebases analyzed:
- TSP: `az_sensors.py` (22 sensors), `az_laws.py` (8 laws), `az_partitioners.py` (9 partitioners)
- NAS: `NAS_arena_v19.py` (B1–B10 phases, 40+ sensors/laws)
- Sudoku: `BD_Sudoku.html` (5 strategies, 5 sensors, ρ confirmed)
- G seeds: `CW_cross_domain_transfer_G.md` (10 crossword-specific seeds)

---

## V v7 — 10 closure sensorjev

### Iz TSP

| # | Sensor | Izvor | Kje v CW | Preslikava |
|---|--------|-------|----------|------------|
| 1 | DCC delta | LZBinarySensor / LZDualSensor | `_order` | Kompresija partial boarda kot candidate signal |
| 2 | MSTD clusters | FlipPartitioner / HilbertPartitioner | `_choose` | Crossing graf → grozdi, reši po grozdih |
| 3 | Piramida keystones | HourglassSensor / ScaleCoherenceSensor | `_choose` | Multi-view: crossing pozicije ki določajo rešitev |
| 4 | Echolokacija | EchoSensor (spatial miss rate) | `_order` | Quality-weighted support namesto raw count |
| 5 | Resonanca | CCH / RE=AC·R | `_order` | Letter rarity na crossing pozicijah |
| 6 | Edge sensitivity | FrozenEdgeSensor koncept | `_choose` | Slot criticality: crossings × partner length |
| 9 | ADSR search control | ADSRLaw (seizure detection) | `_search` | Zaznaj mrtve veje, backtrackaj zgodaj |

### Iz NAS

| # | Sensor | Izvor | Kje v CW | Preslikava |
|---|--------|-------|----------|------------|
| 10 | Flood & Drain | FloodRegionSensor / DrainEscapeSensor | `_gate` | Dinamičen gating: popusti ko obtičiš, zoži ko teče |

### Iz Sudoku

| # | Sensor | Izvor | Kje v CW | Preslikava |
|---|--------|-------|----------|------------|
| 7 | Cascade depth | Gini Cascade (ρ=+0.83) | `_order` | Prefer besede ki forsirajo sosedne slote |
| 8 | Frozen crossing | Naked single strategija | `_choose` | Domain=1 → postavi takoj, brez heuristike |

---

## Česa v7 NIMA — in zakaj je to problem

V7 ima 10 senzorjev ki pomagajo **zapreti** board. V5c je že imel 89% closure rate. Pravi problem ni closure — pravi problem je **quality discrimination**: zakaj solver najde samo 4 unique boarde v 444 trialih? Zakaj so vsi skoraj enaki?

GPT-jeva analiza pravilno identificira ta gap: manjkajo quality-side koncepti ki ločijo lepo križanko od samo-zaprte križanke.

---

## NI dodano — closure-side (iz TSP/NAS/Sudoku)

### TSP geometric sensors (ni CW preslikave brez spatial embeddinga)

- **GravitySensor** — segment energy. Bi rabili tematske embeddings.
- **TriAreaSensor / CircumRSensor / TriCompactSensor / VoronoiAdjSensor** — triangle/Voronoi. Geometrično.
- **FoldDistSensor / SouthwestSensor** — specifično za 2D.
- **HierSimplexSensors / MultiCenterRadialSensor** — rabijo koordinatni sistem.
- **SymmetrySensors** — CW maske imajo simetrijo ampak jo že poznamo vnaprej.
- **ScaleWalkLZ/DeltaSensor** — bi se dalo na constraint grafu, ni jasno kaj bi merili.

### TSP quantum-inspired (preslikava nejasna)

- **InterferenceSensor** — ni dveh neodvisnih streamov v CW.
- **TunnelingSensor** — kaj je "barrier" v crossword searchu?
- **QuantumWalkSensor** — nima jasnega CW analoga.
- **EntanglementSensor / DecoherenceSensor** — v bistvu kar crossing map že je.

### TSP compression (redundantni)

- **TransferEntropySensor** — meta-sensor, mogoče v8.
- **SampEnSensor** — redundanten z LZ76.
- **CUSUMSensor** — ADSR to že pokriva preprosteje.

### TSP control laws (rabijo iterativen loop)

- **PILaw / CDPIDLaw / EMALaw / BBInvertLaw** — CW solver ni iterativen kot TSP.
- **HysteresisBBLaw** — flood/drain že pokriva.
- **RatchetLaw** — zanimivo za quality ratchet (glej spodaj).

### TSP partitioners (poenostavljeni)

- **Flip, Hilbert, Delaunay, KMeans, Savings, Strip, TEP, HyperDim** — za 15×15 bi rabili pravo particioniranje, za 9×9 MSTD clusters zadostujejo.

### NAS (specifično ali redundantno)

- **Terrain roughness (B3)** — = Density Flow iz Sudoku (glej spodaj).
- **Poly-fovea (B2)** — multi-restart, podobno counterfactual beam (glej spodaj).
- **Drain vs greedy disagreement (B4)** — diagnostika, ne sensor.
- **Echo stability (B8)** — perturbation response, zahtevno.
- **AffinitySensor / FamilySensor** — specifično za NAS multi-model.

### Sudoku (manjkajoče, obetavne)

- **Density Flow (ρ=-0.76)** — gladkost domain reduction. LZ76 na sekvenci total-domain-sizes.
- **LZ Process (ρ=-0.79)** — kompresibilnost solving procesa samega. Najmočnejše kar manjka.
- **Cascade Power (ρ=+0.84)** — weighted cascade: depth × entropy-delta. v7 ima depth brez ponderiranja.
- **ADSR bimodality** — meri mask difficulty, ne solver quality.

---

## NI dodano — quality-side (iz G semen)

To je gap ki ga v7 ne pokriva. GPT identificira 3 ključne koncepte:

### Board Basin Discovery (G #7)

**Problem:** v5c najde 4 unique boarde v 444 trialih. Zakaj? Ali obstaja structuralni razlog da solver vedno pade v isti attractor?

**Preslikava:** clustering solved boardov v feature space. Features: word lengths distribution, crossing letter frequencies, hinted/unhinted ratio, position of long words. Kmeans ali DBSCAN na teh featurih pokaže ali obstajajo ločeni basini.

**Kako pomaga:** če poznamo basin mapo, lahko CMA-ES *cilja* različne basine namesto da konvergira k enemu. Elite diversity je slab proxy za to — diversity na parameter space ni isto kot diversity na board space.

**Implementacija:** post-hoc diagnostika (ne v solverju). `cw_basin_analysis.py` ki vzame leaderboard.jsonl in vrne basin map.

### Counterfactual Beam (G #10)

**Problem:** solver naredi zgodnjo odločitev (npr. ARCTIC na slot 0) in se zaklene. Vse nadaljnje rešitve so variante istega skeleta.

**Preslikava:** namesto single DFS, drži 2-3 "shadow" poti pri prvih K odločitvah. Po depth K izberi najboljšo po DCC/quality signal in nadaljuj single-path.

**Kako pomaga:** prepreči early lock-in v dominanten attractor. Solver vidi periferno — ali bi bila druga beseda na slot 0 vodila v boljši basin.

**Implementacija:** modificiraj `_search` da pri depth < K (K~3) ne gre v rekurzijo takoj, ampak shrani top-M alternativ. Po depth K izberi best po kumulativnem DCC delta in nadaljuj single-path. Tunable: `beam_depth` (0-5), `beam_width` (1-4).

### Style Coherence Field (G #9)

**Problem:** board z ARCTIC, RAPINE, THENCE, HEDGER zveni kot pet različnih svetov. Ni nelegalen, ampak ni lep.

**Preslikava:** vsaka beseda dobi style bucket (common / literary / archaic / technical / informal). Style entropy boarda = quality signal. Nizka entropy = koherenten slog.

**Kako pomaga:** CMA-ES dobi nov quality signal ki loči "zaprto" od "lepo zaprto". Dopolnjuje q_ugly in q_hinted ki merita word-level quality, ne board-level coherence.

**Implementacija:** style bucketing v lexicon scoring pipeline (cw_score_words.py). Dodaj `style` field v scored JSON. V areni: `q_style_entropy` quality parameter. Tunable, CMA-ES zerira če ne pomaga.

---

## Sinteza: kaj manjka za v8

### Closure-side (iz Sudoku — dokazano z ρ)

| Prioriteta | Sensor | ρ v Sudoku | Implementacija |
|-----------|--------|-----------|---------------|
| 1 | LZ Process | -0.79 | LZ76 na search decision sekvenci |
| 2 | Density Flow | -0.76 | LZ76 na total-domain-size sekvenci |
| 3 | Cascade Power | +0.84 | Upgrade #7: depth × domain-reduction |

### Quality-side (iz G semen — logično, ampak nepotrjeno)

| Prioriteta | Koncept | Tip | Implementacija |
|-----------|---------|-----|---------------|
| 1 | Board Basin Discovery | diagnostika | Clustering solved boardov, basin map |
| 2 | Counterfactual Beam | search modification | Shadow paths pri depth < K |
| 3 | Style Coherence | quality signal | Style bucketing + q_style_entropy |

### Hybrid (TSP law + G insight)

| Prioriteta | Koncept | Iz | Implementacija |
|-----------|---------|-----|---------------|
| 1 | Quality Ratchet | TSP RatchetLaw + G basin | Po vsaki rešitvi dvigni min quality. Solver naravno prehaja od "najdi karkoli" k "najdi dobro" |
| 2 | Scent Trail | NAS B7 + G echo ping | Crossing letter history kot consistency signal |

---

## Predlagan plan

**Faza 1: diagnostika (pred v8)**
Preden dodamo nove senzorje, rabimo vedeti KAJ je problem. Basin analysis na v6/v7 rezultatih pokaže:
- koliko structuralnih tipov boardov obstaja za dense9_a masko?
- ali solver konvergira k enemu basinu zarad gatinga, zarad MRV, ali zarad lexicona?
- ali obstajajo lepi basini ki jih solver nikoli ne najde?

To je en Python skript, ne sprememba solverja.

**Faza 2: v8 closure upgrade**
LZ Process + Density Flow + Cascade Power. Trije Sudoku senzorji z ρ > 0.76. Samo dodaj v `_search` in `_order`.

**Faza 3: v8 quality upgrade**
Counterfactual beam + Quality ratchet + Style coherence (če imamo style bucketing v lexiconu).

P16: arena odloči kaj preživi. Vse ima bounds, vse je zerirable.

---

*Črt · AIM³ Lab · v7: 10 sensors (closure). v8 target: closure + quality + basin awareness.*
*Skupaj z G — tim dela.*
