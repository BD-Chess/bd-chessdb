#!/usr/bin/env node
'use strict';

const path = require('path');
const { loadPreparedSource } = require('./cw_sources');
const { generateWithPolicy, comparePolicies, puzzleJson, POLICIES, renderGrid } = require('./cw_bun_core');
const { writeJson, writeCsv, ensureDir } = require('./cw_export');

function usage() {
  console.log(`
CW Bun Headless v1 — MDL×DCC crossword constructor

Modes:
  generate   Create one puzzle JSON
  compare    Compare multiple policies on same setup
  batch      Generate many runs and emit summary CSV
  eval       Re-score existing puzzle JSON

Examples:
  node cw_bun_cli.js generate --lang sl --size 9 --policy dense_first --seed 42 --source data/cw_sl_scored.json --out out/sl9.json
  node cw_bun_cli.js generate --lang en --size 11 --policy polish_first --seed 77 --source data/cw_en_scored.json --out out/en11.json
  node cw_bun_cli.js compare --lang en --size 9 --seed 42 --source data/cw_en_scored.json --outdir out/compare_en9
  node cw_bun_cli.js batch --lang sl --size 9 --runs 4 --source data/cw_sl_scored.json --outdir out/batch_sl9
`);
}

function parseArgs(argv) {
  const mode = argv[2];
  const opts = {
    lang: 'en',
    size: 9,
    policy: 'dense_first',
    seed: '1',
    source: null,
    out: null,
    outdir: null,
    runs: 4,
    policies: Object.keys(POLICIES),
    minScore: 55,
    merge: null,
    includeTopics: null,
    excludeTopics: null,
    ageProfile: null,
    maxPerLength: 400,
  };
  for (let i = 3; i < argv.length; i++) {
    const k = argv[i];
    const v = argv[i + 1];
    switch (k) {
      case '--lang': opts.lang = v; i++; break;
      case '--size': opts.size = Number(v); i++; break;
      case '--policy': opts.policy = v; i++; break;
      case '--seed': opts.seed = v; i++; break;
      case '--source': opts.source = v; i++; break;
      case '--out': opts.out = v; i++; break;
      case '--outdir': opts.outdir = v; i++; break;
      case '--runs': opts.runs = Number(v); i++; break;
      case '--policies': opts.policies = String(v).split(',').map(s => s.trim()).filter(Boolean); i++; break;
      case '--min-score': opts.minScore = Number(v); i++; break;
      case '--merge': opts.merge = v; i++; break;
      case '--include-topics': opts.includeTopics = v; i++; break;
      case '--exclude-topics': opts.excludeTopics = v; i++; break;
      case '--age-profile': opts.ageProfile = v; i++; break;
      case '--max-per-length': opts.maxPerLength = Number(v); i++; break;
      case '--help': usage(); process.exit(0); break;
      default:
        console.warn('Unknown arg:', k);
    }
  }
  return { mode, opts };
}

function loadSource(opts) {
  return loadPreparedSource({
    lang: opts.lang,
    source: opts.source,
    baseDir: process.cwd(),
    minScore: opts.minScore,
    merge: opts.merge,
    includeTopics: opts.includeTopics,
    excludeTopics: opts.excludeTopics,
    ageProfile: opts.ageProfile,
    maxPerLength: opts.maxPerLength,
  });
}

function runGenerate(opts) {
  const source = loadSource(opts);
  const result = generateWithPolicy(source, opts);
  const payload = puzzleJson(result, source, opts);
  const out = opts.out || path.join(opts.outdir || 'out', `${opts.lang}_${opts.size}_${opts.policy}_${opts.seed}.json`);
  writeJson(out, payload);
  console.log(`[generate] ${out}`);
  console.log(renderGrid(result.grid));
  console.log('score=', result.score.total, 'solved=', result.solved, 'policy=', result.policy);
}

function runCompare(opts) {
  const source = loadSource(opts);
  const cmp = comparePolicies(source, opts);
  const outdir = opts.outdir || path.join('out', `compare_${opts.lang}_${opts.size}_${opts.seed}`);
  ensureDir(outdir);
  writeJson(path.join(outdir, 'comparison_summary.json'), cmp.ranking);
  writeCsv(path.join(outdir, 'comparison_summary.csv'), cmp.ranking);
  for (const r of cmp.results) {
    writeJson(path.join(outdir, `${r.policy}.puzzle.json`), puzzleJson(r, source, opts));
  }
  console.log(`[compare] winner=${cmp.winner.policy} solved=${cmp.winner.solved} score=${cmp.winner.score.total}`);
  console.table(cmp.ranking);
}

function runBatch(opts) {
  const source = loadSource(opts);
  const outdir = opts.outdir || path.join('out', `batch_${opts.lang}_${opts.size}`);
  ensureDir(outdir);
  const rows = [];
  for (let i = 0; i < opts.runs; i++) {
    const seed = `${opts.seed}_${i + 1}`;
    const cmp = comparePolicies(source, { ...opts, seed });
    const best = cmp.winner;
    const file = path.join(outdir, `run_${i + 1}_${best.policy}.json`);
    writeJson(file, puzzleJson(best, source, { ...opts, seed }));
    rows.push({
      run: i + 1,
      seed,
      policy: best.policy,
      solved: best.solved,
      totalScore: best.score.total,
      blackRatio: best.score.metrics.blackRatio,
      crossingDensity: best.score.metrics.crossingDensity,
      averageWordScore: best.score.metrics.averageWordScore,
      uncheckedLetters: best.score.metrics.uncheckedLetters,
      backtracks: best.traceMeta.backtracks,
      file,
    });
  }
  writeCsv(path.join(outdir, 'batch_summary.csv'), rows);
  writeJson(path.join(outdir, 'batch_summary.json'), rows);
  console.table(rows);
}

function runEval(opts) {
  if (!opts.source) throw new Error('eval mode expects --source existingPuzzle.json');
  const payload = require(path.resolve(opts.source));
  const row = {
    solved: payload.solved,
    totalScore: payload.finalScoreSummary?.total,
    blackRatio: payload.metrics?.blackRatio,
    crossingDensity: payload.metrics?.crossingDensity,
    averageWordScore: payload.metrics?.averageWordScore,
    uncheckedLetters: payload.metrics?.uncheckedLetters,
    winningStrategy: payload.winningStrategy,
  };
  console.table([row]);
}

if (require.main === module) {
  const { mode, opts } = parseArgs(process.argv);
  if (!mode || mode === 'help') { usage(); process.exit(0); }
  try {
    if (mode === 'generate') runGenerate(opts);
    else if (mode === 'compare') runCompare(opts);
    else if (mode === 'batch') runBatch(opts);
    else if (mode === 'eval') runEval(opts);
    else usage();
  } catch (err) {
    console.error(err.stack || err.message || String(err));
    process.exit(1);
  }
}
