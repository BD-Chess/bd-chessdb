#!/usr/bin/env python3
"""
cw_ai8_arena_v7.py — Crossword Arena v7 (Črt / AIM³ Lab)

v7 = v6 proven core + 10 cross-domain sensor layers from TSP/NAS/Sudoku/Chess:

  #1  DCC during search    — compression delta as candidate scoring signal (TSP)
  #2  MSTD clusters        — solve by connected slot groups, not global MRV (TSP)
  #3  Pyramid keystones    — multi-view reveals critical crossing positions (TSP)
  #4  Echolocation         — quality-weighted support echo, not raw count (TSP)
  #5  Resonance            — letter rarity at crossings × support quality (CCH)
  #6  Edge sensitivity     — pre-computed slot criticality for selection (NAS)
  #7  Cascade depth        — prefer words that force more slots (Sudoku Gini ρ=0.83)
  #8  Frozen crossing      — forced slots (domain=1) placed immediately (Sudoku naked single)
  #9  ADSR search control  — detect dead branches, backtrack early (TSP ADSR law)
  #10 Flood & Drain        — dynamic gating: loosen when stuck, tighten when flowing (NAS)

All sensors have arena-tunable weights (can be zeroed → falls back to v6).
AC-3 + constraint propagation core is UNTOUCHED.
Sensors only affect heuristic layer: _choose (slot selection) and _order (candidate ranking).

P16: arena decides which sensors help. We don't exclude before measuring.
"""

import argparse, ast, concurrent.futures as cf, json, math, os, random, re
import signal, statistics, sys, time
from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from pathlib import Path

# ═══════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════

MASKS = {
    'dense9_a': [
        '......###', '......###', '.......##',
        '....#....', '...###...', '....#....',
        '##.......', '###......', '###......',
    ],
}

VOWELS = set('AEIOUY')
WEIRD = {'EEO', 'DPI', 'TRUG', 'INRI', 'EEOC', 'LII', 'TVA', 'OTB', 'ETA', 'PTA'}
MAX_PER_LEN = 4000
EPS = 1e-9

# FIXED solver weights — proven, never tuned
SUPPORT_W = 3.0
MINSUP_W = 2.0
FORCED_W = 1.5
TOPN_EARLY = 80
TOPN_LATE = 120
TOPN_SWITCH = 10


# ═══════════════════════════════════════════════════
# MDL signals
# ═══════════════════════════════════════════════════

def lz76c(s):
    if not s:
        return 0.0
    n = len(s); c = 0; seen = set(); i = 0
    while i < n:
        j = i + 1
        while j <= n and s[i:j] in seen:
            j += 1
        seen.add(s[i:j]); c += 1; i = j
    return c / max(1.0, n / max(1.0, math.log2(n + 1.0)))


def shannon(s):
    if not s:
        return 0.0
    cnt = Counter(s); n = len(s)
    return -sum((v / n) * math.log2(v / n + EPS) for v in cnt.values())


# ═══════════════════════════════════════════════════
# Arena-tunable params
# ═══════════════════════════════════════════════════

@dataclass
class QP:
    # ── Gating (from v6, proven) ──
    core_depth: float = 5.0
    stage2_depth: float = 14.0
    core_min_score: float = 72.0
    bal_min_score: float = 40.0
    # ── Quality ranking (from v6) ──
    q_ugly: float = 25.0
    q_hinted: float = 30.0
    q_avgscore: float = 3.0
    q_mdl: float = 8.0
    q_entropy: float = 4.0
    q_weird: float = 14.0
    # ── Cross-domain sensors (v7 NEW) ──
    w_dcc: float = 2.0           # #1 DCC compression delta
    w_echo: float = 1.0          # #4 echo quality blend (0=off, higher=more quality-weighted)
    w_resonance: float = 1.5     # #5 letter-rarity resonance
    w_sensitivity: float = 1.0   # #6 + #3 slot sensitivity (keystones) in _choose
    w_cluster: float = 1.0       # #2 MSTD cluster coherence in _choose
    # ── Cross-domain sensors (v7b — from TSP/NAS/Sudoku deep analysis) ──
    w_cascade: float = 1.5       # #7 Sudoku Gini cascade: prefer words that force more slots
    w_frozen: float = 3.0        # #8 Sudoku naked single: bonus for forced slots in _choose
    adsr_patience: float = 5.0   # #9 TSP ADSR: max consecutive fruitless depths before early backtrack
    flood_drain: float = 0.15    # #10 NAS flood/drain: gating loosens when stuck (fraction of score drop)


QP_BOUNDS = {
    'core_depth':     (2.0, 8.0),
    'stage2_depth':   (8.0, 20.0),
    'core_min_score': (55.0, 82.0),
    'bal_min_score':  (10.0, 55.0),
    'q_ugly':         (5.0, 50.0),
    'q_hinted':       (5.0, 70.0),
    'q_avgscore':     (0.5, 10.0),
    'q_mdl':          (0.0, 25.0),
    'q_entropy':      (0.0, 15.0),
    'q_weird':        (0.0, 30.0),
    'w_dcc':          (0.0, 8.0),
    'w_echo':         (0.0, 5.0),
    'w_resonance':    (0.0, 5.0),
    'w_sensitivity':  (0.0, 5.0),
    'w_cluster':      (0.0, 5.0),
    'w_cascade':      (0.0, 5.0),
    'w_frozen':       (0.0, 10.0),
    'adsr_patience':  (2.0, 12.0),
    'flood_drain':    (0.0, 0.5),
}

QP_SEED = {k: getattr(QP(), k) for k in QP_BOUNDS}


# ═══════════════════════════════════════════════════
# Solver
# ═══════════════════════════════════════════════════

class Solver:
    def __init__(self, source, qp=None, mask='dense9_a',
                 budget=30.0, banned=None, seed=0):
        with open(source, 'r', encoding='utf-8') as f:
            data = json.load(f)
        self.lang = data.get('lang', 'en')
        self.bylen = {int(k): list(v) for k, v in data['words'].items()}
        for l, arr in self.bylen.items():
            arr.sort(key=lambda x: (-(x.get('s', 0)), -(1 if x.get('h') else 0), x['w']))
            if len(arr) > MAX_PER_LEN:
                self.bylen[l] = arr[:MAX_PER_LEN]
        self.wbl = {l: [x['w'] for x in arr] for l, arr in self.bylen.items()}
        self.mask_rows = MASKS[mask]
        self.R = len(self.mask_rows)
        self.C = len(self.mask_rows[0])
        self.slots = self._build_slots()
        self.nbrs = {s['id']: set(s2 for _, s2, _ in s['xr']) for s in self.slots}
        self.asets = {l: set(range(len(a))) for l, a in self.wbl.items()}
        self.ban = {w.upper() for w in (banned or set())}
        self.qp = qp or QP()
        self.budget = budget
        self.t0 = 0.0
        self.nodes = 0
        self.sols = []
        self.best_d = 0
        self.best_p = None
        self.first_t = None
        self.rej = Counter()
        # v7b: ADSR stagnation tracker (#9)
        self.stagnation = 0  # consecutive depths without progress
        # v7b: flood/drain dynamic gating state (#10)
        self.gate_offset = 0.0  # negative = loosened (flood), positive = tightened (drain)
        # v7: pre-compute topology signals
        self._precompute_topology()

    # ── Slot extraction (unchanged) ──

    def _build_slots(self):
        slots = []
        for o in 'AD':
            rows = range(self.R) if o == 'A' else range(self.C)
            for primary in rows:
                sec = 0
                limit = self.C if o == 'A' else self.R
                while sec < limit:
                    r, c = (primary, sec) if o == 'A' else (sec, primary)
                    if self.mask_rows[r][c] != '#' and (sec == 0 or
                            (self.mask_rows[r][c - 1] if o == 'A' else self.mask_rows[r - 1][c]) == '#'):
                        end = sec
                        while end < limit:
                            rr, cc = (primary, end) if o == 'A' else (end, primary)
                            if self.mask_rows[rr][cc] == '#':
                                break
                            end += 1
                        if end - sec >= 3:
                            cells = [(primary, j) for j in range(sec, end)] if o == 'A' \
                                else [(j, primary) for j in range(sec, end)]
                            slots.append({'id': len(slots), 'o': o, 'cells': cells, 'len': end - sec})
                        sec = end
                    else:
                        sec += 1
        cm = defaultdict(list)
        for s in slots:
            for p, cell in enumerate(s['cells']):
                cm[cell].append((s['id'], p))
        for s in slots:
            s['xr'] = [(p, s2, p2) for p, cell in enumerate(s['cells'])
                       for s2, p2 in cm[cell] if s2 != s['id']]
        return slots

    # ══════════════════════════════════════════════
    # v7: TOPOLOGY PRE-COMPUTATION
    # ══════════════════════════════════════════════

    def _precompute_topology(self):
        """Compute all static topology signals once."""
        self._compute_letter_freq()      # for resonance (#5)
        self._compute_sensitivity()      # for edge sensitivity + keystones (#3, #6)
        self._compute_clusters()         # for MSTD (#2)

    def _compute_letter_freq(self):
        """Letter frequency at each position per word length — for resonance."""
        # freq[word_len][position][char] = count in lexicon
        self.letter_freq = {}
        for l, arr in self.bylen.items():
            pos_freq = [Counter() for _ in range(l)]
            for meta in arr:
                for i, ch in enumerate(meta['w']):
                    pos_freq[i][ch] += 1
            self.letter_freq[l] = pos_freq

    def _compute_sensitivity(self):
        """Slot criticality: crossings weighted by partner length.
        Merges edge sensitivity (#6) with pyramid keystones (#3):
        a slot crossing long words through rare positions is critical."""
        self.sensitivity = {}
        for s in self.slots:
            # Each crossing contributes: partner_len (longer partner = more impact)
            cross_weight = sum(self.slots[s2]['len'] for _, s2, _ in s['xr'])
            domain_size = len(self.asets.get(s['len'], set()))
            # High crossings + small domain = critical slot
            self.sensitivity[s['id']] = cross_weight / max(1.0, math.log(domain_size + 1))
        # Normalize to [0, 1]
        max_s = max(self.sensitivity.values()) if self.sensitivity else 1.0
        for sid in self.sensitivity:
            self.sensitivity[sid] /= max(max_s, EPS)

    def _compute_clusters(self):
        """MSTD-style slot clustering by crossing connectivity."""
        adj = defaultdict(set)
        for s in self.slots:
            for _, s2, _ in s['xr']:
                adj[s['id']].add(s2)
                adj[s2].add(s['id'])
        self.slot_cluster = {}
        cluster_id = 0
        remaining = set(s['id'] for s in self.slots)
        target_size = max(4, len(self.slots) // 4)
        while remaining:
            start = max(remaining, key=lambda s: len(adj[s] & remaining))
            cluster = set()
            queue = deque([start])
            while queue and len(cluster) < target_size:
                sid = queue.popleft()
                if sid not in remaining:
                    continue
                cluster.add(sid)
                remaining.remove(sid)
                self.slot_cluster[sid] = cluster_id
                # Add neighbors sorted by degree (most connected first)
                for nb in sorted(adj[sid] & remaining,
                                 key=lambda s: len(adj[s] & remaining), reverse=True):
                    queue.append(nb)
            cluster_id += 1
        self.n_clusters = cluster_id

    # ══════════════════════════════════════════════
    # v7: SENSOR FUNCTIONS
    # ══════════════════════════════════════════════

    def _board_string(self, asgn):
        """Build partial board string for DCC measurement."""
        brd = [list(r) for r in self.mask_rows]
        for sid, idx in asgn.items():
            sl = self.slots[sid]
            w = self.wbl[sl['len']][idx]
            for (r, c), ch in zip(sl['cells'], w):
                brd[r][c] = ch
        rows_s = '|'.join(''.join(c for c in row if c != '#') for row in brd)
        cols_s = '|'.join(''.join(brd[r][c] for r in range(self.R) if brd[r][c] != '#')
                          for c in range(self.C))
        return rows_s + '||' + cols_s

    def _dcc_delta(self, asgn, sid, idx):
        """#1 DCC: compression improvement from placing word idx at slot sid."""
        base_mdl = lz76c(self._board_string(asgn))
        test_asgn = dict(asgn)
        test_asgn[sid] = idx
        new_mdl = lz76c(self._board_string(test_asgn))
        # Positive = compression improved (lower MDL after adding structure)
        # Negative = adding noise
        return base_mdl - new_mdl

    def _echo_quality(self, s2, p2, ch, dom, asgn, used):
        """#4 Echolocation: quality-weighted support from crossing slot.
        Returns (count, quality_sum) — blend controlled by w_echo."""
        arr = self.wbl[self.slots[s2]['len']]
        count = 0
        quality_sum = 0.0
        for j in self._cd(self.slots[s2], dom, asgn, used):
            if arr[j][p2] == ch:
                meta = self.bylen[self.slots[s2]['len']][j]
                count += 1
                quality_sum += meta.get('s', 0) + (14 if meta.get('h') else 0)
        return count, quality_sum

    def _crossing_resonance(self, slot, word, asgn):
        """#5 Resonance: sum of letter-rarity at crossing positions.
        Rare letter at a crossing = high resonance = more structural."""
        resonance = 0.0
        for p, s2, p2 in slot['xr']:
            if s2 in asgn:
                continue
            ch = word[p]
            partner_len = self.slots[s2]['len']
            if partner_len in self.letter_freq and p2 < len(self.letter_freq[partner_len]):
                freq = self.letter_freq[partner_len][p2].get(ch, 0)
                total = sum(self.letter_freq[partner_len][p2].values())
                if total > 0 and freq > 0:
                    # Rarity = inverse relative frequency, log-scaled
                    resonance += math.log(total / freq)
        return resonance

    # ── Gating (from v6, unchanged) ──

    def _gate(self, meta, depth):
        w = meta['w']
        if w in self.ban:
            return False
        s = meta.get('s', 0)
        has_hint = bool(meta.get('h'))
        cd = int(round(self.qp.core_depth))
        s2d = int(round(max(self.qp.stage2_depth, cd + 1)))
        # #10 Flood/drain: lower thresholds when stuck (gate_offset < 0)
        core_thr = max(10.0, self.qp.core_min_score + self.gate_offset)
        bal_thr = max(5.0, self.qp.bal_min_score + self.gate_offset)
        if depth < cd:
            if s < core_thr:
                return False
            if len(w) <= 4 and not has_hint:
                return False
            return True
        elif depth < s2d:
            return s >= bal_thr
        return True

    # ── AC-3 core (FIXED, UNTOUCHED) ──

    def _cd(self, slot, dom, asgn, used):
        sid = slot['id']
        if sid in asgn:
            return {asgn[sid]}
        arr = self.wbl[slot['len']]
        out = set()
        for idx in dom[sid]:
            w = arr[idx]
            if w in used or w in self.ban:
                continue
            ok = True
            for p, s2, p2 in slot['xr']:
                if s2 in asgn:
                    if w[p] != self.wbl[self.slots[s2]['len']][asgn[s2]][p2]:
                        ok = False
                        break
            if ok:
                out.add(idx)
        return out

    def _revise(self, dom, xi, xj, used, asgn):
        xrs = [(pi, pj) for pi, s2, pj in self.slots[xi]['xr'] if s2 == xj]
        if not xrs:
            return False
        di = self._cd(self.slots[xi], dom, asgn, used)
        dj = self._cd(self.slots[xj], dom, asgn, used)
        if not di or not dj:
            dom[xi] = set()
            return True
        ai = self.wbl[self.slots[xi]['len']]
        aj = self.wbl[self.slots[xj]['len']]
        sup = [(pi, set(aj[j][pj] for j in dj)) for pi, pj in xrs]
        rem = {i for i in di if any(ai[i][pi] not in lts for pi, lts in sup)}
        if rem:
            dom[xi] = di - rem
            return True
        dom[xi] = di
        return False

    def _ac3(self, dom, used, asgn):
        q = deque((xi, xj) for xi in range(len(self.slots)) for xj in self.nbrs[xi])
        while q:
            xi, xj = q.popleft()
            if self._revise(dom, xi, xj, used, asgn):
                if not dom[xi]:
                    return False
                for xk in self.nbrs[xi] - {xj}:
                    q.append((xk, xi))
        return True

    # ── Slot selection: MRV + sensitivity + cluster (#2, #3, #6) ──

    def _choose(self, dom, asgn, used):
        best_sid, best_key = None, None
        frozen_sid = None  # #8: slot with domain=1 (naked single)

        cluster_fill = Counter()
        for sid in asgn:
            cluster_fill[self.slot_cluster.get(sid, 0)] += 1
        active_cluster = cluster_fill.most_common(1)[0][0] if cluster_fill else None

        for slot in self.slots:
            sid = slot['id']
            if sid in asgn:
                continue
            d = self._cd(slot, dom, asgn, used)
            dom[sid] = d
            filled = sum(1 for _, s2, _ in slot['xr'] if s2 in asgn)

            # #8 Frozen crossing: if domain=1, it's forced — do it NOW
            if len(d) == 1 and self.qp.w_frozen > 0.1:
                if frozen_sid is None:
                    frozen_sid = sid

            mrv = len(d)
            sens_bonus = self.sensitivity.get(sid, 0) * self.qp.w_sensitivity
            cluster_bonus = self.qp.w_cluster if (
                active_cluster is not None and
                self.slot_cluster.get(sid, -1) == active_cluster
            ) else 0.0

            key = (mrv - sens_bonus - cluster_bonus, -filled, -slot['len'])
            if best_key is None or key < best_key:
                best_key = key
                best_sid = sid

        # #8: forced slot overrides all heuristics
        if frozen_sid is not None:
            return frozen_sid
        return best_sid

    # ── Candidate ordering: support + DCC + echo + resonance (#1, #4, #5) ──

    def _order(self, sid, dom, asgn, used):
        slot = self.slots[sid]
        depth = len(asgn)
        d = self._cd(slot, dom, asgn, used)

        # #1 DCC: pre-compute base MDL once for this slot
        use_dcc = self.qp.w_dcc > 0.1
        if use_dcc:
            base_str = self._board_string(asgn)
            base_mdl = lz76c(base_str)

        scored = []
        for idx in d:
            meta = self.bylen[slot['len']][idx]
            if not self._gate(meta, depth):
                self.rej['gated'] += 1
                continue
            w = meta['w']

            # ── FIXED lexical score (unchanged from v6) ──
            val = meta.get('s', 0) + (14 if meta.get('h') else 0)
            val += 4.0 * len(set(w)) / len(w)
            if not meta.get('h'):
                val -= 18
            if len(w) <= 4 and sum(c in VOWELS for c in w) <= 1:
                val -= 12
            if re.search(r'(.)\1\1', w):
                val -= 8
            if len(set(w)) <= 2:
                val -= 8
            if w in WEIRD or w in self.ban:
                val -= 22

            # ── Support counting with echo quality (#4) ──
            minsup, total, zero = 999999, 0, False
            echo_total = 0.0
            for p, s2, p2 in slot['xr']:
                if s2 in asgn:
                    continue
                if self.qp.w_echo > 0.1:
                    cnt, eq = self._echo_quality(s2, p2, w[p], dom, asgn, used)
                    echo_total += eq
                else:
                    cnt = self._sup_count(s2, p2, w[p], dom, asgn, used)
                if cnt == 0:
                    zero = True
                    break
                total += cnt
                minsup = min(minsup, cnt)
            if zero:
                self.rej['zero_sup'] += 1
                continue

            # FIXED support score
            val += SUPPORT_W * math.log(total + 1) + MINSUP_W * math.log(minsup + 1)
            # #4 Echo quality bonus
            if self.qp.w_echo > 0.1:
                val += self.qp.w_echo * math.log(echo_total + 1) * 0.1

            # ── #5 Resonance ──
            if self.qp.w_resonance > 0.1:
                res = self._crossing_resonance(slot, w, asgn)
                val += self.qp.w_resonance * res

            # ── #1 DCC compression delta ──
            if use_dcc:
                test_asgn = dict(asgn)
                test_asgn[sid] = idx
                new_mdl = lz76c(self._board_string(test_asgn))
                dcc_delta = base_mdl - new_mdl
                val += self.qp.w_dcc * dcc_delta

            # ── #7 Cascade depth (Sudoku Gini cascade) ──
            if self.qp.w_cascade > 0.1:
                cascade = 0
                for p, s2, p2 in slot['xr']:
                    if s2 in asgn:
                        continue
                    arr2 = self.wbl[self.slots[s2]['len']]
                    # How many candidates survive for crossing slot after this word?
                    survivors = sum(1 for j in self._cd(self.slots[s2], dom, asgn, used)
                                    if arr2[j][p2] == w[p])
                    if survivors == 1:
                        cascade += 1  # This crossing becomes forced = cascade
                    elif survivors <= 3:
                        cascade += 0.3  # Near-forced = partial cascade
                val += self.qp.w_cascade * cascade

            scored.append((val, idx))

        scored.sort(reverse=True)
        topn = TOPN_EARLY if depth < TOPN_SWITCH else TOPN_LATE
        return [idx for _, idx in scored[:topn]]

    def _sup_count(self, s2, p2, ch, dom, asgn, used):
        """Raw support count (fallback when echo is off)."""
        arr = self.wbl[self.slots[s2]['len']]
        return sum(1 for j in self._cd(self.slots[s2], dom, asgn, used) if arr[j][p2] == ch)

    # ── Search (FIXED, UNTOUCHED) ──

    def _search(self, dom, asgn, used):
        self.nodes += 1
        depth = len(asgn)
        if depth > self.best_d:
            self.best_d = depth
            self.best_p = dict(asgn)
            self.stagnation = 0  # #9: reset on progress
        else:
            self.stagnation += 1
        if depth == len(self.slots):
            self.sols.append(dict(asgn))
            if self.first_t is None:
                self.first_t = time.time() - self.t0
            return False
        if time.time() - self.t0 > self.budget:
            return True
        # #9 ADSR early backtrack: if stuck for too long at this depth band
        patience = int(round(self.qp.adsr_patience))
        if self.stagnation > patience * max(1, len(self.slots) - depth):
            self.rej['adsr_backtrack'] = self.rej.get('adsr_backtrack', 0) + 1
            return False
        # #10 Flood/drain: assess domain health, adjust gate_offset
        if self.qp.flood_drain > 0.01:
            total_dom = sum(len(dom.get(s['id'], set())) for s in self.slots if s['id'] not in asgn)
            remaining = len(self.slots) - depth
            avg_dom = total_dom / max(1, remaining)
            if avg_dom < 3.0:
                # Domains drying up → FLOOD: loosen gating
                self.gate_offset = -self.qp.flood_drain * self.qp.core_min_score
            elif avg_dom > 50.0:
                # Plenty of candidates → DRAIN: tighten gating
                self.gate_offset = self.qp.flood_drain * 10.0
            else:
                # Normal → reset
                self.gate_offset *= 0.5
        sid = self._choose(dom, asgn, used)
        if sid is None or not dom[sid]:
            return False
        for idx in self._order(sid, dom, asgn, used):
            w = self.wbl[self.slots[sid]['len']][idx]
            if w in used:
                continue
            d2 = {k: set(v) for k, v in dom.items()}
            a2 = dict(asgn)
            u2 = set(used)
            a2[sid] = idx
            u2.add(w)
            d2[sid] = {idx}
            ok = True
            for p, s2, p2 in self.slots[sid]['xr']:
                if s2 in a2:
                    continue
                arr2 = self.wbl[self.slots[s2]['len']]
                nd = {j for j in self._cd(self.slots[s2], d2, a2, u2) if arr2[j][p2] == w[p]}
                d2[s2] = nd
                if not nd:
                    ok = False
                    break
            if not ok:
                continue
            if not self._ac3(d2, u2, a2):
                continue
            if self._search(d2, a2, u2):
                return True
        return False

    # ── Board + signals + quality ──

    def board(self, asgn):
        b = [list(r) for r in self.mask_rows]
        for sid, idx in asgn.items():
            sl = self.slots[sid]
            w = self.wbl[sl['len']][idx]
            for (r, c), ch in zip(sl['cells'], w):
                b[r][c] = ch
        return [''.join(r) for r in b]

    def words(self, asgn):
        out = []
        for sid, idx in sorted(asgn.items()):
            m = self.bylen[self.slots[sid]['len']][idx]
            out.append({'sid': sid, 'o': self.slots[sid]['o'], 'len': self.slots[sid]['len'],
                        'w': m['w'], 'h': m.get('h', ''), 's': m.get('s', 0)})
        return out

    def signals(self, asgn):
        brd = self.board(asgn)
        rows_s = '|'.join(''.join(c for c in row if c != '#') for row in brd)
        cols_s = '|'.join(''.join(brd[r][c] for r in range(self.R) if brd[r][c] != '#')
                          for c in range(self.C))
        letters = ''.join(c for row in brd for c in row if c not in '.#')
        filled = sum(1 for c in letters)
        total = sum(1 for row in brd for c in row if c != '#')
        return {
            'sol_mdl': round(lz76c(rows_s + '||' + cols_s), 4),
            'cross_entropy': round(shannon(letters), 4),
            'fill_ratio': round(filled / max(1, total), 4),
        }

    def quality(self, asgn):
        ws = self.words(asgn)
        p = self.qp
        hinted = sum(1 for w in ws if w['h'])
        avg_s = sum(w['s'] for w in ws) / max(1, len(ws))
        ugly = sum(1 for w in ws if w['s'] < 65 and not w['h'])
        weird_n = sum(1 for w in ws if w['w'] in WEIRD)
        sig = self.signals(asgn)
        return (- p.q_ugly * ugly
                + p.q_hinted * (hinted / max(1, len(ws)))
                + p.q_avgscore * (avg_s / 100.0)
                - p.q_mdl * sig['sol_mdl']
                - p.q_entropy * sig['cross_entropy']
                - p.q_weird * weird_n)

    def run(self):
        dom = {s['id']: set(self.asets[s['len']]) for s in self.slots}
        if not self._ac3(dom, set(), {}):
            return {'solved': False, 'error': 'AC-3 init fail'}
        self.t0 = time.time()
        self._search(dom, {}, set())
        solved = len(self.sols) > 0
        best_a, best_q = None, -1e18
        for a in self.sols:
            q = self.quality(a)
            if q > best_q:
                best_q = q
                best_a = a
        if not solved:
            best_a = self.best_p or {}
        return {
            'solved': solved,
            'num_solutions': len(self.sols),
            'seconds': round(time.time() - self.t0, 3),
            'nodes': self.nodes,
            'best_partial_depth': self.best_d,
            'first_solved_at': round(self.first_t, 3) if self.first_t else None,
            'quality': round(best_q, 4) if solved else None,
            'board': self.board(best_a),
            'words': self.words(best_a),
            'signals': self.signals(best_a),
            'rejections': dict(self.rej),
        }


# ═══════════════════════════════════════════════════
# CMA-ES Arena (from v6 + elite diversity)
# ═══════════════════════════════════════════════════

def clamp(k, v):
    lo, hi = QP_BOUNDS[k]
    return max(lo, min(hi, float(v)))


def sample_qp(mean, sigma, rng):
    vals = {k: clamp(k, rng.gauss(mean[k], max(EPS, sigma[k]))) for k in QP_BOUNDS}
    vals['stage2_depth'] = max(vals['stage2_depth'], vals['core_depth'] + 1)
    return QP(**vals)


def elite_update(elites, mean, sigma, frac=0.35):
    nm, ns = {}, {}
    for k in QP_BOUNDS:
        vals = [e['params'][k] for e in elites]
        m = statistics.fmean(vals)
        s = statistics.pstdev(vals) if len(vals) > 1 else sigma[k] * 0.9
        span = QP_BOUNDS[k][1] - QP_BOUNDS[k][0]
        nm[k] = (1 - frac) * mean[k] + frac * m
        ns[k] = max(span * 0.03, (1 - frac) * sigma[k] + frac * max(s, span * 0.05))
    return nm, ns


def board_signature(result):
    if result.get('solved'):
        return tuple(result.get('board', []))
    return None


def select_elites(results, elite_n, diverse=True):
    solved = [r for r in results if r.get('solved')]
    if not solved or elite_n <= 0:
        return []
    solved.sort(key=lambda r: (r.get('quality') or -1e18), reverse=True)
    if not diverse:
        return solved[:elite_n]
    picked = []
    seen = set()
    for r in solved:
        sig = board_signature(r)
        if sig in seen:
            continue
        picked.append(r)
        seen.add(sig)
        if len(picked) >= elite_n:
            return picked
    for r in solved:
        if len(picked) >= elite_n:
            break
        if r not in picked:
            picked.append(r)
    return picked


def run_trial(job):
    qp = QP(**{k: job['params'][k] for k in QP_BOUNDS})
    s = Solver(job['source'], qp=qp, mask=job['mask'], budget=job['budget'],
               banned=set(job.get('banned', [])), seed=job['seed'])
    r = s.run()
    return {'trial_id': job['trial_id'], 'gen': job['gen'], 'seed': job['seed'],
            'params': job['params'], **r}


def save_json(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(str(path) + '.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def append_jsonl(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'a', encoding='utf-8') as f:
        f.write(json.dumps(obj, ensure_ascii=False) + '\n')


def main():
    ap = argparse.ArgumentParser(
        description='Crossword Arena v7 (Črt / AIM³ Lab) — 6 cross-domain sensors on proven core')
    ap.add_argument('--source', required=True)
    ap.add_argument('--mask', default='dense9_a', choices=sorted(MASKS))
    ap.add_argument('--outdir', required=True)
    ap.add_argument('--hours', type=float, default=1.0)
    ap.add_argument('--budget', type=float, default=35.0)
    ap.add_argument('--population', type=int, default=12)
    ap.add_argument('--elite', type=int, default=4)
    ap.add_argument('--workers', type=int, default=1)
    ap.add_argument('--no-diversity', action='store_true')
    ap.add_argument('--ban-words', default='')
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--fresh', action='store_true')
    args = ap.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    sp = outdir / 'arena_state.json'
    lb = outdir / 'leaderboard.jsonl'
    lock_path = outdir / 'arena.lock'
    use_diversity = not args.no_diversity

    banned = sorted({w.strip().upper() for w in args.ban_words.split(',') if w.strip()})
    rng = random.Random(args.seed)

    save_json(outdir / 'run_manifest.json', {
        'engine': 'cw_ai8_arena_v7',
        'source': args.source, 'mask': args.mask,
        'hours': args.hours, 'budget': args.budget,
        'population': args.population, 'elite': args.elite,
        'workers': args.workers, 'seed': args.seed,
        'elite_diversity': use_diversity,
        'sensors': ['DCC', 'MSTD_cluster', 'pyramid_keystone', 'echo_quality',
                    'resonance', 'edge_sensitivity', 'cascade_depth', 'frozen_crossing',
                    'ADSR_search', 'flood_drain'],
        'banned_words': banned,
        'created_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    })

    if lock_path.exists():
        raise SystemExit(f'Lock exists: {lock_path} — another run active?')
    save_json(lock_path, {'pid': os.getpid(), 'started': time.strftime('%Y-%m-%d %H:%M:%S')})

    interrupted = {'flag': False}
    def _sigint(signum, frame):
        interrupted['flag'] = True
        print('\n[arena_v7] Ctrl+C — will checkpoint after current generation...')
    old_handler = signal.signal(signal.SIGINT, _sigint)

    try:
        state = None if args.fresh else (json.load(open(sp)) if sp.exists() else None)
        if state:
            mean, sigma = state['mean'], state['sigma']
            gen0, tc = state['next_gen'], state.get('tc', 0)
            best = state.get('best')
            rng.setstate(ast.literal_eval(state['rng_state']))
            print(f'[arena_v7] resume gen={gen0} trials={tc}')
        else:
            mean = {k: float(QP_SEED[k]) for k in QP_BOUNDS}
            sigma = {k: (QP_BOUNDS[k][1] - QP_BOUNDS[k][0]) * 0.15 for k in QP_BOUNDS}
            gen0, tc, best = 0, 0, None
            print(f'[arena_v7] fresh start')

        deadline = time.time() + args.hours * 3600
        t_start = time.time()
        all_unique = set()

        print(f'[arena_v7] source={args.source} mask={args.mask} hours={args.hours}')
        print(f'[arena_v7] budget={args.budget}s pop={args.population} workers={args.workers}')
        print(f'[arena_v7] Sensors: DCC + MSTD + keystones + echo + resonance + sensitivity')
        print(f'[arena_v7]          cascade + frozen + ADSR + flood/drain')
        print(f'[arena_v7] elite_diversity={use_diversity}, {len(QP_BOUNDS)} tunable params')
        print(f'[arena_v7] P16: arena decides which sensors survive.\n')

        while time.time() < deadline and not interrupted['flag']:
            jobs = []
            for i in range(args.population):
                qp = sample_qp(mean, sigma, rng)
                jobs.append({
                    'trial_id': tc + i, 'gen': gen0,
                    'seed': rng.randint(0, 2**31 - 1),
                    'source': args.source, 'mask': args.mask,
                    'budget': args.budget, 'banned': banned,
                    'params': {k: getattr(qp, k) for k in QP_BOUNDS},
                })
            tc += len(jobs)

            if args.workers <= 1:
                results = [run_trial(j) for j in jobs]
            else:
                with cf.ProcessPoolExecutor(max_workers=args.workers) as ex:
                    results = list(ex.map(run_trial, jobs))

            results.sort(key=lambda r: (
                1 if r['solved'] else 0,
                r.get('quality') or -1e9,
                r['best_partial_depth'],
            ), reverse=True)

            for r in results:
                if r['solved']:
                    all_unique.add(tuple(r['board']))

            for r in results:
                append_jsonl(lb, {k: r[k] for k in
                    ('trial_id', 'gen', 'seed', 'solved', 'num_solutions', 'nodes',
                     'seconds', 'quality', 'best_partial_depth', 'signals', 'board',
                     'words', 'params', 'rejections')})
                if best is None or \
                   (r['solved'] and not best.get('solved')) or \
                   (r['solved'] == best.get('solved') and
                    (r.get('quality') or -1e9) > (best.get('quality') or -1e9)):
                    best = r
                    save_json(outdir / 'best_result.json', r)

            elites = [{'params': r['params'], 'score': r.get('quality', 0)}
                      for r in select_elites(results, args.elite, diverse=use_diversity)
                      if r['solved']]
            if elites:
                mean, sigma = elite_update(elites, mean, sigma)

            save_json(sp, {
                'next_gen': gen0 + 1, 'mean': mean, 'sigma': sigma,
                'best': best, 'tc': tc, 'rng_state': repr(rng.getstate()),
            })

            top = results[0]
            solved_n = sum(1 for r in results if r['solved'])
            total_sols = sum(r.get('num_solutions', 0) for r in results)
            elapsed = (time.time() - t_start) / 60
            print(f'[gen {gen0:>3}] {solved_n}/{len(results)} solved ({total_sols} boards)  '
                  f'q={str(top.get("quality") or "—"):>8}  '
                  f'mdl={top["signals"]["sol_mdl"]:.3f}  '
                  f'uniq={len(all_unique)}  '
                  f'{elapsed:.1f}min')

            gen0 += 1

        print(f'\n{"=" * 65}')
        reason = 'interrupted' if interrupted['flag'] else 'deadline'
        print(f'[arena_v7] Done ({reason}). {gen0} gens, {tc} trials, {(time.time()-t_start)/60:.1f} min')
        print(f'[arena_v7] Unique boards: {len(all_unique)}')
        if best:
            print(f'Best: solved={best["solved"]} quality={best.get("quality")}')
            print(f'      solutions={best.get("num_solutions", 0)} nodes={best["nodes"]}')
            print()
            for row in best['board']:
                print(f'  {row}')
            ws = best['words']
            hinted = [w for w in ws if w['h']]
            print(f'\n  Words: {len(ws)} ({len(hinted)} hinted)')
            for w in ws:
                mark = '✓' if w['h'] else '·'
                print(f'    {mark} {w["w"]:12s} (s={w["s"]:>2})  {w["h"][:45]}')
            print(f'\n  MDL: {best["signals"]["sol_mdl"]:.3f}  '
                  f'entropy: {best["signals"]["cross_entropy"]:.3f}  '
                  f'fill: {best["signals"]["fill_ratio"]:.2f}')
            # v7: show which sensors CMA-ES kept
            print(f'\n  Sensor weights (CMA-ES converged):')
            for sk in ['w_dcc', 'w_echo', 'w_resonance', 'w_sensitivity', 'w_cluster',
                        'w_cascade', 'w_frozen', 'adsr_patience', 'flood_drain']:
                v = best['params'][sk]
                status = '●' if v > 0.3 else '○'
                print(f'    {status} {sk}: {v:.2f}')

    finally:
        signal.signal(signal.SIGINT, old_handler)
        try:
            lock_path.unlink(missing_ok=True)
        except OSError:
            pass


if __name__ == '__main__':
    main()
