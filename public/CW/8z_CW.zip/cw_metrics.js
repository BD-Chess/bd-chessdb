'use strict';

function makeEmptyMask(size, black = false) {
  return Array.from({ length: size }, () => Array.from({ length: size }, () => !!black));
}

function cloneMask(mask) {
  return mask.map(row => row.slice());
}

function inBounds(size, r, c) {
  return r >= 0 && c >= 0 && r < size && c < size;
}

function isOpen(mask, r, c) {
  return inBounds(mask.length, r, c) && !mask[r][c];
}

function countOpen(mask) {
  let n = 0;
  for (const row of mask) for (const cell of row) if (!cell) n++;
  return n;
}

function countBlack(mask) {
  let n = 0;
  for (const row of mask) for (const cell of row) if (cell) n++;
  return n;
}

function blackRatio(mask) {
  const cells = mask.length * mask.length;
  return countBlack(mask) / cells;
}

function getOpenComponents(mask) {
  const size = mask.length;
  const seen = Array.from({ length: size }, () => Array(size).fill(false));
  const comps = [];
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (mask[r][c] || seen[r][c]) continue;
      const stack = [[r, c]];
      const cells = [];
      seen[r][c] = true;
      while (stack.length) {
        const [cr, cc] = stack.pop();
        cells.push([cr, cc]);
        for (const [dr, dc] of [[1,0],[-1,0],[0,1],[0,-1]]) {
          const nr = cr + dr, nc = cc + dc;
          if (inBounds(size, nr, nc) && !mask[nr][nc] && !seen[nr][nc]) {
            seen[nr][nc] = true;
            stack.push([nr, nc]);
          }
        }
      }
      comps.push(cells);
    }
  }
  return comps;
}

function extractSlots(mask) {
  const size = mask.length;
  const slots = [];
  let id = 0;

  for (let r = 0; r < size; r++) {
    let c = 0;
    while (c < size) {
      if (mask[r][c]) { c++; continue; }
      const start = c;
      while (c < size && !mask[r][c]) c++;
      const len = c - start;
      if (len >= 3) {
        const cells = [];
        for (let k = 0; k < len; k++) cells.push([r, start + k]);
        slots.push({ id: `A${id++}`, dir: 'across', row: r, col: start, len, cells });
      }
    }
  }

  id = 0;
  for (let c = 0; c < size; c++) {
    let r = 0;
    while (r < size) {
      if (mask[r][c]) { r++; continue; }
      const start = r;
      while (r < size && !mask[r][c]) r++;
      const len = r - start;
      if (len >= 3) {
        const cells = [];
        for (let k = 0; k < len; k++) cells.push([start + k, c]);
        slots.push({ id: `D${id++}`, dir: 'down', row: start, col: c, len, cells });
      }
    }
  }
  return slots;
}

function buildCellMap(slots, size) {
  const map = Array.from({ length: size }, () => Array.from({ length: size }, () => []));
  for (const slot of slots) {
    slot.cells.forEach(([r, c], idx) => {
      map[r][c].push({ slotId: slot.id, dir: slot.dir, index: idx });
    });
  }
  return map;
}

function slotLengthsValid(mask) {
  const size = mask.length;
  let invalid = 0;

  for (let r = 0; r < size; r++) {
    let c = 0;
    while (c < size) {
      if (mask[r][c]) { c++; continue; }
      const s = c;
      while (c < size && !mask[r][c]) c++;
      const len = c - s;
      if (len > 0 && len < 3) invalid++;
    }
  }
  for (let c = 0; c < size; c++) {
    let r = 0;
    while (r < size) {
      if (mask[r][c]) { r++; continue; }
      const s = r;
      while (r < size && !mask[r][c]) r++;
      const len = r - s;
      if (len > 0 && len < 3) invalid++;
    }
  }
  return invalid === 0;
}

function countTwoByTwoBlacks(mask) {
  let n = 0;
  for (let r = 0; r < mask.length - 1; r++) {
    for (let c = 0; c < mask.length - 1; c++) {
      if (mask[r][c] && mask[r+1][c] && mask[r][c+1] && mask[r+1][c+1]) n++;
    }
  }
  return n;
}

function symmetryMismatch(mask) {
  const size = mask.length;
  let miss = 0, total = 0;
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      const rr = size - 1 - r, cc = size - 1 - c;
      total++;
      if (mask[r][c] !== mask[rr][cc]) miss++;
    }
  }
  return miss / Math.max(1, total);
}

function uglyPocketScore(mask) {
  const size = mask.length;
  let pen = 0;
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (mask[r][c]) continue;
      let deg = 0;
      for (const [dr, dc] of [[1,0],[-1,0],[0,1],[0,-1]]) {
        const nr = r + dr, nc = c + dc;
        if (inBounds(size, nr, nc) && !mask[nr][nc]) deg++;
      }
      if (deg <= 1) pen += 3;
      else if (deg === 2) pen += 0.5;
    }
  }
  return pen;
}

function buildGridFromAssignments(mask, assignments) {
  const size = mask.length;
  const grid = Array.from({ length: size }, () => Array.from({ length: size }, () => '#'));
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) if (!mask[r][c]) grid[r][c] = '.';
  }
  for (const slot of Object.values(assignments)) {
    if (!slot || !slot.word) continue;
    slot.cells.forEach(([r, c], idx) => {
      grid[r][c] = slot.word[idx];
    });
  }
  return grid;
}

function crossingStats(mask, slots) {
  const size = mask.length;
  const map = buildCellMap(slots, size);
  let checked = 0;
  let unchecked = 0;
  let open = 0;
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (mask[r][c]) continue;
      open++;
      if ((map[r][c] || []).length >= 2) checked++;
      else unchecked++;
    }
  }
  return {
    open,
    checked,
    unchecked,
    crossingDensity: checked / Math.max(1, open),
  };
}

function entriesFromAssignments(assignments) {
  const across = [];
  const down = [];
  for (const slot of Object.values(assignments)) {
    if (!slot || !slot.word) continue;
    const entry = {
      id: slot.id,
      row: slot.row,
      col: slot.col,
      len: slot.len,
      answer: slot.word,
      clue: slot.h || '',
      score: slot.score,
      tier: slot.tier,
      topic: slot.topic || null,
    };
    if (slot.dir === 'across') across.push(entry);
    else down.push(entry);
  }
  across.sort((a, b) => a.row - b.row || a.col - b.col);
  down.sort((a, b) => a.row - b.row || a.col - b.col);
  return { across, down };
}

module.exports = {
  makeEmptyMask,
  cloneMask,
  inBounds,
  isOpen,
  countOpen,
  countBlack,
  blackRatio,
  getOpenComponents,
  extractSlots,
  buildCellMap,
  slotLengthsValid,
  countTwoByTwoBlacks,
  symmetryMismatch,
  uglyPocketScore,
  buildGridFromAssignments,
  crossingStats,
  entriesFromAssignments,
};
