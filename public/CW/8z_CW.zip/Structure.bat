tree /F > "_Structure1.txt"
dir /S > "_Structure2.txt"