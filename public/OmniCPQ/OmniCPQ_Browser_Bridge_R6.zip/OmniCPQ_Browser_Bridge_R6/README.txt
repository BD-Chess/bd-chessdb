OmniCPQ Browser Bridge R6
Navodilo: https://www.mdlxdcc.org/omnicpq/browser-help.html
Namestitev in povezavo odobri uporabnik. Razvojna distribucija, ni objava v trgovini.
Dostop: activeTab, scripting, storage; samo izbrani CPQ in samo dovoljena navigacija.
Brez API kljucev, gesel, zasebnega znanja, analitike ali oddaljene kode.
