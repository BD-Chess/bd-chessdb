OmniCPQ Browser Bridge 1.2.8
Veljavnost odobrenega para: do 3 dni (72 ur). Odklop, zaprtje povezanega zavihka ali izguba dovoljenja jo lahko prekinejo prej. Po ponovnem zagonu brskalnika ali reloadu razširitve par znova potrdi. Rok ne podaljšuje prijave pomočnika ali CPQ.
Navodilo: https://www.mdlxdcc.org/omnicpq/browser-help.html
Namestitev in povezavo odobri uporabnik. Razvojna distribucija, ni objava v trgovini.
Dostop: activeTab, scripting, storage, debugger; samo izbrani CPQ GUI po potrditvah.
Brez API kljucev, gesel, zasebnega znanja, analitike ali oddaljene kode.
