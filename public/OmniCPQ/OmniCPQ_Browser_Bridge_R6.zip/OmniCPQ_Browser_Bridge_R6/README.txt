OmniCPQ Browser Bridge R6
Navodilo: https://www.mdlxdcc.org/omnicpq/browser-help.html
Namestitev in povezavo odobri uporabnik. Razvojna distribucija, ni objava v trgovini.
Dostop: activeTab, scripting, storage, debugger; samo izbrani CPQ GUI po potrditvah.
Brez API kljucev, gesel, zasebnega znanja, analitike ali oddaljene kode.
