@echo off
cd /d "%~dp0"
set OPENBLAS_NUM_THREADS=1
python -B -X utf8 gods_execution_20261101_R1/aggregate_ext_R1.py --run --extension-key gods_execution_20261101_R1/keys/GODS10_B_EXT_KEY_SEALED.json --old-key originals/GODS10_KEY_SEALED.json --own originals/own_set_table_v1.1_25.json --out reproduction_results
