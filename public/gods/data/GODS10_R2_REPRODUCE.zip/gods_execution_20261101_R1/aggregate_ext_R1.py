"""GODS10 B_EXT web panel: frozen blinded amendment, 2026-11-01.

Run --selftest before keys; --prekey freezes all selected parses; --run requires
both exact keys and the canonical own-table. No network, models or imputation.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, os, re, sys
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime, timezone
import numpy as np

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'gods_quality_20261101'
sys.path.insert(0,str(SOURCE))
from audit_prekey import load_parser, diagnostic_checks
M=load_parser()
SEED=20261027
B=10000
R=10000
EXT_SHA='d1b5b08ccd886f1ec4208bae9493a248b7bc6f08b99fd9cb697fc9a8ecc44d24'
OLD_SHA='fdb811272d026edca1ae0f90607f806755237dbcd6d6e1d4540fb54880f184b3'
EXTRA={'web_Perplexity','ext_gpt-6.1-terra_high'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,obj):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    b=(json.dumps(M.jclean(obj),ensure_ascii=False,indent=1,allow_nan=False)+'\n').encode()
    if p.exists():assert p.read_bytes()==b,f'conflicting output: {p}';return
    tmp=p.with_name(p.name+'.tmp')
    with tmp.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
    os.rename(tmp,p)
def codes(prompt):return re.findall(r'^Set ([A-Z]{2})\s*$',prompt,flags=re.M)
def join_split(parts,expected):
    rows={}
    for p in parts:
        assert p['table_valid'],'invalid packet'
        assert not (set(rows)&set(p['rows'])),'overlapping split packet'
        rows.update(p['rows'])
    assert set(rows)==set(expected),'incomplete split union'
    # One 36-set observation, no fabricated global Q ballot or packet-rank merge.
    return M.jclean(M.parse_reply('TABLE\n'+'\n'.join(c+' | '+' | '.join(map(str,v)) for c,v in rows.items()),expected))
def prekey():
    manifest=read(SOURCE/'source/MANIFEST.json');state=read(ROOT/'RUN_STATE.json')
    assert len(state['requests'])==4 and all(x['state']=='CAPTURED_VALID' for x in state['requests'])
    baseline={};recovered={};files={};fullcodes={};metadata={};split_votes={}
    for r in manifest['records']:
        rp=SOURCE/'replies'/r['file'];pp=SOURCE/r['prompt_file']
        assert sha(rp)==r['sha256'] and sha(pp)==r['prompt_sha256']
        files[str(rp.relative_to(ROOT.parent))]=sha(rp);files[str(pp.relative_to(ROOT.parent))]=sha(pp)
        if r['packet']=='FULL':
            j='web_'+r['model'];ex=codes(pp.read_text());assert len(ex)==len(set(ex))==36
            baseline[j]=M.jclean(M.parse_reply(rp.read_text(encoding='utf-8-sig'),ex));fullcodes[j]=ex
            metadata[j]=r
    recovered=copy.deepcopy(baseline)
    for model in ['Amazon_Nova','Cohere']:
        parts=[];split_votes[model]=[]
        for k in (1,2,3):
            name=f'B_recovery_web_{model}_P{k}of3.txt';rp=ROOT/'recovery'/name
            if model=='Cohere' and k in (1,3):
                r=next(r for r in manifest['records'] if r['model']==model and r['packet']==f'P{k}of3')
                rp=SOURCE/'replies'/r['file'];pp=SOURCE/r['prompt_file']
            else:
                r=next(r for r in state['requests'] if r['model'].replace(' ','_')==model and r['packet']==f'P{k}of3')
                assert sha(rp)==r['reply_sha256'];pp=ROOT/'inputs'/r['prompt_file']
                assert sha(pp)==r['prompt_sha256']
            ex=codes(pp.read_text());p=M.jclean(M.parse_reply(rp.read_text(),ex));assert len(ex)==12 and p['table_valid']
            parts.append(p);split_votes[model].append({'packet':k,'best':p['best'],'codes':ex})
            files[str(rp.relative_to(ROOT.parent))]=sha(rp);files[str(pp.relative_to(ROOT.parent))]=sha(pp)
        recovered['web_'+model]=join_split(parts,fullcodes['web_'+model])
    assert sum(p['table_valid'] for p in baseline.values())==13
    assert len(recovered)==15 and all(p['table_valid'] and p['n_valid_rows']==36 for p in recovered.values())
    return {'schema':'gods10.extension.prekey.v1','key_read':False,'files':files,'baseline':baseline,'recovered':recovered,
            'fullcodes':fullcodes,'metadata':metadata,'split_local_votes':split_votes,
            'counts':{'baseline_valid_tables':13,'recovered_valid_tables':15,'sets':36,'new_submissions':4},
            'rules':'Frozen recovery protocol and SCIENTIFIC_ADDENDUM_R1.md; original global ballots retained separately.'}
def resolve(ext,old,own):
    authors={};families={}
    for sid,v in ext['sets'].items():
        if v['kind']=='old25':
            ptr=v['pointer'];a=old['mapping']['free_ChatGPT'][ptr['ref_label']]
            assert a in own['set_families'],f'own table missing {a}'
            authors[sid]=a;families[sid]=own['set_families'][a]
        else:
            authors[sid]=v['author'];families[sid]=[v['family']]
        assert len(v['normalized'])==10
    assert len(set(authors.values()))==len(authors)==36
    # A conservative amendment made before author key reveal; manufacturer is preserved separately.
    if 'web_Copilot' in families:families['web_Copilot']=['openai']
    return authors,families
def build(ext,parses,authors,families,subset=None):
    sets=sorted(subset if subset is not None else ext['sets']);judges=list(parses);J=len(judges);N=len(sets);si={s:i for i,s in enumerate(sets)}
    fam=[('openai' if j=='web_Copilot' else ext['judges'][j]['family']) for j in judges]
    d=SimpleNamespace(sets=sets,judges=judges,J=J,N=N,letters=[],group=['free']*J,family=fam,model=judges[:])
    d.fam_idx=np.array([sorted(set(fam)).index(f) for f in fam]);d.T=np.full((J,N),np.nan);d.C=np.full((J,N,5),np.nan);d.R=np.full((J,N),np.nan)
    d.POS=np.zeros((J,N),int);d.LET=np.zeros((J,N),int);d.CODE=np.empty((J,N),object)
    d.score_ok=np.zeros(J,bool);d.rank_ok=np.zeros(J,bool);d.z_ok=np.zeros(J,bool);d.incoherent=np.zeros(J,bool);d.dropout=[None]*J;d.BEST=[[None]*10 for _ in judges]
    d.own={lev:np.zeros((J,N),bool) for lev in (1,2,3)}
    for j,name in enumerate(judges):
        info=ext['judges'][name];mp=info['mapping'];order=info['packets']['FULL'];p=parses[name]
        assert set(mp.values())==set(ext['sets']) and len(mp)==36
        exact={name,'free_'+name.removeprefix('web_')}
        for code,s in mp.items():
            if s not in si:continue
            k=si[s];d.POS[j,k]=order.index(code)+1;d.CODE[j,k]=code;d.LET[j,k]=d.POS[j,k]-1
            d.own[1][j,k]=d.own[2][j,k]=(s==name or authors[s] in exact)
            d.own[3][j,k]=fam[j] in families[s]
            if code in p['rows']:d.C[j,k]=p['rows'][code];d.T[j,k]=sum(p['rows'][code])
            if p['ranks'] and code in p['ranks']:d.R[j,k]=p['ranks'][code]
        d.score_ok[j]=p['table_valid'];d.rank_ok[j]=bool(p['ranks']);d.incoherent[j]=p['incoherent'];d.dropout[j]=p['dropout']
        if subset is not None and d.rank_ok[j]:d.R[j]=M.avg_rank_desc(-d.R[j])
        for q,code in p['best'].items():
            if code and mp[code] in si:d.BEST[j][int(q)-1]=si[mp[code]]
    assert np.all(d.own[1]<=d.own[3]),'own-family rule does not contain exact own set'
    normalize(d)
    return d
def normalize(d):
    d.Z=np.full_like(d.T,np.nan);d.ZC=np.full_like(d.C,np.nan);d.zc_notes=[]
    for j in range(d.J):
        if not d.score_ok[j]:continue
        x=d.T[j];assert np.isfinite(x).all()
        if x.std()>0:d.Z[j]=(x-x.mean())/x.std();d.z_ok[j]=True
        for c in range(5):
            y=d.C[j,:,c]
            if y.std()>0:d.ZC[j,:,c]=(y-y.mean())/y.std()
            else:d.zc_notes.append(f'{d.judges[j]}: constant criterion {c+1}')
def label_effect(d,repetitions=R):
    idx=np.where(d.score_ok & d.z_ok)[0];z=d.Z[idx];z=z-z.mean(0);labels=d.CODE[idx];pool=sorted(set(labels.ravel()));ids=np.array([[pool.index(c) for c in row] for row in labels]);cnt=np.bincount(ids.ravel(),minlength=len(pool))
    def stat(a):
        sums=np.bincount(a.ravel(),weights=z.ravel(),minlength=len(pool));return float(np.sum(sums*sums/np.maximum(cnt,1)))
    obs=stat(ids);rng=M.rng_for(SEED,'two_letter_label');ge=0
    for _ in range(repetitions):ge+=stat(np.array([rng.permutation(row) for row in ids]))>=obs-1e-12
    return {'n_judges':len(idx),'n_labels':len(pool),'stat':obs,'p_randomization':(ge+1)/(repetitions+1),'R':repetitions,
      'note':'Exploratory sparse categorical identity test. Each judge retains its actual 36-code pool; assignment is permuted within judge; set-mean z removed. FULL originals only.'}
def selftest():
    diagnostic_checks(M)
    ex=['BC','DF','GH','JK'];p=M.parse_reply('TABLE\nBC | 1 | 2 | 3 | 4 | 5\nDF | 2 | 3 | 4 | 5 | 6',ex[:2]);q=M.parse_reply('TABLE\nGH | 3 | 4 | 5 | 6 | 7\nJK | 4 | 5 | 6 | 7 | 8',ex[2:]);joined=join_split([p,q],ex)
    assert joined['table_valid'] and joined['rank_source']=='derived_from_totals' and joined['n_best_valid']==0
    try:join_split([p,p],ex);raise RuntimeError('overlap accepted')
    except AssertionError:pass
    d=SimpleNamespace(J=2,N=4,T=np.array([[15,20,25,30],[30,25,20,15]],float),C=np.array([[[3]*5,[4]*5,[5]*5,[6]*5],[[6]*5,[5]*5,[4]*5,[3]*5]],float),score_ok=np.ones(2,bool),z_ok=np.zeros(2,bool),judges=['a','b'])
    normalize(d);assert np.allclose(d.Z.mean(1),0) and np.allclose(d.Z.std(1),1)
    assert np.allclose(M.weights(np.ones((3,4),bool),np.array([0,0,1]),'family').sum(0),2)
    # Own-family nesting and minimum gate exercised on generated multi-judge scores.
    d.sets=['s'+str(i) for i in range(4)];d.judges=['a','b'];d.family=['f','g'];d.model=d.judges;d.fam_idx=np.array([0,1]);d.group=['free']*2;d.R=np.array([[4,3,2,1],[1,2,3,4]],float);d.rank_ok=np.ones(2,bool);d.incoherent=np.zeros(2,bool);d.own={i:np.zeros((2,4),bool) for i in [1,2,3]}
    v,_=M.compute_variant(d,M.variant_defs()[0],100,SEED);assert not v['ranked'] and v['decision']['winner'] is None
    ids=['web_A','web_B','web_Perplexity','ext_gpt-6.1-terra_high']+['s'+str(i) for i in range(32)]
    cc=[a+b for a in 'BCDFGH' for b in 'JKLMNP']
    ext={'sets':{s:{} for s in ids},'judges':{}}
    pars={};au={s:s for s in ids};fa={s:['f' if s=='web_A' else 'g' if s=='web_B' else 'h'] for s in ids}
    for j,name in enumerate(['web_A','web_B']):
        order=cc[j:]+cc[:j];ext['judges'][name]={'family':['f','g'][j],'mapping':dict(zip(order,ids)),'packets':{'FULL':cc}}
        pars[name]=M.jclean(M.parse_reply('TABLE\n'+'\n'.join(code+' | '+' | '.join([str(1+(k+j)%10)]*5) for k,code in enumerate(order)),cc))
    dd=build(ext,pars,au,fa);assert dd.own[1][0,dd.sets.index('web_A')] and dd.own[3][1,dd.sets.index('web_B')]
    assert dd.T[0,dd.sets.index('s0')]==25 and dd.T[1,dd.sets.index('s0')]==30
    sub=build(ext,pars,au,fa,set(ids)-EXTRA)
    assert sub.N==34 and np.allclose(sub.Z.mean(1),0)
    assert all(np.allclose(sub.R[j],M.avg_rank_desc(sub.T[j])) for j in range(sub.J))
    return {'result':'PASS','checks':['8 parser cases','split disjoint complete union','overlap rejection','no global split Q votes','global population z','family weights','minimum coverage gate','per-judge code permutations','own-family masks','34-set rank compression and renormalization'],'sealed_read':False}
def run(args):
    freeze=read(ROOT/'PREKEY_FREEZE_RECEIPT.json')
    for rel,h in freeze['files'].items():assert sha(ROOT/rel)==h,f'frozen file moved: {rel}'
    assert sha(args.extension_key)==EXT_SHA and sha(args.old_key)==OLD_SHA
    assert sha(args.own).startswith('e0688931'),'wrong own-table v1.1'
    p=read(ROOT/'PREKEY_SELECTED_PARSE.json');assert freeze['files']['PREKEY_SELECTED_PARSE.json']==sha(ROOT/'PREKEY_SELECTED_PARSE.json')
    ext=read(args.extension_key);old=read(args.old_key);own=read(args.own);authors,families=resolve(ext,old,own)
    result={'schema':'gods10.extension.results.v1','config':{'B':B,'R':R,'seed':SEED,'z_sd':'population','web_only':True},'authors':authors,'families':families,
      'sets':ext['sets'],'judges':p['metadata'],'inputs':{'freeze':sha(ROOT/'PREKEY_FREEZE_RECEIPT.json'),'extension_key':EXT_SHA,'old_key':OLD_SHA,'own':sha(args.own)},'panels':{}}
    definitions=[v for v in M.variant_defs() if v[0] not in ['free','api','local']]
    checkpoint_path=Path(args.out)/'CHECKPOINTS.json'
    checkpoint=read(checkpoint_path) if checkpoint_path.exists() else {'freeze':sha(ROOT/'PREKEY_FREEZE_RECEIPT.json'),'phases':{}}
    assert checkpoint['freeze']==sha(ROOT/'PREKEY_FREEZE_RECEIPT.json')
    for panel in ['baseline','recovered']:
        for universe in ['all36','core34']:
            name=panel+'_'+universe;out=Path(args.out)/(name+'.json')
            if out.exists():
                assert checkpoint['phases'].get(name)==sha(out),f'unverified resume phase {name}'
                result['panels'][name]=read(out);print('validated resume '+name,flush=True);continue
            print('calculating '+name,flush=True)
            d=build(ext,p[panel],authors,families,None if universe=='all36' else set(ext['sets'])-EXTRA)
            variants=[M.compute_variant(d,v,B,SEED)[0] for v in definitions]
            # Global per-question ballots come from the original FULL answers, including Nova.
            original=build(ext,p['baseline'],authors,families,set(d.sets) if universe=='core34' else None)
            strict=copy.deepcopy(original)
            for j in range(strict.J):
                if not strict.score_ok[j]:strict.BEST[j]=[None]*10
            res={'variants':variants,'agreement':M.agreement(d,B,SEED),'self_preference':M.self_preference(d,R,SEED),
              'best_per_question':{'original_FULL_all':M.best_per_question(original),'original_FULL_own_l3':M.best_per_question(original,3),'complete_tables_only':M.best_per_question(strict)},
              'matrix':{'sets':d.sets,'judges':d.judges,'criteria':d.C,'totals':d.T,'z':d.Z,'score_valid':d.score_ok,'own_l3':d.own[3]},'notes':d.zc_notes}
            if panel=='baseline' and universe=='all36':
                pos=M.position_effect(d,R,SEED);pos.pop('label_effect',None);res['position_effect_FULL_only']=pos;res['two_letter_label_effect_FULL_only']=label_effect(d)
            write(out,res);result['panels'][name]=M.jclean(res);checkpoint['phases'][name]=sha(out)
            checkpoint_path.parent.mkdir(parents=True,exist_ok=True);tmp=checkpoint_path.with_suffix('.tmp')
            with tmp.open('w') as f:json.dump(checkpoint,f,indent=1);f.write('\n');f.flush();os.fsync(f.fileno())
            os.replace(tmp,checkpoint_path)
    result['split_local_votes']=p['split_local_votes'];write(Path(args.out)/'GODS10_RESULTS_R2.json',result)
    print('RESULTS COMPLETE',flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--selftest',action='store_true');ap.add_argument('--prekey',action='store_true');ap.add_argument('--run',action='store_true');ap.add_argument('--extension-key');ap.add_argument('--old-key');ap.add_argument('--own');ap.add_argument('--out',default=str(ROOT/'results'))
    a=ap.parse_args()
    if a.selftest:write(ROOT/'SYNTHETIC_CHECKS_R1.json',selftest());print('Synthetic checks PASS')
    elif a.prekey:write(ROOT/'PREKEY_SELECTED_PARSE.json',prekey());print('Prekey selection complete; no keys read')
    elif a.run:run(a)
    else:ap.error('choose --selftest, --prekey or --run')
