#!/usr/bin/env python3
"""GODS10 pre-registered aggregation of blind LLM judging.

Implements GODS10_AGG_SPEC.md v1.0 (2026-10-27), which implements section 3 (3.2-3.8) of
SESTRA_GODS10_AUDIT_ZORA_20261027.md.

Modes
  full      : gods10_aggregate.py --key KEY.json --replies DIR --own own_set_table.json --out OUTDIR [--seed 20261027]
              [--prompts DIR] [--expect-key-sha256 HEX|PREFIX...SUFFIX]
  pre-key   : gods10_aggregate.py --parse-only --n-sets 23 --replies DIR --out OUTDIR
              (no key: freezes the replies (SHA-256 per file + manifest) and records the parse result before the key is opened)
  self-test : gods10_aggregate.py --selftest [--own own_set_table.json] [--out OUTDIR]
              (synthetic key + synthetic replies; never reads a real key)

Replies dir: one file per judge, <judge>.txt; an optional single retry is <judge>.retry.txt (then only the retry is used,
both are hashed). All output files are create-only (an existing file is never overwritten). No network, no model calls.
Dependencies: Python 3.9+, numpy.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import re
import sys
import warnings
from collections import Counter
from pathlib import Path
from types import SimpleNamespace

import numpy as np

SPEC_VERSION = 'GODS10_AGG_SPEC v1.0 (2026-10-27)'
CRITERIA = ('insight', 'coherence', 'originality', 'clarity', 'credibility')
ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
N_Q = 10
B_DEFAULT = 10000          # bootstrap replicates (pre-registered)
R_DEFAULT = 10000          # randomization / permutation draws (pre-registered)
SEED_DEFAULT = 20261027
MIN_JUDGES, MIN_FAMILIES = 5, 3
INCOHERENT_RHO = 0.5
BEST_MARGIN = 2
WINNER_P = 0.5
SELFPREF_MIN_D, SELFPREF_ALPHA = 0.2, 0.05
CLAUDE_GPT = ('anthropic', 'openai')
HERE = Path(__file__).resolve().parent

warnings.filterwarnings('ignore', category=RuntimeWarning)  # nanmean of empty slices etc. are handled explicitly


# ----------------------------------------------------------------------------------------------------------- utilities
def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(p) -> str:
    return sha256_bytes(Path(p).read_bytes())


def write_new(path, text: str) -> str:
    """Create-only write (mode 'x'); returns SHA-256 of the written file."""
    path = Path(path)
    with path.open('x', encoding='utf-8', newline='\n') as f:
        f.write(text)
    return sha256_file(path)


def rng_for(seed: int, *tags: str):
    """Independent, order-free random stream per purpose: SeedSequence([seed, h(tag1), h(tag2), ...])."""
    return np.random.default_rng([int(seed)] + [int(hashlib.sha256(t.encode()).hexdigest()[:8], 16) for t in tags])


def jclean(o):
    """Make an object JSON-safe: numpy -> python, NaN/inf -> None."""
    if isinstance(o, dict):
        return {str(k): jclean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jclean(v) for v in o]
    if isinstance(o, np.ndarray):
        return jclean(o.tolist())
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (float, np.floating)):
        return float(o) if math.isfinite(o) else None
    return o


def fmt(x, nd=3):
    if x is None:
        return 'n/a'
    try:
        if isinstance(x, float) and not math.isfinite(x):
            return 'n/a'
    except TypeError:
        pass
    if isinstance(x, (int, np.integer)):
        return str(int(x))
    return f'{float(x):.{nd}f}'


def avg_rank_desc(x):
    """Rank 1 = largest; ties get the average rank; NaN ranked last (tied among themselves)."""
    v = np.where(np.isnan(np.asarray(x, float)), -np.inf, np.asarray(x, float))
    gt = (v[None, :] > v[:, None]).sum(1)
    eq = (v[None, :] == v[:, None]).sum(1)
    return 1.0 + gt + (eq - 1) / 2.0


def avg_rank_rows(X):
    V = np.where(np.isnan(X), -np.inf, X)
    gt = (V[:, None, :] > V[:, :, None]).sum(2)
    eq = (V[:, None, :] == V[:, :, None]).sum(2)
    return 1.0 + gt + (eq - 1) / 2.0


def min_rank_rows(X):
    """Competition ('min') rank per row: 1 + number of strictly larger values; NaN last."""
    V = np.where(np.isnan(X), -np.inf, X)
    return 1 + (V[:, None, :] > V[:, :, None]).sum(2)


def pearson(a, b):
    a = np.asarray(a, float) - np.mean(a)
    b = np.asarray(b, float) - np.mean(b)
    d = math.sqrt(float((a * a).sum() * (b * b).sum()))
    return float((a * b).sum() / d) if d > 0 else float('nan')


def spearman(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    ok = ~(np.isnan(a) | np.isnan(b))
    if ok.sum() < 3:
        return float('nan')
    return pearson(avg_rank_desc(a[ok]), avg_rank_desc(b[ok]))


def rowwise_spearman(A, B):
    bad = np.isnan(A).any(1) | np.isnan(B).any(1)
    ra, rb = avg_rank_rows(A), avg_rank_rows(B)
    ra -= ra.mean(1, keepdims=True)
    rb -= rb.mean(1, keepdims=True)
    den = np.sqrt((ra * ra).sum(1) * (rb * rb).sum(1))
    rho = np.where(den > 0, (ra * rb).sum(1) / np.where(den > 0, den, 1), np.nan)
    rho[bad] = np.nan
    return rho


def gammaincc(a, x):
    """Regularized upper incomplete gamma Q(a, x) (series / Lentz continued fraction)."""
    if x <= 0:
        return 1.0
    lg = -x + a * math.log(x) - math.lgamma(a)
    if x < a + 1:
        term = s = 1.0 / a
        n = a
        for _ in range(10000):
            n += 1
            term *= x / n
            s += term
            if abs(term) < abs(s) * 1e-15:
                break
        return max(0.0, 1.0 - s * math.exp(lg))
    tiny = 1e-300
    b = x + 1 - a
    c = 1 / tiny
    d = 1 / b
    h = d
    for i in range(1, 10000):
        an = -i * (i - a)
        b += 2
        d = an * d + b
        d = tiny if abs(d) < tiny else d
        c = b + an / c
        c = tiny if abs(c) < tiny else c
        d = 1 / d
        de = d * c
        h *= de
        if abs(de - 1) < 1e-15:
            break
    return min(1.0, h * math.exp(lg))


def chi2_sf(x, k):
    return gammaincc(k / 2.0, x / 2.0) if x > 0 else 1.0


def draw_counts(rng, B, K):
    draws = rng.integers(0, K, size=(B, K))
    counts = np.zeros((B, K))
    np.add.at(counts, (np.repeat(np.arange(B), K), draws.ravel()), 1)
    return counts


# ------------------------------------------------------------------------------------------------------------- parsing
LETTER_RE = re.compile(r'(?<![A-Za-z0-9])([A-Z])(?![A-Za-z0-9])')
LABEL_RE = re.compile(r'^(?:[Ss][Ee][Tt]\s*)?[(\[]?([A-Za-z])[)\]]?[.:)]?$')
HEAD_RE = re.compile(r'^((?:[Ss][Ee][Tt]\s*)?[(\[]?([A-Za-z])[)\]]?)([.:)\-])?(\s*)(.*)$')
NUMISH_RE = re.compile(r'^-?\d+(?:[.,]\d+)?(?:/\d+)?$')
QTOK_RE = re.compile(r'\b(?:[Qq]|[Qq]uestion)\s*(\d{1,2})\b')
SEG_RE = re.compile(r'^[\s:|=.)\-(\]\[>]*(?:(?i:set)\s+)?([A-Z])(?![A-Za-z0-9])'
                    r'(\s*(?:/|,|&|\+|\bor\b|\band\b)\s*(?:(?i:set)\s+)?[A-Z](?![A-Za-z0-9]))?')
QRANGE_RE = re.compile(r'(?i)\bQ\s*1\s*(?:-|to|through|\.\.)\s*Q?\s*10\b')
SET_WORD_RE = re.compile(r'(?i)\bsets?\b')


def clean(line: str) -> str:
    l = (line.replace('–', '-').replace('—', '-').replace('−', '-').replace(' ', ' ')
         .replace('\t', ' '))
    l = re.sub(r'[*_`]', '', l).strip()
    l = re.sub(r'^#{1,6}\s*', '', l)
    l = re.sub(r'^>\s*', '', l)
    return l.strip()


def section_of(l: str):
    u = l.upper()
    if re.match(r'(?:FINAL\s+|OVERALL\s+)?RANK(?:ING|INGS)?\b', u):
        return 'ranking'
    if re.match(r'BEST\s+ANSWERS?\b', u):
        return 'best'
    if re.match(r'JUSTIFICATIONS?\b', u):
        return 'justification'
    if re.match(r'TABLE\b', u):
        return 'table'
    return None


def split_row(l: str):
    """(label, cells) if the line looks like a score row (label + >=3 numeric cells), else None."""
    if '|' in l:
        cells = [c.strip() for c in l.strip().strip('|').split('|')]
        m = LABEL_RE.match(cells[0]) if cells else None
        if not m:
            return None
        label, rest = m.group(1), cells[1:]
    else:
        m = HEAD_RE.match(l)
        if not m or (not m.group(3) and not m.group(4)):
            return None
        label = m.group(2)
        rest = [c for c in re.split(r'[\s,;=]+', m.group(5)) if c]
    if sum(bool(NUMISH_RE.match(c)) for c in rest) < 3:
        return None
    return label, rest


def validate_cells(rest, colmap):
    if len(rest) not in (5, 6):
        return None, None, f'expected 5 scores (+ optional total), found {len(rest)} cells'
    vals = []
    for c in rest[:5]:
        if not re.fullmatch(r'\d{1,2}', c):
            return None, None, f'score {c!r} is not an integer'
        v = int(c)
        if not 1 <= v <= 10:
            return None, None, f'score {v} outside 1-10'
        vals.append(v)
    scores = [0] * 5
    for i, v in enumerate(vals):
        scores[colmap[i]] = v
    note = None
    if len(rest) == 6:
        if re.fullmatch(r'\d{1,3}', rest[5]):
            if int(rest[5]) != sum(vals):
                note = f'reported total {rest[5]} != recomputed {sum(vals)} (recomputed used)'
        else:
            note = f'reported total {rest[5]!r} is not an integer (ignored)'
    return scores, note, None


def parse_ranking(lines, tags, row_lines, letters):
    start = next((i for i, l in enumerate(lines) if section_of(l) == 'ranking'), None)
    if start is None:
        return None, 'missing', 'no RANKING line'
    l = lines[start]
    t = l.split(':', 1)[1] if ':' in l else re.sub(r'(?i)^(?:final\s+|overall\s+)?rank\w*', '', l)
    parts = [t]
    got = bool(LETTER_RE.findall(SET_WORD_RE.sub(' ', t)))
    for i in range(start + 1, len(lines)):
        if section_of(lines[i]) or tags[i] != 'ranking' or i in row_lines:
            break
        if not lines[i].strip():
            if got:
                break
            continue
        parts.append(lines[i])
        got = got or bool(LETTER_RE.findall(SET_WORD_RE.sub(' ', lines[i])))
    text = ' '.join(parts)
    if re.search(r'[=~]|\btie[ds]?\b', text, re.I):
        return None, 'invalid', 'tie notation in RANKING (must be a strict order)'
    seq = LETTER_RE.findall(SET_WORD_RE.sub(' ', text))
    if not seq:
        return None, 'invalid', 'RANKING has no letters'
    known = set(letters)
    unknown = sorted({x for x in seq if x not in known})
    dup = sorted(x for x, c in Counter(seq).items() if c > 1)
    missing = [x for x in letters if x not in seq]
    if unknown or dup or missing:
        why = []
        if missing:
            why.append('missing ' + ''.join(missing))
        if dup:
            why.append('duplicated ' + ''.join(dup))
        if unknown:
            why.append('unknown ' + ''.join(unknown))
        return None, 'invalid', 'RANKING is not a permutation of all letters: ' + '; '.join(why)
    return seq, 'valid', None


def parse_best(lines, tags, row_lines, letters):
    known = set(letters)
    best = {q: None for q in range(1, N_Q + 1)}
    issues = []
    start = next((i for i, l in enumerate(lines) if section_of(l) == 'best'), None)
    if start is None:
        return best, ['no BEST ANSWER PER QUESTION section']
    l = lines[start]
    if ':' in l:
        head = l.split(':', 1)[1]
    else:
        head = re.sub(r'(?i)^best\s+answers?(?:\s+per\s+question)?', '', l)
    block = [head]
    for i in range(start + 1, len(lines)):
        if section_of(lines[i]):
            break
        if i in row_lines:
            continue
        block.append(lines[i])
    block = [QRANGE_RE.sub(' ', b) for b in block]
    if any(QTOK_RE.search(b) for b in block):
        votes = {}
        for b in block:
            parts = QTOK_RE.split(b)
            for k in range(1, len(parts), 2):
                q, seg = int(parts[k]), parts[k + 1]
                if not 1 <= q <= N_Q:
                    issues.append(f'Q{q} outside Q1-Q{N_Q} ignored')
                    continue
                m = SEG_RE.match(seg)
                if m and m.group(2):
                    votes.setdefault(q, []).append(('invalid', f'Q{q}: more than one letter'))
                elif m:
                    votes.setdefault(q, []).append(('ok', m.group(1)))
                else:
                    ls = LETTER_RE.findall(SET_WORD_RE.sub(' ', seg))
                    if len(ls) == 1:
                        votes.setdefault(q, []).append(('ok', ls[0]))
                    else:
                        votes.setdefault(q, []).append(('invalid', f'Q{q}: no single letter found'))
        for q in range(1, N_Q + 1):
            v = votes.get(q)
            if not v:
                issues.append(f'Q{q}: missing')
                continue
            bad = [x[1] for x in v if x[0] == 'invalid']
            vals = {x[1] for x in v if x[0] == 'ok'}
            if bad:
                issues.append(bad[0])
            elif len(vals) != 1:
                issues.append(f'Q{q}: conflicting letters {"".join(sorted(vals))}')
            else:
                L = vals.pop()
                if L in known:
                    best[q] = L
                else:
                    issues.append(f'Q{q}: unknown letter {L!r}')
    else:
        seq = LETTER_RE.findall(SET_WORD_RE.sub(' ', ' '.join(block)))
        if len(seq) != N_Q:
            issues.append(f'no Qn labels and {len(seq)} letters instead of {N_Q}: all questions invalid')
        else:
            for q, L in enumerate(seq, 1):
                if L in known:
                    best[q] = L
                else:
                    issues.append(f'Q{q}: unknown letter {L!r}')
    return best, issues


def parse_reply(text: str, letters):
    """Strict parser (spec 3.2). Works in letter space; needs only the list of valid letters (no key)."""
    letters = list(letters)
    known, n = set(letters), len(letters)
    lines = [clean(x) for x in text.splitlines()]
    tags, sec = [], 'pre'
    for l in lines:
        s = section_of(l)
        if s:
            sec = s
        tags.append(sec)
    res = {'row_issues': [], 'total_notes': [], 'notes': []}
    colmap = list(range(5))
    for l in lines:
        low = l.lower()
        if all(c in low for c in CRITERIA):
            order = sorted(CRITERIA, key=low.index)
            colmap = [CRITERIA.index(c) for c in order]
            if tuple(order) != CRITERIA:
                res['notes'].append('column order remapped from header: ' + ', '.join(order))
            break
    cand, row_lines, unparsed = {}, set(), []
    for i, l in enumerate(lines):
        if tags[i] == 'justification':
            continue
        r = split_row(l)
        if r is None:
            if tags[i] in ('pre', 'table') and len(re.findall(r'(?<![\w.])\d{1,2}(?![\w.])', l)) >= 5:
                unparsed.append(f'line {i + 1}: {l[:80]}')
            continue
        row_lines.add(i)
        label, rest = r
        scores, note, err = validate_cells(rest, colmap)
        if not label.isupper():
            err = f'label {label!r} is not an uppercase letter'
        elif label not in known:
            err = f'unknown letter {label!r}'
        cand.setdefault(label, []).append({'line': i + 1, 'scores': None if err else scores, 'error': err, 'note': note})
    rows = {}
    for L in sorted(cand):
        entries = cand[L]
        if L not in known:
            for e in entries:
                res['row_issues'].append(f'line {e["line"]}: {e["error"]}')
            continue
        errs = [e for e in entries if e['error']]
        if not errs and all(e['scores'] == entries[0]['scores'] for e in entries):
            rows[L] = entries[0]['scores']
            if len(entries) > 1:
                res['notes'].append(f'{L}: {len(entries)} identical duplicate rows (accepted once)')
            if entries[0]['note']:
                res['total_notes'].append(f'{L}: {entries[0]["note"]}')
        elif len(entries) == 1:
            res['row_issues'].append(f'{L} (line {entries[0]["line"]}): {entries[0]["error"]}')
        else:
            res['row_issues'].append(f'{L}: {len(entries)} rows that conflict or are invalid -> row invalid')
    missing = [L for L in letters if L not in cand]
    if missing:
        res['row_issues'].append('missing rows: ' + ''.join(missing))
    if unparsed:
        res['notes'].append(f'{len(unparsed)} numeric line(s) not recognised as rows, e.g. ' + unparsed[0])
    res['rows'] = rows
    res['n_valid_rows'] = len(rows)
    res['table_valid'] = len(rows) == n
    seq, status, issue = parse_ranking(lines, tags, row_lines, letters)
    res['ranking_status'], res['ranking_issue'], res['ranking_explicit'] = status, issue, seq
    best, best_issues = parse_best(lines, tags, row_lines, letters)
    res['best'], res['best_issues'] = best, best_issues
    res['n_best_valid'] = sum(v is not None for v in best.values())
    totals = np.array([sum(rows[L]) for L in letters], float) if res['table_valid'] else None
    if seq:
        res['ranks'] = {L: float(i + 1) for i, L in enumerate(seq)}
        res['rank_source'] = 'explicit'
    elif res['table_valid']:
        res['ranks'] = dict(zip(letters, avg_rank_desc(totals).tolist()))
        res['rank_source'] = 'derived_from_totals'
    else:
        res['ranks'] = None
        res['rank_source'] = 'none'
    res['sd0'] = bool(res['table_valid'] and float(np.std(totals)) == 0.0)
    rho = float('nan')
    if seq and res['table_valid'] and not res['sd0']:
        rho = pearson([res['ranks'][L] for L in letters], avg_rank_desc(totals))
    res['consistency_rho'] = rho
    res['incoherent'] = bool(math.isfinite(rho) and rho < INCOHERENT_RHO)
    res['empty'] = bool(not cand and status == 'missing' and res['n_best_valid'] == 0)
    res['dropout'] = 'no parseable content (refusal or abort)' if res['empty'] else None
    return res


def collect_replies(replies_dir, judges=None):
    rd = Path(replies_dir)
    files = sorted(p for p in rd.iterdir() if p.is_file())
    manifest = [(sha256_file(p), p.name) for p in files]
    manifest_text = ''.join(f'{h}  {nm}\n' for h, nm in manifest)
    stems = sorted({p.name[:-len('.retry.txt')] if p.name.endswith('.retry.txt') else p.stem
                    for p in files if p.suffix == '.txt'})
    if judges is None:
        judges = stems
    recs, used_names = {}, set()
    for j in judges:
        first, retry = rd / f'{j}.txt', rd / f'{j}.retry.txt'
        rec = {'first_sha256': sha256_file(first) if first.exists() else None,
               'retry_sha256': sha256_file(retry) if retry.exists() else None, 'used': None, 'text': None}
        used = retry if retry.exists() else first if first.exists() else None
        if used is not None:
            rec['used'] = 'retry' if used == retry else 'first'
            raw = used.read_bytes()
            rec['text'] = raw.decode('utf-8-sig', errors='replace')
            rec['decode_errors'] = '�' in rec['text'] and b'\xef\xbf\xbd' not in raw
            used_names.update({first.name, retry.name})
        recs[j] = rec
    ignored = [nm for _, nm in manifest if nm not in used_names]
    return recs, {'files': [{'name': nm, 'sha256': h} for h, nm in manifest],
                  'manifest_sha256': sha256_bytes(manifest_text.encode()), 'manifest_text': manifest_text,
                  'ignored_files': ignored}


def parse_all(recs, letters):
    out = {}
    for j, rec in recs.items():
        if rec['text'] is None:
            p = {'dropout': 'missing reply', 'rows': {}, 'n_valid_rows': 0, 'table_valid': False, 'ranks': None,
                 'rank_source': 'none', 'ranking_status': 'missing', 'ranking_issue': 'no reply',
                 'ranking_explicit': None, 'best': {q: None for q in range(1, N_Q + 1)}, 'best_issues': [],
                 'n_best_valid': 0, 'sd0': False, 'consistency_rho': float('nan'), 'incoherent': False,
                 'row_issues': [], 'total_notes': [], 'notes': [], 'empty': True}
        else:
            p = parse_reply(rec['text'], letters)
        p['reply_used'] = rec['used']
        p['first_sha256'], p['retry_sha256'] = rec['first_sha256'], rec['retry_sha256']
        out[j] = p
    return out


def parse_summary(parses):
    s = {}
    for j, p in parses.items():
        s[j] = {k: p.get(k) for k in ('dropout', 'reply_used', 'first_sha256', 'retry_sha256', 'n_valid_rows',
                                      'table_valid', 'rank_source', 'ranking_status', 'ranking_issue', 'n_best_valid',
                                      'sd0', 'consistency_rho', 'incoherent', 'row_issues', 'total_notes', 'notes',
                                      'best_issues')}
    return s


# ---------------------------------------------------------------------------------------------------------- own table
def load_own_table(path, judges, sets):
    t = json.loads(Path(path).read_text(encoding='utf-8'))
    jf, jm, jg = t['judge_family'], t['judge_model'], t['judge_group']
    sf, sm = t['set_families'], t['set_model']
    problems = [f'judge {j} missing in own table' for j in judges if j not in jf or j not in jm or j not in jg]
    problems += [f'set {s} missing in own table' for s in sets if s not in sf or s not in sm]
    if problems:
        raise SystemExit('own_set_table incomplete (a new table version is required): ' + '; '.join(problems))
    own = {}
    for lev in (1, 2, 3):
        explicit = t['own'][f'level{lev}']
        own[lev] = {}
        for j in judges:
            rule = sorted(s for s in sets if (s == j if lev == 1 else sm[s] == jm[j] if lev == 2 else jf[j] in sf[s]))
            ex = sorted(x for x in explicit.get(j, []) if x in sets)
            if ex != rule:
                problems.append(f'level{lev} {j}: explicit {ex} != rule {rule}')
            own[lev][j] = rule
    for j in judges:
        if not (set(own[1][j]) <= set(own[2][j]) <= set(own[3][j])):
            problems.append(f'levels not nested for {j}')
    if problems:
        raise SystemExit('own_set_table inconsistent: ' + '; '.join(problems))
    return {'family': {j: jf[j] for j in judges}, 'model': {j: jm[j] for j in judges},
            'group': {j: jg[j] for j in judges}, 'own': own, 'set_families': {s: sf[s] for s in sets}}


# ---------------------------------------------------------------------------------------------------------- data model
def build_data(sets, judges, letters, mapping, positions, parses, own):
    J, N = len(judges), len(sets)
    si = {s: i for i, s in enumerate(sets)}
    d = SimpleNamespace(sets=sets, judges=judges, J=J, N=N, letters=letters,
                        group=[own['group'][j] for j in judges], family=[own['family'][j] for j in judges],
                        model=[own['model'][j] for j in judges])
    fams = sorted(set(d.family))
    d.fam_idx = np.array([fams.index(f) for f in d.family])
    d.T = np.full((J, N), np.nan)
    d.C = np.full((J, N, 5), np.nan)
    d.R = np.full((J, N), np.nan)
    d.POS = np.zeros((J, N), int)
    d.LET = np.zeros((J, N), int)
    d.score_ok = np.zeros(J, bool)
    d.rank_ok = np.zeros(J, bool)
    d.z_ok = np.zeros(J, bool)
    d.incoherent = np.zeros(J, bool)
    d.dropout = [None] * J
    d.BEST = [[None] * N_Q for _ in range(J)]
    d.own = {lev: np.array([[s in own['own'][lev][j] for s in sets] for j in judges]) for lev in (1, 2, 3)}
    for j, name in enumerate(judges):
        mp = mapping[name]
        for L, s in mp.items():
            d.POS[j, si[s]] = positions[name].index(L) + 1
            d.LET[j, si[s]] = letters.index(L)
        p = parses[name]
        d.dropout[j] = p.get('dropout')
        if d.dropout[j]:
            continue
        for L, sc in p['rows'].items():
            d.C[j, si[mp[L]]] = sc
            d.T[j, si[mp[L]]] = sum(sc)
        d.score_ok[j] = p['table_valid']
        if p['ranks']:
            for L, r in p['ranks'].items():
                d.R[j, si[mp[L]]] = r
            d.rank_ok[j] = True
        for q, L in p['best'].items():
            if L:
                d.BEST[j][int(q) - 1] = si[mp[L]]
        d.incoherent[j] = p['incoherent']
    d.Z = np.full((J, N), np.nan)
    d.ZC = np.full((J, N, 5), np.nan)
    d.zc_notes = []
    for j in range(J):
        if not d.score_ok[j]:
            continue
        t = d.T[j]
        if t.std() > 0:
            d.Z[j] = (t - t.mean()) / t.std()
            d.z_ok[j] = True
        for c in range(5):
            x = d.C[j, :, c]
            if x.std() > 0:
                d.ZC[j, :, c] = (x - x.mean()) / x.std()
            else:
                d.zc_notes.append(f'{judges[j]}: criterion {CRITERIA[c]} constant (excluded from its criterion z)')
    return d


# ------------------------------------------------------------------------------------------------------------ variants
def variant_defs():
    return [
        ('all', 'All valid judges (primary)', lambda d, j: True, None, 'judge'),
        ('own_l3', 'Without own set, level 3 = family (primary bias control)', lambda d, j: True, 3, 'judge'),
        ('own_l2', 'Without own set, level 2 = same model (sensitivity)', lambda d, j: True, 2, 'judge'),
        ('own_l1', 'Without own set, level 1 = same model + effort (sensitivity)', lambda d, j: True, 1, 'judge'),
        ('free', 'Free web judges only', lambda d, j: d.group[j] == 'free', None, 'judge'),
        ('api', 'API judges only (all Anthropic/OpenAI)', lambda d, j: d.group[j] == 'api', None, 'judge'),
        ('local', 'Local judges only', lambda d, j: d.group[j] == 'local', None, 'judge'),
        ('no_claude_gpt', 'Without Anthropic + OpenAI judges', lambda d, j: d.family[j] not in CLAUDE_GPT, None, 'judge'),
        ('family_weighted', 'All judges, each family weight 1', lambda d, j: True, None, 'family'),
        ('no_incoherent', 'All judges except those flagged incoherent', lambda d, j: not d.incoherent[j], None, 'judge'),
    ]


def weights(M, fam_idx, scheme):
    W = M.astype(float)
    if scheme == 'family':
        for f in np.unique(fam_idx):
            rows = fam_idx == f
            cnt = M[rows].sum(0)
            W[rows] = M[rows] / np.maximum(cnt, 1)
    return W


def wmean(X, W, M):
    X0 = np.where(M, np.nan_to_num(X), 0.0)
    num, den = (W * X0).sum(0), W.sum(0)
    return np.where(den > 0, num / np.where(den > 0, den, 1), np.nan)


def bootstrap_primary(d, Mz, scheme, cluster_by, B, rng):
    act = np.where(Mz.any(1))[0]
    if len(act) == 0:
        return np.full((B, d.N), np.nan), 0
    labels = [(d.model if cluster_by == 'model' else d.family)[j] for j in act]
    uniq = sorted(set(labels))
    cidx = np.array([uniq.index(x) for x in labels])
    m = draw_counts(rng, B, len(uniq))[:, cidx]
    Zs = np.where(Mz[act], np.nan_to_num(d.Z[act]), 0.0)
    Mf = Mz[act].astype(float)
    if scheme == 'judge':
        num, den = m @ Zs, m @ Mf
        est = np.where(den > 0, num / np.where(den > 0, den, 1), np.nan)
    else:
        acc, nf = np.zeros((B, d.N)), np.zeros((B, d.N))
        for f in sorted(set(d.family[j] for j in act)):
            ii = [k for k, j in enumerate(act) if d.family[j] == f]
            num, den = m[:, ii] @ Zs[ii], m[:, ii] @ Mf[ii]
            ok = den > 0
            acc += np.where(ok, num / np.where(ok, den, 1), 0.0)
            nf += ok
        est = np.where(nf > 0, acc / np.where(nf > 0, nf, 1), np.nan)
    return est, len(uniq)


def boot_summary(est):
    rk = min_rank_rows(est)
    return {'ci_lo': np.nanpercentile(est, 2.5, axis=0), 'ci_hi': np.nanpercentile(est, 97.5, axis=0),
            'rank_lo': np.percentile(rk, 2.5, axis=0, method='lower'),
            'rank_hi': np.percentile(rk, 97.5, axis=0, method='higher'),
            'p_rank1': (rk == 1).mean(0), 'n_nan': np.isnan(est).sum(0)}


def compute_variant(d, vdef, B, seed):
    name, desc, filt, level, scheme = vdef
    N = d.N
    jsel = np.array([bool(filt(d, j)) for j in range(d.J)])
    excl = d.own[level] if level else np.zeros((d.J, N), bool)
    Ms = jsel[:, None] & d.score_ok[:, None] & ~excl
    Mz = Ms & d.z_ok[:, None]
    Mr = jsel[:, None] & d.rank_ok[:, None] & ~excl
    primary = wmean(d.Z, weights(Mz, d.fam_idx, scheme), Mz)
    raw = wmean(d.T, weights(Ms, d.fam_idx, scheme), Ms)
    borda = wmean(N - d.R, weights(Mr, d.fam_idx, scheme), Mr)
    med, trim = np.full(N, np.nan), np.full(N, np.nan)
    for s in range(N):
        v = np.sort(d.Z[Mz[:, s], s])
        if len(v):
            med[s] = np.median(v)
        if len(v) >= 3:
            trim[s] = v[1:-1].mean()
    firsts = ((d.R == 1) & Mr).sum(0)
    n_z = Mz.sum(0)
    n_fam = np.array([len({d.family[j] for j in np.where(Mz[:, s])[0]}) for s in range(N)])
    crit = {}
    for c, cn in enumerate(CRITERIA):
        Mzc = Mz & ~np.isnan(d.ZC[:, :, c])
        crit[cn] = {'raw_mean': wmean(d.C[:, :, c], weights(Ms, d.fam_idx, scheme), Ms),
                    'raw_sum': np.where(Ms, np.nan_to_num(d.C[:, :, c]), 0).sum(0),
                    'z_mean': wmean(d.ZC[:, :, c], weights(Mzc, d.fam_idx, scheme), Mzc)}
    key = [(-(primary[s]) if math.isfinite(primary[s]) else math.inf,
            -(borda[s]) if math.isfinite(borda[s]) else math.inf, -int(firsts[s])) for s in range(N)]
    order = sorted(range(N), key=lambda s: (key[s], d.sets[s]))
    place = [1 + sum(key[t] < key[s] for t in range(N)) for s in range(N)]
    short = [d.sets[s] for s in range(N) if n_z[s] < MIN_JUDGES or n_fam[s] < MIN_FAMILIES]
    ranked = not short
    est, K = bootstrap_primary(d, Mz, scheme, 'model', B, rng_for(seed, 'boot', name, 'model'))
    bs = boot_summary(est)
    v = {'name': name, 'description': desc, 'own_level': level, 'weighting': scheme,
         'judges_selected': [d.judges[j] for j in np.where(jsel)[0]],
         'judges_scoring': [d.judges[j] for j in np.where(Mz.any(1))[0]],
         'judges_ranking': [d.judges[j] for j in np.where(Mr.any(1))[0]],
         'bootstrap_clusters_model': K, 'ranked': ranked, 'min_rule_failures': short,
         'order': [d.sets[s] for s in order], 'B': B}
    rows = []
    for s in order:
        rows.append({'place': place[s], 'set': d.sets[s], 'primary_mean_z': primary[s], 'ci_lo': bs['ci_lo'][s],
                     'ci_hi': bs['ci_hi'][s], 'rank_lo': bs['rank_lo'][s], 'rank_hi': bs['rank_hi'][s],
                     'p_rank1': bs['p_rank1'][s], 'boot_nan': bs['n_nan'][s], 'raw_mean_total': raw[s],
                     'borda_mean': borda[s], 'median_z': med[s], 'trimmed_mean_z': trim[s], 'first_places': firsts[s],
                     'n_judges_z': n_z[s], 'n_families_z': n_fam[s], 'n_judges_rank': Mr[:, s].sum(),
                     'criteria': {cn: {k: crit[cn][k][s] for k in crit[cn]} for cn in CRITERIA}})
    v['table'] = rows
    leader = order[0]
    lead_group = [d.sets[s] for s in order if bs['rank_lo'][s] == 1]
    if not ranked:
        v['decision'] = {'status': 'descriptive', 'winner': None, 'leading_group': None,
                         'reason': f'minimum rule (>= {MIN_JUDGES} judges with valid z from >= {MIN_FAMILIES} families '
                                   f'for every set) fails for {len(short)}/{N} sets; min judges {int(n_z.min())}, '
                                   f'min families {int(n_fam.min())}',
                         'failing_sets': short}
    elif bs['p_rank1'][leader] >= WINNER_P:
        v['decision'] = {'status': 'winner', 'winner': d.sets[leader], 'p_rank1': bs['p_rank1'][leader],
                         'leading_group': lead_group}
    else:
        v['decision'] = {'status': 'leading_group', 'winner': None, 'leading_group': lead_group,
                         'reason': f'P(rank=1) of point leader {d.sets[leader]} = {bs["p_rank1"][leader]:.3f} < {WINNER_P}'}
    if name in ('all', 'own_l3'):
        estf, Kf = bootstrap_primary(d, Mz, scheme, 'family', B, rng_for(seed, 'boot', name, 'family'))
        bf = boot_summary(estf)
        v['family_bootstrap'] = {'clusters': Kf, 'rows': [
            {'set': d.sets[s], 'ci_lo': bf['ci_lo'][s], 'ci_hi': bf['ci_hi'][s], 'rank_lo': bf['rank_lo'][s],
             'rank_hi': bf['rank_hi'][s], 'p_rank1': bf['p_rank1'][s]} for s in order]}
    return v, est


# ----------------------------------------------------------------------------------------------------------- agreement
def kendall_w(Rm):
    m, n = Rm.shape
    if m < 2:
        return {'m': m, 'n': n, 'W': None, 'chi2': None, 'p': None}
    Rs = Rm.sum(0)
    S = float(((Rs - Rs.mean()) ** 2).sum())
    T = 0.0
    for row in Rm:
        for c in Counter(row.tolist()).values():
            T += c ** 3 - c
    den = m * m * (n ** 3 - n) - m * T
    W = 12 * S / den if den > 0 else float('nan')
    chi2 = m * (n - 1) * W
    return {'m': m, 'n': n, 'W': W, 'chi2': chi2, 'df': n - 1, 'p': chi2_sf(chi2, n - 1)}


def agreement(d, B, seed):
    gm = {'free': [g == 'free' for g in d.group], 'api': [g == 'api' for g in d.group],
          'local': [g == 'local' for g in d.group], 'claude_gpt': [f in CLAUDE_GPT for f in d.family],
          'no_claude_gpt': [f not in CLAUDE_GPT for f in d.family], 'all': [True] * d.J}
    gm = {k: np.array(v) for k, v in gm.items()}
    point, boot = {}, {}
    for g in ('free', 'api', 'local', 'claude_gpt', 'no_claude_gpt'):
        Mz = gm[g][:, None] & d.score_ok[:, None] & d.z_ok[:, None] & np.ones((1, d.N), bool)
        point[g] = wmean(d.Z, Mz.astype(float), Mz)
        boot[g], _ = bootstrap_primary(d, Mz, 'judge', 'model', B, rng_for(seed, 'agree', g))
    pairs = []
    for a, b, note in (('local', 'api', 'also = others vs Claude/GPT (all API judges are Anthropic/OpenAI)'),
                       ('local', 'free', ''), ('free', 'api', ''),
                       ('claude_gpt', 'no_claude_gpt', 'supplementary (family split)')):
        rb = rowwise_spearman(boot[a], boot[b])
        ok = rb[~np.isnan(rb)]
        pairs.append({'a': a, 'b': b, 'rho': spearman(point[a], point[b]),
                      'ci_lo': float(np.percentile(ok, 2.5)) if len(ok) else None,
                      'ci_hi': float(np.percentile(ok, 97.5)) if len(ok) else None,
                      'n_boot_valid': int(len(ok)), 'note': note})
    W = {}
    for g in ('free', 'api', 'local', 'claude_gpt', 'no_claude_gpt', 'all'):
        rows = np.where(gm[g] & d.rank_ok)[0]
        W[g] = kendall_w(d.R[rows])
    rk = np.where(d.rank_ok)[0]
    pw = []
    for a, b in (('free', 'free'), ('api', 'api'), ('local', 'local'), ('free', 'api'), ('free', 'local'),
                 ('api', 'local')):
        if a == b:
            pr = [(j, k) for j in rk for k in rk if j < k and gm[a][j] and gm[a][k]]
        else:
            pr = [(j, k) for j in rk for k in rk if gm[a][j] and gm[b][k]]
        vals = [x for x in (pearson(d.R[j], d.R[k]) for j, k in pr) if math.isfinite(x)]
        pw.append({'a': a, 'b': b, 'mean_rho': float(np.mean(vals)) if vals else None, 'n_pairs': len(vals)})
    allv = [pearson(d.R[j], d.R[k]) for j in rk for k in rk if j < k]
    allv = [x for x in allv if math.isfinite(x)]
    return {'spearman_group_means': pairs, 'kendall_w': W, 'pairwise_spearman': pw,
            'pairwise_spearman_all': {'mean_rho': float(np.mean(allv)) if allv else None, 'n_pairs': len(allv)}}


# ----------------------------------------------------------------------------------------------------- best per question
def best_per_question(d, level=None):
    out, totals = [], Counter()
    for q in range(N_Q):
        votes = []
        for j in range(d.J):
            s = d.BEST[j][q]
            if s is None or (level and d.own[level][j, s]):
                continue
            votes.append(s)
        cnt = Counter(votes)
        nv = len(votes)
        ranked = sorted(cnt.items(), key=lambda kv: (-kv[1], d.sets[kv[0]]))
        top = ranked[0][1] if ranked else 0
        second = ranked[1][1] if len(ranked) > 1 else 0
        winner = d.sets[ranked[0][0]] if ranked and top - second >= BEST_MARGIN else None
        totals.update(cnt)
        out.append({'q': q + 1, 'n_votes': nv, 'winner': winner, 'margin': top - second,
                    'counts': [{'set': d.sets[s], 'votes': c, 'share': c / nv} for s, c in ranked]})
    tot = sorted(totals.items(), key=lambda kv: (-kv[1], d.sets[kv[0]]))
    return {'own_level_excluded': level, 'questions': out,
            'totals': [{'set': d.sets[s], 'votes': c} for s, c in tot]}


# -------------------------------------------------------------------------------------------- position and label effect
def position_effect(d, R, seed):
    V = d.score_ok & d.z_ok
    M = np.repeat(V[:, None], d.N, 1)
    Jv = int(V.sum())
    if Jv < 2:
        return {'n_judges': Jv, 'note': 'fewer than 2 judges with valid z: not estimated'}
    cnt = M.sum(0)
    zbar = np.where(M, np.nan_to_num(d.Z), 0).sum(0) / cnt
    Zp = np.where(M, np.nan_to_num(d.Z) - zbar, 0.0)

    def beta(P):
        Pm = np.where(M, P, 0)
        pbar = Pm.sum(-2) / cnt
        Pp = np.where(M, P - pbar[..., None, :], 0.0)
        return (Zp * Pp).sum((-2, -1)) / (Pp ** 2).sum((-2, -1))

    def cat_stat(P):  # between-position sum of squares of set-demeaned z
        r = P.shape[0]
        idx = (np.arange(r)[:, None, None] * d.N + (P - 1)).ravel()
        S = np.bincount(idx, weights=np.broadcast_to(Zp, P.shape).ravel(), minlength=r * d.N).reshape(r, d.N)
        return (S ** 2).sum(1) / Jv, S / Jv

    b_obs = float(beta(d.POS[None])[0])
    c_obs, means = cat_stat(d.POS[None])
    rng = rng_for(seed, 'position')
    nb = nc = 0
    done = 0
    while done < R:
        r = min(2000, R - done)
        P = np.argsort(rng.random((r, d.J, d.N)), axis=2) + 1
        nb += int((np.abs(beta(P)) >= abs(b_obs) - 1e-12).sum())
        nc += int((cat_stat(P)[0] >= c_obs[0] - 1e-12).sum())
        done += r
    k = min(3, d.N // 2)
    res = {'n_judges': Jv, 'n_cells': Jv * d.N, 'slope_z_per_position': b_obs,
           'implied_first_minus_last_z': -b_obs * (d.N - 1), 'slope_p_randomization': (1 + nb) / (R + 1),
           'categorical_stat': float(c_obs[0]), 'categorical_p_randomization': (1 + nc) / (R + 1),
           'mean_residual_z_by_position': means[0].tolist(),
           f'mean_residual_first{k}': float(means[0][:k].mean()), f'mean_residual_last{k}': float(means[0][-k:].mean()),
           'R': R}
    same = bool(np.all((d.LET + 1)[V] == d.POS[V]))
    if same:
        res['label_effect'] = {'confounded_with_position': True,
                               'note': 'letters were assigned in presentation order (first shown = Set A), so the '
                                       'label effect is identical to the categorical position effect above; it is '
                                       'no longer confounded with set content.'}
    else:
        c_l, m_l = cat_stat((d.LET + 1)[None])
        rng2 = rng_for(seed, 'label')
        n2 = 0
        done = 0
        while done < R:
            r = min(2000, R - done)
            P = np.argsort(rng2.random((r, d.J, d.N)), axis=2) + 1
            n2 += int((cat_stat(P)[0] >= c_l[0] - 1e-12).sum())
            done += r
        res['label_effect'] = {'confounded_with_position': False, 'categorical_stat': float(c_l[0]),
                               'categorical_p_randomization': (1 + n2) / (R + 1),
                               'mean_residual_z_by_letter': dict(zip(d.letters, m_l[0].tolist()))}
    return res


# ----------------------------------------------------------------------------------------------------- self-preference
def self_preference(d, R, seed):
    V = d.score_ok & d.z_ok
    out = {}
    for lev in (1, 2, 3):
        O = d.own[lev]
        elig = V[:, None] & ~O
        Zv = np.where(elig, np.nan_to_num(d.Z), 0.0)
        S, C = Zv.sum(0), elig.sum(0)
        judges, fam_acc = [], {}
        for j in range(d.J):
            if not V[j] or not O[j].any():
                continue
            sj, cj = S - Zv[j], C - elig[j]
            D = np.where(cj > 0, d.Z[j] - sj / np.maximum(cj, 1), np.nan)
            own_idx = np.where(O[j])[0]
            k = len(own_idx)
            obs = float(np.nanmean(D[own_idx]))
            rng = rng_for(seed, 'selfpref', str(lev), d.judges[j])
            idx = np.argsort(rng.random((R, d.N)), axis=1)[:, :k]
            vals = D[idx]
            null = np.nanmean(vals, 1)
            p = (1 + int((null >= obs - 1e-12).sum())) / (R + 1) if math.isfinite(obs) else None
            flag = bool(math.isfinite(obs) and obs >= SELFPREF_MIN_D and p is not None and p < SELFPREF_ALPHA)
            judges.append({'judge': d.judges[j], 'family': d.family[j], 'n_own_sets': k,
                           'own_sets': [d.sets[s] for s in own_idx], 'self_pref_d': obs, 'p_perm': p, 'flag': flag})
            a = fam_acc.setdefault(d.family[j], {'sum': 0.0, 'n': 0, 'null_sum': np.zeros(R), 'null_n': np.zeros(R),
                                                 'members': []})
            ok = ~np.isnan(D[own_idx])
            a['sum'] += float(D[own_idx][ok].sum())
            a['n'] += int(ok.sum())
            a['null_sum'] += np.nansum(vals, 1)
            a['null_n'] += (~np.isnan(vals)).sum(1)
            a['members'].append(d.judges[j])
        fams = []
        for f, a in sorted(fam_acc.items()):
            obs = a['sum'] / a['n'] if a['n'] else float('nan')
            null = a['null_sum'] / np.maximum(a['null_n'], 1)
            p = (1 + int((null >= obs - 1e-12).sum())) / (R + 1) if math.isfinite(obs) else None
            fams.append({'family': f, 'members': a['members'], 'n_cells': a['n'], 'self_pref_d': obs, 'p_perm': p,
                         'flag': bool(math.isfinite(obs) and obs >= SELFPREF_MIN_D and p < SELFPREF_ALPHA)})
        out[f'level{lev}'] = {'judges': judges, 'families': fams}
    return out


# ------------------------------------------------------------------------------------------------------------- pipeline
def read_key(key_path):
    key = json.loads(Path(key_path).read_text(encoding='utf-8'))
    mapping = key['mapping']
    judges = list(mapping)
    sets = sorted(set(mapping[judges[0]].values()))
    N = len(sets)
    letters = list(ALPHABET[:N])
    for j in judges:
        mp = mapping[j]
        if sorted(mp) != letters or sorted(mp.values()) != sets:
            raise SystemExit(f'key mapping for {j} is not a bijection letters A-{letters[-1]} -> the {N} sets')
    return key, mapping, judges, sets, letters


def presentation_positions(key, judges, letters, prompts_dir=None):
    if 'presentation_order' in key:
        pos, src = {j: list(key['presentation_order'][j]) for j in judges}, 'key.presentation_order'
    elif prompts_dir:
        pos, src = {}, 'prompt files'
        for j in judges:
            txt = (Path(prompts_dir) / f'PROMPT_{j}.txt').read_text(encoding='utf-8')
            pos[j] = re.findall(r'^Set ([A-Z])\s*$', txt, re.M)
    else:
        pos, src = {j: list(letters) for j in judges}, 'letter order (build: first shown = Set A)'
    for j in judges:
        if sorted(pos[j]) != letters:
            raise SystemExit(f'presentation order for {j} is not a permutation of the letters')
    return pos, src


def check_key_hash(h, expect):
    if not expect:
        return None
    e = expect.lower()
    for sep in ('...', '…'):
        if sep in e:
            a, b = e.split(sep, 1)
            return h.startswith(a) and h.endswith(b)
    return h == e


def run_full(key_path, replies_dir, own_path, out_dir, seed=SEED_DEFAULT, B=B_DEFAULT, R=R_DEFAULT, prompts=None,
             expect_key=None, quiet=False):
    t0 = dt.datetime.now(dt.timezone.utc)
    key_sha = sha256_file(key_path)
    ok = check_key_hash(key_sha, expect_key)
    if ok is False:
        raise SystemExit(f'key SHA-256 {key_sha} does not match expected {expect_key}')
    key, mapping, judges, sets, letters = read_key(key_path)
    own = load_own_table(own_path, judges, sets)
    positions, pos_src = presentation_positions(key, judges, letters, prompts)
    recs, manifest = collect_replies(replies_dir, judges)
    parses = parse_all(recs, letters)
    d = build_data(sets, judges, letters, mapping, positions, parses, own)
    variants, ests = [], {}
    for vd in variant_defs():
        v, est = compute_variant(d, vd, B, seed)
        variants.append(v)
        ests[v['name']] = est
    res = {
        'spec_version': SPEC_VERSION, 'run_utc': t0.isoformat(timespec='seconds'),
        'config': {'seed': seed, 'B': B, 'R': R, 'min_judges': MIN_JUDGES, 'min_families': MIN_FAMILIES,
                   'incoherent_rho': INCOHERENT_RHO, 'best_margin': BEST_MARGIN, 'winner_p_rank1': WINNER_P,
                   'selfpref_min_d': SELFPREF_MIN_D, 'selfpref_alpha': SELFPREF_ALPHA, 'z_sd': 'population (ddof=0)',
                   'position_source': pos_src},
        'inputs': {'script_sha256': sha256_file(__file__), 'key_path': str(key_path), 'key_sha256': key_sha,
                   'key_sha256_expected': expect_key, 'key_sha256_match': ok, 'own_table_path': str(own_path),
                   'own_table_sha256': sha256_file(own_path), 'replies_dir': str(replies_dir),
                   'replies_manifest_sha256': manifest['manifest_sha256'], 'reply_files': manifest['files'],
                   'ignored_files': manifest['ignored_files']},
        'n_sets': d.N, 'sets': sets, 'judges': [{'judge': j, 'group': d.group[i], 'family': d.family[i],
                                                 'model_cluster': d.model[i]} for i, j in enumerate(judges)],
        'parse': parse_summary(parses), 'criterion_z_notes': d.zc_notes,
        'judge_status': {j: {'dropout': d.dropout[i], 'score_valid': bool(d.score_ok[i]), 'z_valid': bool(d.z_ok[i]),
                             'rank_valid': bool(d.rank_ok[i]), 'incoherent': bool(d.incoherent[i])}
                         for i, j in enumerate(judges)},
        'variants': variants,
        'agreement': agreement(d, B, seed),
        'best_per_question': {'all': best_per_question(d), 'own_l3': best_per_question(d, 3)},
        'position_label_effect': position_effect(d, R, seed),
        'self_preference': self_preference(d, R, seed),
    }
    res = jclean(res)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    h_man = write_new(out / 'REPLIES_MANIFEST.sha256', manifest['manifest_text'])
    h_json = write_new(out / 'GODS10_AGG_RESULTS.json', json.dumps(res, indent=1, ensure_ascii=False, allow_nan=False))
    h_md = write_new(out / 'GODS10_AGG_REPORT.md', make_report(res))
    if not quiet:
        print(json.dumps({'out': str(out), 'results_sha256': h_json, 'report_sha256': h_md, 'manifest_sha256': h_man,
                          'decisions': {v['name']: v['decision'] for v in res['variants']}}, indent=1))
    return res, d, ests


def run_prekey(replies_dir, n_sets, out_dir, quiet=False):
    letters = list(ALPHABET[:n_sets])
    recs, manifest = collect_replies(replies_dir)
    parses = parse_all(recs, letters)
    res = jclean({'spec_version': SPEC_VERSION, 'mode': 'pre-key parse (no key used)',
                  'run_utc': dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds'),
                  'script_sha256': sha256_file(__file__), 'n_sets': n_sets, 'letters': ''.join(letters),
                  'replies_dir': str(replies_dir), 'replies_manifest_sha256': manifest['manifest_sha256'],
                  'reply_files': manifest['files'], 'parse': parse_summary(parses)})
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    write_new(out / 'REPLIES_MANIFEST.sha256', manifest['manifest_text'])
    h = write_new(out / 'GODS10_PREKEY_PARSE.json', json.dumps(res, indent=1, ensure_ascii=False, allow_nan=False))
    md = ['# GODS10 pre-key parse log', '', f'- Spec: {SPEC_VERSION}', f'- Run (UTC): {res["run_utc"]}',
          f'- Script SHA-256: `{res["script_sha256"]}`', f'- Letters: {res["letters"]} (N = {n_sets}); key NOT used',
          f'- Replies manifest SHA-256: `{res["replies_manifest_sha256"]}`', '']
    md += md_parse_section(res['parse'], None)
    write_new(out / 'GODS10_PREKEY_PARSE.md', '\n'.join(md) + '\n')
    if not quiet:
        print(json.dumps({'out': str(out), 'prekey_json_sha256': h, 'manifest_sha256': manifest['manifest_sha256'],
                          'valid_tables': sum(p['table_valid'] for p in res['parse'].values()),
                          'judges': len(res['parse'])}, indent=1))
    return res


# --------------------------------------------------------------------------------------------------------------- report
def md_parse_section(parse, judges_meta):
    meta = {m['judge']: m for m in judges_meta} if judges_meta else {}
    L = ['## Parse log', '',
         '| Judge | Group | Family | Reply used | SHA-256 (12) | Valid rows | Table | Ranking | Best Qs | sd=0 | rho(rank,total) | Flags |',
         '|---|---|---|---|---|---:|---|---|---:|---|---:|---|']
    for j, p in parse.items():
        m = meta.get(j, {})
        sha = (p['retry_sha256'] if p['reply_used'] == 'retry' else p['first_sha256']) or ''
        flags = []
        if p['dropout']:
            flags.append('DROPOUT: ' + p['dropout'])
        if p['incoherent']:
            flags.append('INCOHERENT')
        if p['retry_sha256']:
            flags.append('retry used')
        L.append(f"| {j} | {m.get('group', '')} | {m.get('family', '')} | {p['reply_used'] or '-'} | {sha[:12]} | "
                 f"{p['n_valid_rows']} | {'valid' if p['table_valid'] else 'INVALID'} | {p['rank_source']} | "
                 f"{p['n_best_valid']}/{N_Q} | {'yes' if p['sd0'] else 'no'} | {fmt(p['consistency_rho'])} | "
                 f"{'; '.join(flags)} |")
    L += ['', '### Parse issues (per judge)', '']
    for j, p in parse.items():
        items = list(p['row_issues']) + list(p['total_notes']) + list(p['notes'])
        if p['ranking_issue'] and p['ranking_status'] != 'valid':
            items.append(f"ranking: {p['ranking_status']} ({p['ranking_issue']}) -> {p['rank_source']}")
        items += [f'best: {x}' for x in p['best_issues']]
        if items:
            L.append(f'- **{j}**: ' + ' | '.join(items))
    return L + ['']


def make_report(res):
    L = [f'# GODS10 aggregation report', '',
         f'- Spec: {res["spec_version"]}; run (UTC) {res["run_utc"]}',
         f'- Seed {res["config"]["seed"]}, bootstrap B = {res["config"]["B"]}, randomization R = {res["config"]["R"]}',
         f'- N sets = {res["n_sets"]}, judges = {len(res["judges"])}; presentation order source: '
         f'{res["config"]["position_source"]}', '', '## Inputs (SHA-256)', '',
         f'- Script: `{res["inputs"]["script_sha256"]}`',
         f'- Key: `{res["inputs"]["key_sha256"]}` (expected: {res["inputs"]["key_sha256_expected"]}, '
         f'match: {res["inputs"]["key_sha256_match"]})',
         f'- Own-set table: `{res["inputs"]["own_table_sha256"]}`',
         f'- Replies manifest: `{res["inputs"]["replies_manifest_sha256"]}`', '']
    L += [f'  - `{f["sha256"]}`  {f["name"]}' for f in res['inputs']['reply_files']]
    if res['inputs']['ignored_files']:
        L.append(f'- Ignored files in replies dir: {", ".join(res["inputs"]["ignored_files"])}')
    L.append('')
    L += md_parse_section(res['parse'], res['judges'])
    if res['criterion_z_notes']:
        L += ['Criterion z notes: ' + '; '.join(res['criterion_z_notes']), '']
    L += ['## Summary of variants', '', '| Variant | Judges (z-valid) | Status | Winner / leading group |', '|---|---:|---|---|']
    for v in res['variants']:
        dcs = v['decision']
        what = dcs['winner'] if dcs['status'] == 'winner' else (', '.join(dcs['leading_group'] or []) or '-')
        L.append(f"| {v['name']} | {len(v['judges_scoring'])} | {dcs['status']} | {what} |")
    L += ['', 'Tie-break order for publication: primary (mean z), then Borda, then number of first places; equal on all '
              'three = shared place. Leading group = sets whose 95% bootstrap rank interval includes 1.', '']
    for v in res['variants']:
        dcs = v['decision']
        L += [f"## Variant `{v['name']}`: {v['description']}", '',
              f"- Status: **{dcs['status'].upper()}**" + (f" ({dcs.get('reason')})" if dcs.get('reason') else ''),
              f"- Judges with valid z: {len(v['judges_scoring'])} ({', '.join(v['judges_scoring'])}); "
              f"rankings used: {len(v['judges_ranking'])}; model clusters in bootstrap: {v['bootstrap_clusters_model']}",
              '',
              '| Place | Set | mean z | 95% CI | rank 95% | P(rank=1) | raw mean | Borda | median z | trimmed z | #1st | n z (fam) | n rank |',
              '|---:|---|---:|---|---|---:|---:|---:|---:|---:|---:|---|---:|']
        for r in v['table']:
            place = str(r['place']) if v['ranked'] else '-'
            L.append(f"| {place} | {r['set']} | {fmt(r['primary_mean_z'])} | [{fmt(r['ci_lo'])}, {fmt(r['ci_hi'])}] | "
                     f"{fmt(r['rank_lo'], 0)}-{fmt(r['rank_hi'], 0)} | {fmt(r['p_rank1'])} | {fmt(r['raw_mean_total'], 2)} | "
                     f"{fmt(r['borda_mean'], 2)} | {fmt(r['median_z'])} | {fmt(r['trimmed_mean_z'])} | "
                     f"{r['first_places']} | {r['n_judges_z']} ({r['n_families_z']}) | {r['n_judges_rank']} |")
        if v['name'] in ('all', 'own_l3'):
            L += ['', 'Per criterion (mean raw / mean z / raw sum):', '',
                  '| Set | ' + ' | '.join(CRITERIA) + ' |', '|---|' + '---|' * len(CRITERIA)]
            for r in v['table']:
                L.append(f"| {r['set']} | " + ' | '.join(
                    f"{fmt(r['criteria'][c]['raw_mean'], 2)} / {fmt(r['criteria'][c]['z_mean'], 2)} / "
                    f"{fmt(r['criteria'][c]['raw_sum'], 0)}" for c in CRITERIA) + ' |')
        if 'family_bootstrap' in v:
            fb = v['family_bootstrap']
            L += ['', f"Sensitivity: bootstrap clustered by family ({fb['clusters']} clusters):", '',
                  '| Set | 95% CI | rank 95% | P(rank=1) |', '|---|---|---|---:|']
            for r in fb['rows']:
                L.append(f"| {r['set']} | [{fmt(r['ci_lo'])}, {fmt(r['ci_hi'])}] | {fmt(r['rank_lo'], 0)}-"
                         f"{fmt(r['rank_hi'], 0)} | {fmt(r['p_rank1'])} |")
        L.append('')
    ag = res['agreement']
    L += ['## Agreement', '', 'Note: the API group consists only of Anthropic/OpenAI models, so API vs local is also '
          'Claude/GPT vs others (Zora 3.1).', '', '| Group means (mean z) | Spearman rho | 95% CI (stratified cluster bootstrap) | note |',
          '|---|---:|---|---|']
    for p in ag['spearman_group_means']:
        L.append(f"| {p['a']} vs {p['b']} | {fmt(p['rho'])} | [{fmt(p['ci_lo'])}, {fmt(p['ci_hi'])}] | {p['note']} |")
    L += ['', "| Group | Kendall's W | m judges | chi2 | p |", '|---|---:|---:|---:|---:|']
    for g, w in ag['kendall_w'].items():
        L.append(f"| {g} | {fmt(w['W'])} | {w['m']} | {fmt(w.get('chi2'), 1)} | {fmt(w.get('p'), 4)} |")
    L += ['', '| Pairwise Spearman between judges | mean rho | pairs |', '|---|---:|---:|']
    for p in ag['pairwise_spearman']:
        L.append(f"| {p['a']} x {p['b']} | {fmt(p['mean_rho'])} | {p['n_pairs']} |")
    L.append(f"| all x all | {fmt(ag['pairwise_spearman_all']['mean_rho'])} | {ag['pairwise_spearman_all']['n_pairs']} |")
    L.append('')
    for k, bp in res['best_per_question'].items():
        L += [f'## Best answer per question (`{k}`)', '', f'Winner only if >= {BEST_MARGIN} votes ahead of the runner-up.', '',
              '| Q | votes | winner | margin | top counts (share) |', '|---:|---:|---|---:|---|']
        for q in bp['questions']:
            top = ', '.join(f"{c['set']} {c['votes']} ({c['share']:.2f})" for c in q['counts'][:4])
            L.append(f"| Q{q['q']} | {q['n_votes']} | {q['winner'] or '-'} | {q['margin']} | {top} |")
        L += ['', 'Totals over Q1-Q10: ' + ', '.join(f"{t['set']} {t['votes']}" for t in bp['totals']), '']
    pe = res['position_label_effect']
    L += ['## Position and label effect', '']
    if 'slope_z_per_position' in pe:
        L += [f"- Slope of z on presentation position (set fixed effects): {fmt(pe['slope_z_per_position'], 4)} z/position; "
              f"implied first-minus-last {fmt(pe['implied_first_minus_last_z'])} z; randomization p = "
              f"{fmt(pe['slope_p_randomization'], 4)} (R = {pe['R']})",
              f"- Position as a factor: stat {fmt(pe['categorical_stat'])}, randomization p = "
              f"{fmt(pe['categorical_p_randomization'], 4)}",
              '- Mean set-demeaned z by position: ' + ', '.join(f'{i + 1}:{x:+.2f}' for i, x in
                                                               enumerate(pe['mean_residual_z_by_position'])),
              f"- Label effect: {pe['label_effect'].get('note') or ('p = ' + fmt(pe['label_effect'].get('categorical_p_randomization'), 4))}"]
    else:
        L.append('- ' + pe.get('note', 'not estimated'))
    L += ['', '## Self-preference', '',
          f'd = mean z the judge gives its own sets minus the mean z that non-own judges give the same sets; p from '
          f'{res["config"]["R"]} random same-size set subsets of the same judge; flag if d >= {SELFPREF_MIN_D} and '
          f'p < {SELFPREF_ALPHA} (uncorrected; expect about 1 false flag in 20 tests).', '']
    for lev, sp in res['self_preference'].items():
        L += [f'### {lev}', '', '| Judge | Family | own sets | d | p | flag |', '|---|---|---:|---:|---:|---|']
        for r in sp['judges']:
            L.append(f"| {r['judge']} | {r['family']} | {r['n_own_sets']} | {fmt(r['self_pref_d'])} | "
                     f"{fmt(r['p_perm'], 4)} | {'FLAG' if r['flag'] else ''} |")
        L += ['', '| Family | judges | cells | d | p | flag |', '|---|---|---:|---:|---:|---|']
        for r in sp['families']:
            L.append(f"| {r['family']} | {', '.join(r['members'])} | {r['n_cells']} | {fmt(r['self_pref_d'])} | "
                     f"{fmt(r['p_perm'], 4)} | {'FLAG' if r['flag'] else ''} |")
        L.append('')
    return '\n'.join(L) + '\n'


# ------------------------------------------------------------------------------------------------------------ self-test
def render_reply(style, rows, ranking, best, colorder=None):
    """rows: list of (label, [5 cells as str in CRITERIA order or custom], total str or None)."""
    cols = colorder or list(CRITERIA)
    out = []
    if style == 0:
        out += ['TABLE (one row per set)', '', '| Set | ' + ' | '.join(c.capitalize() for c in cols) + ' | Total |',
                '|---|' + '---|' * (len(cols) + 1)]
        out += [f'| **{lab}** | ' + ' | '.join(cells) + f' | **{tot}** |' for lab, cells, tot in rows]
        out += ['', '**RANKING:** ' + ' > '.join(ranking), '', '**BEST ANSWER PER QUESTION:**']
        out += [f'- Q{q}: {b}' for q, b in enumerate(best, 1)]
        out += ['', '**JUSTIFICATION:**', '- A: 9 8 7 6 5 reasons I liked it.', '- B: Solid but derivative.']
    elif style == 1:
        out += ['TABLE (one row per set): set | ' + ' | '.join(cols) + ' | total']
        out += [f'{lab} | ' + ' | '.join(cells) + f' | {tot}' for lab, cells, tot in rows]
        out += ['RANKING: ' + ', '.join(ranking), 'BEST ANSWER PER QUESTION: Q1-Q10: ' + ', '.join(best),
                'JUSTIFICATION: All sets were read carefully.']
    elif style == 2:
        out += ['## TABLE', 'set: ' + ' '.join(cols) + ' = total']
        out += [f'Set {lab}: ' + ' '.join(cells) + f' = {tot}' for lab, cells, tot in rows]
        out += ['', '## RANKING'] + [f'{i}. Set {x}' for i, x in enumerate(ranking, 1)]
        out += ['', '## BEST ANSWER PER QUESTION', '| Question | Best |', '|---|---|']
        out += [f'| Q{q} | {b} |' for q, b in enumerate(best, 1)]
        out += ['', '## JUSTIFICATION', 'Overall a strong field.']
    else:
        out += ['### TABLE', '| Set | ' + ' | '.join(c.capitalize() for c in cols) + ' | Total |', '|:-:|' + ':-:|' * (len(cols) + 1)]
        out += [f'| Set {lab} | ' + ' | '.join(cells) + f' | {tot} |' for lab, cells, tot in rows]
        out += ['', 'RANKING: ' + '>'.join(ranking), '', 'BEST ANSWER PER QUESTION']
        out += [f'Q{q} - {b}' for q, b in enumerate(best, 1)]
        out += ['', 'JUSTIFICATION', 'See table.']
    return '\n'.join(out) + '\n'


def parser_unit_checks(check):
    """Hand-written replies in formats real judges use (4 sets A-D)."""
    L4 = list('ABCD')
    qs = '\n'.join(f'Q{q}: {x}' for q, x in zip(range(3, 11), 'DABCDABC'))
    r1 = parse_reply('Here is my evaluation.\n\n| Set | Insight (1-10) | Coherence | Originality | Clarity | Credibility '
                     '| Total |\n|-----|---|---|---|---|---|---|\n| **Set A** | 8 | 7 | 9 | 8 | 7 | 39 |\n'
                     '| **Set B** | 6 | 6 | 5 | 7 | 6 | 30 |\n| **Set C** | 7.5 | 7 | 7 | 7 | 7 | 35.5 |\n'
                     '| **Set D** | 5 | 5 | 5 | 5 | 5 | 25 |\n\n**RANKING:** A > B > D > C\n\n'
                     '**BEST ANSWER PER QUESTION:**\nQ1 (What is the fundamental nature of reality?): A\nQ2: B/C\n'
                     + qs + '\n\n**JUSTIFICATION:**\n- Set A: 9 9 9 9 9 would be too generous.\n', L4)
    check('unit: non-integer score invalidates row -> table invalid, explicit ranking kept',
          r1['n_valid_rows'] == 3 and not r1['table_valid'] and r1['rank_source'] == 'explicit'
          and any("'7.5'" in x for x in r1['row_issues']), str(r1['row_issues']))
    check('unit: Q with two letters invalid, Q with question text valid',
          r1['best'][1] == 'A' and r1['best'][2] is None and r1['n_best_valid'] == 9, str(r1['best_issues']))
    r2 = parse_reply('RANKING: C, A, B, D\nTABLE\nA: 8, 7, 9, 8, 7 (39)\nB: 6 6 5 7 6 30\nC: 9 9 9 9 9 45\n'
                     'D: 1 2 3 4 5 15\nBEST ANSWER PER QUESTION: C C C A A A B B D C\n'
                     'JUSTIFICATION: A is deep. B: 5 5 5 5 5 average.\n', L4)
    check('unit: RANKING before TABLE, plain rows, letter-sequence best answers',
          r2['table_valid'] and r2['ranking_explicit'] == list('CABD') and r2['n_best_valid'] == 10
          and abs(r2['consistency_rho'] - 1) < 1e-9 and r2['rows']['A'] == [8, 7, 9, 8, 7], str(r2['total_notes']))
    r3 = parse_reply('TABLE\n| A | 8 | 8 | 8 | 8 | 8 | 40 |\n| B | 7 | 7 | 7 | 7 | 7 | 35 |\n| C | 7 | 7 | 7 | 7 | 7 | 35 |\n'
                     '| D | 9 | 9 | 9 | 9 | 9 | 45 |\nRANKING: D > A > B = C\nBEST ANSWER PER QUESTION: Q1-Q10: '
                     'D, D, D, D, D, A, A, A, A, A\n', L4)
    check('unit: tie in RANKING -> derived from totals with average ranks',
          r3['rank_source'] == 'derived_from_totals' and r3['ranks'] == {'D': 1.0, 'A': 2.0, 'B': 3.5, 'C': 3.5}
          and r3['n_best_valid'] == 10, str(r3['ranks']))
    r4 = parse_reply('| Set | insight | coherence | originality | clarity | credibility | total | notes |\n'
                     '| A | 8 | 8 | 8 | 8 | 8 | 40 | deep |\n| B | 7 | 7 | 7 | 7 | 7 | 35 | ok |\n'
                     '| c | 7 | 7 | 7 | 7 | 7 | 35 | ok |\n| D | 9 | 9 | 9 | 9 | 9 | 45 | best |\n'
                     'RANKING: D A B C\n', L4)
    check('unit: extra column and lowercase label rejected (strict), no BEST section logged',
          r4['n_valid_rows'] == 0 and r4['rank_source'] == 'explicit' and r4['n_best_valid'] == 0
          and any('lowercase' in x or "'c'" in x for x in r4['row_issues']), str(r4['row_issues'][:2]))
    r5 = parse_reply("I'm sorry, I can't evaluate these.\n", L4)
    check('unit: refusal -> dropout', r5['dropout'] is not None)


def selftest(args):
    checks = []

    def check(name, cond, info=''):
        checks.append((name, bool(cond), info))
        print(('PASS ' if cond else 'FAIL ') + name + (f'  [{info}]' if info else ''))

    parser_unit_checks(check)

    seed = args.seed
    own_path = Path(args.own) if args.own else HERE / 'own_set_table.json'
    ot = json.loads(own_path.read_text(encoding='utf-8'))
    sets = sorted(ot['set_families'])
    judges = sorted(ot['judge_family'], key=lambda j: (['free', 'api', 'local'].index(ot['judge_group'][j]), j))
    N = len(sets)
    letters = list(ALPHABET[:N])
    stamp = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    out = Path(args.out) if args.out else HERE / 'selftest_runs' / f'run_{stamp}'
    out.mkdir(parents=True, exist_ok=False)
    inp = out / 'synthetic_inputs'
    rdir = inp / 'replies'
    rdir.mkdir(parents=True)
    rng = rng_for(seed, 'selftest')
    mapping = {}
    for j in judges:
        perm = rng.permutation(N)
        mapping[j] = {letters[i]: sets[perm[i]] for i in range(N)}
    key_path = inp / 'SYNTHETIC_KEY.json'
    write_new(key_path, json.dumps({'mapping': mapping, 'synthetic': True, 'note': 'self-test only'}, indent=1))
    planted_best = 'free_Gemini' if 'free_Gemini' in sets else sets[0]
    others = [s for s in sets if s != planted_best]
    q = dict(zip(others, rng.permutation(np.linspace(-1.5, 0.8, len(others)))))
    q[planted_best] = 1.6
    sp_judge = 'api_gpt-6-sol_high' if 'api_gpt-6-sol_high' in judges else judges[-1]
    sp_own = set(ot['own']['level3'][sp_judge])
    special = {'malformed': 'local_lfm2.5', 'derived': 'free_Qwen', 'incoherent': 'local_magistral',
               'sd0': 'free_Grok', 'retry': 'free_ChatGPT', 'missing': 'local_ministral3',
               'remap': 'api_claude-opus-5-5_max'}
    special = {k: v for k, v in special.items() if v in judges}
    truth = {}
    for ji, j in enumerate(judges):
        bias, scale = rng.uniform(-1, 1), rng.uniform(0.7, 1.3)
        rows, tot_by_letter = [], {}
        sc_by_letter = {}
        for pos, L in enumerate(letters, 1):
            s = mapping[j][L]
            mu = 6 + bias + scale * 1.5 * q[s] + 1.2 * (N - pos) / (N - 1) + (2.5 if j == sp_judge and s in sp_own else 0)
            sc = [int(np.clip(round(mu + rng.normal(0, 0.7)), 1, 10)) for _ in CRITERIA]
            if j == special.get('sd0'):
                sc = [7] * 5
            sc_by_letter[L] = sc
            tot_by_letter[L] = sum(sc)
        truth[j] = sc_by_letter
        rank = sorted(letters, key=lambda L: (-tot_by_letter[L], L))
        if j == special.get('incoherent'):
            rank = rank[::-1]
        if j == special.get('sd0'):
            rank = list(rng.permutation(letters))
        best = []
        for _ in range(N_Q):
            noisy = {L: q[mapping[j][L]] + rng.normal(0, 0.6) for L in letters}
            best.append(max(letters, key=lambda L: noisy[L]))
        colorder = None
        if j == special.get('remap'):
            colorder = ['clarity', 'insight', 'coherence', 'originality', 'credibility']
        rows = []
        for L in letters:
            sc = sc_by_letter[L]
            cells = [str(sc[CRITERIA.index(c)]) for c in (colorder or CRITERIA)]
            tot = str(sum(sc))
            rows.append([L, cells, tot])
        if j == special.get('derived'):
            rank = rank[:-3]
            rows[2][2] = str(int(rows[2][2]) + 1)
        if j == special.get('malformed'):
            rows[3][1][0] = '11'
            bad = ALPHABET[N] if N < 26 else '?'
            rows[5][0] = bad
            rank = rank[:-1] + [rank[0]]
            best[3] = bad
        style = 3 if j == special.get('remap') else ji % 3
        text = render_reply(style, rows, rank, best, colorder)
        if j == special.get('missing'):
            continue
        if j == special.get('retry'):
            write_new(rdir / f'{j}.txt', "I'm sorry, but I can't help with rating these.\n")
            write_new(rdir / f'{j}.retry.txt', text)
        else:
            write_new(rdir / f'{j}.txt', text)
    # 1) pre-key parse (no key)
    pk = run_prekey(rdir, N, out / 'prekey', quiet=True)
    # 2) full pipeline
    res, d, ests = run_full(key_path, rdir, own_path, out / 'full', seed=seed, B=args.bootstrap, R=args.bootstrap,
                            quiet=True)
    P = res['parse']
    mj = special.get('malformed')
    if mj:
        p = P[mj]
        txt = ' '.join(p['row_issues'])
        check('malformed reply: table invalid, 21 valid rows', (not p['table_valid']) and p['n_valid_rows'] == N - 2,
              f"valid rows {p['n_valid_rows']}")
        check('malformed reply: out-of-range, unknown letter and missing row logged',
              'outside 1-10' in txt and 'unknown letter' in txt and 'missing rows' in txt, txt[:160])
        check('malformed reply: invalid ranking not derivable -> none', p['rank_source'] == 'none'
              and p['ranking_status'] == 'invalid', p['ranking_issue'])
        check('malformed reply: best-per-question 9/10 valid', p['n_best_valid'] == N_Q - 1, str(p['best_issues']))
        check('malformed judge excluded from score metrics', mj not in res['variants'][0]['judges_scoring'])
    if special.get('derived'):
        p = P[special['derived']]
        check('broken RANKING with valid table -> derived from totals',
              p['rank_source'] == 'derived_from_totals' and p['ranking_status'] == 'invalid', p['ranking_issue'])
        check('reported-total mismatch logged only', p['table_valid'] and any('recomputed' in x for x in p['total_notes']))
    if special.get('retry'):
        p = P[special['retry']]
        check('retry used (both hashes kept)', p['reply_used'] == 'retry' and p['first_sha256'] and p['table_valid'])
    if special.get('missing'):
        check('missing reply -> dropout', P[special['missing']]['dropout'] == 'missing reply')
    if special.get('remap'):
        p = P[special['remap']]
        check('column order remapped from header', any('remapped' in x for x in p['notes']))
    rt = all(P[j]['table_valid'] is False or all(
        [d.C[d.judges.index(j), d.sets.index(mapping[j][L])].astype(int).tolist() == truth[j][L] for L in letters])
             for j in judges if not P[j]['dropout'])
    check('round trip: parsed scores equal generated scores for every valid table', rt)
    if special.get('incoherent'):
        check('incoherent judge flagged (rho < 0.5)', P[special['incoherent']]['incoherent'],
              fmt(P[special['incoherent']]['consistency_rho']))
        v_ni = next(v for v in res['variants'] if v['name'] == 'no_incoherent')
        check('no_incoherent variant excludes the incoherent judge', special['incoherent'] not in v_ni['judges_selected'])
    if special.get('sd0'):
        check('sd = 0 judge excluded from z, ranking kept', P[special['sd0']]['sd0']
              and special['sd0'] not in res['variants'][0]['judges_scoring']
              and special['sd0'] in res['variants'][0]['judges_ranking'])
    pk_valid = {j: x['table_valid'] for j, x in pk['parse'].items()}
    full_valid = {j: x['table_valid'] for j, x in P.items() if x['reply_used']}
    check('pre-key parse (no key) agrees with full parse', pk_valid == full_valid)
    v_all = res['variants'][0]
    check('planted best ranks first in primary metric (all)', v_all['table'][0]['set'] == planted_best,
          f"first = {v_all['table'][0]['set']}, planted = {planted_best}")
    check('planted best declared winner (P(rank=1) >= 0.5)', v_all['decision'].get('winner') == planted_best,
          fmt(v_all['table'][0]['p_rank1']))
    v3 = next(v for v in res['variants'] if v['name'] == 'own_l3')
    check('planted best first in own_l3 variant', v3['table'][0]['set'] == planted_best)
    sp3 = res['self_preference']['level3']['judges']
    r_sp = next((r for r in sp3 if r['judge'] == sp_judge), None)
    check('self-preference detected for planted judge (level 3)', r_sp is not None and r_sp['flag'],
          f"d = {fmt(r_sp['self_pref_d']) if r_sp else 'n/a'}, p = {fmt(r_sp['p_perm'], 4) if r_sp else 'n/a'}")
    check('planted judge has the largest self-preference', r_sp is not None and
          max(sp3, key=lambda r: r['self_pref_d'] if r['self_pref_d'] is not None else -9)['judge'] == sp_judge)
    fin = all(r['ci_lo'] is not None and r['ci_hi'] is not None and r['ci_lo'] <= r['primary_mean_z'] + 1e-9 <= r['ci_hi'] + 2e-9
              for r in v_all['table'])
    check('bootstrap ran: finite 95% CIs containing the point estimate (all)', fin)
    check('bootstrap B and P(rank=1) sane', v_all['B'] == args.bootstrap and
          0.99 <= sum(r['p_rank1'] for r in v_all['table']) <= 1.5)
    Mz = d.score_ok[:, None] & d.z_ok[:, None] & np.ones((1, d.N), bool)
    e2, _ = bootstrap_primary(d, Mz, 'judge', 'model', args.bootstrap, rng_for(seed, 'boot', 'all', 'model'))
    check('bootstrap reproducible with the same seed', np.allclose(e2, ests['all'], equal_nan=True))
    check('15 model clusters for 19 judges (high/max pooled)', len(set(d.model)) == 15, str(len(set(d.model))))
    v_loc = next(v for v in res['variants'] if v['name'] == 'local')
    v_api = next(v for v in res['variants'] if v['name'] == 'api')
    check('minimum rule: local (3 valid judges) and api (2 families) are descriptive',
          (not v_loc['ranked']) and (not v_api['ranked']))
    pe = res['position_label_effect']
    check('planted primacy effect detected (slope < 0, randomization p < 0.05)',
          pe['slope_z_per_position'] < 0 and pe['slope_p_randomization'] < 0.05,
          f"slope {fmt(pe['slope_z_per_position'], 4)}, p {fmt(pe['slope_p_randomization'], 4)}")
    check('label effect reported as confounded with position (letters in presentation order)',
          pe['label_effect']['confounded_with_position'])
    check('agreement and Kendall W computed', all(p['rho'] is not None for p in res['agreement']['spearman_group_means'][:3])
          and res['agreement']['kendall_w']['all']['W'] is not None)
    check('report and results written', (out / 'full' / 'GODS10_AGG_REPORT.md').exists()
          and (out / 'full' / 'GODS10_AGG_RESULTS.json').exists() and (out / 'prekey' / 'GODS10_PREKEY_PARSE.json').exists())
    ok = all(c[1] for c in checks)
    summary = {'result': 'PASS' if ok else 'FAIL', 'checks': [{'name': n, 'pass': p, 'info': i} for n, p, i in checks],
               'out': str(out), 'seed': seed, 'B': args.bootstrap, 'script_sha256': sha256_file(__file__),
               'own_table_sha256': sha256_file(own_path)}
    write_new(out / 'SELFTEST_RESULT.json', json.dumps(jclean(summary), indent=1))
    print(f"SELFTEST {'PASS' if ok else 'FAIL'} ({sum(c[1] for c in checks)}/{len(checks)} checks) -> {out}")
    return 0 if ok else 1


# ------------------------------------------------------------------------------------------------------------------ cli
def main(argv=None):
    ap = argparse.ArgumentParser(description='GODS10 pre-registered aggregation (' + SPEC_VERSION + ')')
    ap.add_argument('--key', help='sealed key JSON {"mapping": {judge: {letter: set_id}}}')
    ap.add_argument('--replies', help='dir with <judge>.txt (and optional <judge>.retry.txt)')
    ap.add_argument('--own', help='own_set_table.json')
    ap.add_argument('--out', help='output dir (files are create-only)')
    ap.add_argument('--seed', type=int, default=SEED_DEFAULT)
    ap.add_argument('--bootstrap', type=int, default=B_DEFAULT, help='B and R (pre-registered 10000; other = post hoc)')
    ap.add_argument('--prompts', help='optional dir with PROMPT_<judge>.txt to read the presentation order')
    ap.add_argument('--expect-key-sha256', help='full hex or PREFIX...SUFFIX; abort on mismatch')
    ap.add_argument('--parse-only', action='store_true', help='pre-key mode: freeze + parse replies without the key')
    ap.add_argument('--n-sets', type=int, help='number of sets (letters A..) for --parse-only')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args(argv)
    if a.selftest:
        return selftest(a)
    if a.parse_only:
        if not (a.replies and a.n_sets and a.out):
            ap.error('--parse-only needs --replies, --n-sets and --out')
        run_prekey(a.replies, a.n_sets, a.out)
        return 0
    if not (a.key and a.replies and a.own and a.out):
        ap.error('full mode needs --key, --replies, --own and --out')
    run_full(a.key, a.replies, a.own, a.out, seed=a.seed, B=a.bootstrap, R=a.bootstrap, prompts=a.prompts,
             expect_key=a.expect_key_sha256)
    return 0


if __name__ == '__main__':
    sys.exit(main())
