"""Read-only GODS10 input audit; diagnostic only, not the extension aggregator.

Reuses the frozen v1.0 parser with four in-memory token-width adaptations.
Expected anonymous codes come from the actual prompts, never from SEALED.
No canonical author mapping, model calls, winner calculation or retry selection.
"""
from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
import math
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_parser():
    path = ROOT / 'source' / 'gods10_aggregate.py'
    spec = importlib.util.spec_from_file_location('frozen_gods10_parser', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # Only label/token widths change. Section, row, duplicate, ranking, Q-vote,
    # total and consistency policies remain the original parser's policies.
    module.LETTER_RE = re.compile(r'(?<![A-Za-z0-9])([A-Z]{2})(?![A-Za-z0-9])')
    module.LABEL_RE = re.compile(r'^(?:[Ss][Ee][Tt]\s*)?[(\[]?([A-Za-z]{2})[)\]]?[.:)]?$')
    module.HEAD_RE = re.compile(r'^(?:([Ss][Ee][Tt]\s*)?[(\[]?([A-Za-z]{2})[)\]]?)([.:)\-])?(\s*)(.*)$')
    module.SEG_RE = re.compile(
        r'^[\s:|=.)\-(\]\[>]*(?:(?i:set)\s+)?([A-Z]{2})(?![A-Za-z0-9])'
        r'(\s*(?:/|,|&|\+|\bor\b|\band\b)\s*(?:(?i:set)\s+)?[A-Z]{2}(?![A-Za-z0-9]))?')
    return module


def diagnostic_checks(m):
    codes = ['AB', 'CD']
    base = 'TABLE\nAB | 1 | 2 | 3 | 4 | 5 | 15\nCD\t2\t3\t4\t5\t6\t20\n'
    good = m.parse_reply(base + 'RANKING: CD AB\nBEST ANSWER PER QUESTION: ' +
                         ' '.join(f'Q{i}: AB' for i in range(1, 11)), codes)
    assert good['table_valid'] and good['ranking_status'] == 'valid'
    assert good['n_best_valid'] == 10
    assert m.parse_reply(base + 'AB | 1 | 2 | 3 | 4 | 5\n', codes)['table_valid']
    assert not m.parse_reply(base + 'AB | 2 | 2 | 3 | 4 | 5\n', codes)['table_valid']
    assert not m.parse_reply(base.replace('1 | 2', '11 | 2', 1), codes)['table_valid']
    assert m.parse_reply(base + 'RANKING: AB AB\n', codes)['rank_source'] == 'derived_from_totals'
    assert m.LETTER_RE.findall('XAB ABY AB CD') == ['AB', 'CD']
    assert m.parse_reply('', codes)['dropout']
    return {'checks': 8, 'result': 'PASS', 'scope': 'small diagnostic parser adapter cases; no full suite or bootstrap'}


def audit():
    m = load_parser()
    checks = diagnostic_checks(m)
    manifest_path = ROOT / 'source' / 'MANIFEST.json'
    manifest = json.loads(manifest_path.read_text())
    summaries, details, integrity = [], {}, []
    prompt_multisets, reference_bodies = {}, None
    models = {}
    for rec in manifest['records']:
        model, packet = rec['model'], rec['packet']
        suffix = '' if packet == 'FULL' else '_' + packet
        prompt = ROOT / 'prompts' / f'PROMPT_EXT_{"FULL" if packet == "FULL" else "SPLIT"}_web_{model}{suffix}.md'
        reply = ROOT / 'replies' / rec['file']
        prompt_text = prompt.read_text(encoding='utf-8-sig')
        codes = re.findall(r'^Set ([A-Z]{2})\s*$', prompt_text, flags=re.M)
        assert len(codes) == len(set(codes)) == (36 if packet == 'FULL' else 12)
        if packet == 'FULL':
            chunks = re.split(r'^Set ([A-Z]{2})\s*$', prompt_text, flags=re.M)
            bodies = [chunks[i + 1].strip() for i in range(1, len(chunks), 2)]
            fingerprints = sorted(hashlib.sha256(b.encode()).hexdigest() for b in bodies)
            assert len(set(fingerprints)) == 36
            prompt_multisets[model] = fingerprints
            reference_bodies = reference_bodies or bodies
        p = m.parse_reply(reply.read_text(encoding='utf-8-sig'), codes)
        p = m.jclean(p)
        key = model + '/' + packet
        details[key] = {'expected_codes': codes, 'parser': p}
        for path, expected in [(prompt, rec['prompt_sha256']), (reply, rec['sha256'])]:
            integrity.append({'path': str(path.relative_to(ROOT)), 'actual_sha256': sha(path),
                              'expected_sha256': expected, 'match': sha(path) == expected})
        lines = [m.clean(x) for x in reply.read_text(encoding='utf-8-sig').splitlines()]
        section, candidates = 'pre', []
        for line in lines:
            section = m.section_of(line) or section
            row = m.split_row(line)
            if section != 'justification' and row is not None:
                candidates.append(row[0])
        dup = {k: v for k, v in Counter(candidates).items() if v > 1}
        summary = {
            'model': model, 'packet': packet, 'expected': len(codes),
            'candidate_rows': len(candidates), 'distinct_candidate_codes': len(set(candidates)),
            'valid_rows': p['n_valid_rows'], 'table_valid': p['table_valid'],
            'duplicate_codes': dup, 'row_issue_count': len(p['row_issues']),
            'ranking_status': p['ranking_status'], 'rank_source': p['rank_source'],
            'best_questions_valid': p['n_best_valid'], 'total_mismatch_count': len(p['total_notes']),
            'consistency_rho': p['consistency_rho'], 'incoherent': p['incoherent'],
            'mode_recorded': rec.get('mode'), 'instructions_off_recorded': rec.get('instructions_off'),
            'search_off_recorded': rec.get('search_off'), 'reply_bytes': reply.stat().st_size,
        }
        summaries.append(summary)
        models.setdefault(model, {})[packet] = (codes, p)
    assert all(x['match'] for x in integrity), 'A captured file differs from its manifest'
    reference_multiset = next(iter(prompt_multisets.values()))
    assert all(x == reference_multiset for x in prompt_multisets.values()), 'Full judges received different answer texts'
    answer_word_counts = []
    for body in reference_bodies:
        answers = re.findall(r'^\d+\.\s+(.+)$', body, flags=re.M)
        assert len(answers) == 10
        answer_word_counts.extend(len(s.split()) for s in answers)
    cohere = models['Cohere']
    split_sets = [set(cohere[f'P{i}of3'][0]) for i in (1, 2, 3)]
    assert not any(split_sets[i] & split_sets[j] for i in range(3) for j in range(i))
    assert set.union(*split_sets) == set(cohere['FULL'][0])
    full = [s for s in summaries if s['packet'] == 'FULL']
    split_valid = set().union(*(set(cohere[f'P{i}of3'][1]['rows']) for i in (1, 2, 3)))
    result = {
        'schema': 'gods10.prekey.input_quality.v1',
        'scope': 'anonymous-code diagnostic, not a frozen production extension calculation',
        'source_manifest_sha256': sha(manifest_path),
        'source_parser_sha256': sha(ROOT / 'source' / 'gods10_aggregate.py'),
        'source_parser_policy': 'v1.0, two-character token width adapted in memory',
        'diagnostic_checks': checks, 'integrity': integrity,
        'prompt_content_integrity': {'models': len(prompt_multisets), 'same_36_answer_bodies': True},
        'length_diagnostic': {
            'definition': 'whitespace-separated tokens; diagnostic, not a new score or retrospective penalty',
            'answers': len(answer_word_counts), 'over_20_tokens': sum(n > 20 for n in answer_word_counts),
            'max_tokens': max(answer_word_counts), 'min_tokens': min(answer_word_counts),
        },
        'summary': summaries, 'details': details,
        'counts': {
            'models': len(full), 'reply_files': len(summaries),
            'full_valid_tables': sum(s['table_valid'] for s in full),
            'full_valid_explicit_rankings': sum(s['ranking_status'] == 'valid' for s in full),
            'full_valid_best_question_votes': sum(s['best_questions_valid'] for s in full),
            'cohere_split_valid_score_codes': len(split_valid),
            'integrity_pairs_pass': sum(x['match'] for x in integrity),
        },
        'sealed_read': False, 'model_calls': 0,
    }
    out = ROOT / 'PREKEY_INPUT_AUDIT.json'
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    with (ROOT / 'PREKEY_INPUT_AUDIT.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(summaries[0]))
        writer.writeheader()
        writer.writerows(summaries)
    return result


if __name__ == '__main__':
    result = audit()
    print(json.dumps(result['counts'], ensure_ascii=False))
    for row in result['summary']:
        print(json.dumps({k: row[k] for k in ['model', 'packet', 'candidate_rows', 'valid_rows',
              'table_valid', 'ranking_status', 'best_questions_valid', 'duplicate_codes',
              'total_mismatch_count', 'consistency_rho']}, ensure_ascii=False))
