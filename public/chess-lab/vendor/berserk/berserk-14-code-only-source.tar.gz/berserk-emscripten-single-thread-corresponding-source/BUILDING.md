# berserk emscripten-single-thread corresponding source

This archive contains the upstream source snapshot, local browser integration scripts/adapters, docs, and required network/model asset provenance for the generated berserk browser artifacts.

## Rebuild

Install Node dependencies and the documented upstream toolchain, then run:

```sh
npm ci
rm -rf "$PWD/.build/berserk-baseline" "$PWD/.build/berserk-simd" "$PWD/.build/berserk-relaxed"
mkdir -p "$PWD/.build" "$PWD/out/public/berserk"
cp -a "$PWD/upstream/berserk-8ae895a6151695be4a50d4fb65b0c131659c513a" "$PWD/.build/berserk-baseline"
cp -a "$PWD/upstream/berserk-8ae895a6151695be4a50d4fb65b0c131659c513a" "$PWD/.build/berserk-simd"
cp -a "$PWD/upstream/berserk-8ae895a6151695be4a50d4fb65b0c131659c513a" "$PWD/.build/berserk-relaxed"
BERSERK_SKIP_GIT=1 BERSERK_BUILD_DIR="$PWD/.build/berserk-baseline" BERSERK_NET_DIR="$PWD/assets" BERSERK_EMSCRIPTEN_JS_OUT="$PWD/out/public/berserk/berserk-emscripten.js" node scripts/build_berserk_emscripten.mjs
BERSERK_SKIP_GIT=1 BERSERK_BUILD_DIR="$PWD/.build/berserk-simd" BERSERK_NET_DIR="$PWD/assets" BERSERK_WASM_SIMD=1 BERSERK_EMSCRIPTEN_JS_OUT="$PWD/out/public/berserk/berserk-emscripten-simd128.js" node scripts/build_berserk_emscripten.mjs
BERSERK_SKIP_GIT=1 BERSERK_BUILD_DIR="$PWD/.build/berserk-relaxed" BERSERK_NET_DIR="$PWD/assets" BERSERK_WASM_RELAXED_SIMD=1 BERSERK_EMSCRIPTEN_JS_OUT="$PWD/out/public/berserk/berserk-emscripten-relaxed-simd128.js" node scripts/build_berserk_emscripten.mjs
```

The build script applies patches/berserk-emscripten.patch to the upstream snapshot in upstream/berserk-8ae895a6151695be4a50d4fb65b0c131659c513a/.

The build writes outputs under `out/public/berserk/` or the upstream build directory as noted by the command above.

See `ASSET_PROVENANCE.json` for network/model source URLs and hashes.
