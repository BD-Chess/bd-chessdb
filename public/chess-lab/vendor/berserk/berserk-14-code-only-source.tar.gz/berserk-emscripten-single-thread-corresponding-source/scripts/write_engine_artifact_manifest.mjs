import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, relative } from 'node:path';
import { spawnSync } from 'node:child_process';
import { brotliCompressSync, constants as zlibConstants, gzipSync } from 'node:zlib';

const ROOT = process.cwd();

const CONFIGS = {
  berserk: {
    engine: 'berserk',
    flavor: 'emscripten-single-thread',
    status: 'experimental',
    upstream: {
      repo: 'https://github.com/jhonnold/berserk.git',
      tag: '14',
      commit: '8ae895a6151695be4a50d4fb65b0c131659c513a',
      license: 'GPL-3.0',
    },
    build: {
      script: 'scripts/build_berserk_emscripten.mjs',
      command: 'npm run berserk:build-emscripten && npm run berserk:build-simd-emscripten && npm run berserk:build-relaxed-simd-emscripten',
      patches: ['patches/berserk-emscripten.patch'],
    },
    artifacts: [
      'public/berserk/berserk-emscripten.js',
      'public/berserk/berserk-emscripten.wasm',
      'public/berserk/berserk-emscripten.data',
      'public/berserk/berserk-emscripten-simd128.js',
      'public/berserk/berserk-emscripten-simd128.wasm',
      'public/berserk/berserk-emscripten-relaxed-simd128.js',
      'public/berserk/berserk-emscripten-relaxed-simd128.wasm',
    ],
    assets: [
      {
        name: 'berserk-9b84c340af7e.nn',
        sourceUrl: 'https://github.com/jhonnold/berserk-networks/releases/download/networks/berserk-9b84c340af7e.nn',
        rawSha256: '9b84c340af7e45f6e07f0046235ccb327f4ae0840c8ee2c4b97b99121e5c5084',
        licenseNote: 'Covered by Berserk GPL-3.0 under this release policy: the net is named as EVALFILE in the engine Makefile, downloaded and hash-verified by the engine build, and required for the binary to run, so it is treated as part of the Corresponding Source. See docs/engine_artifact_distribution.md.',
        embeddedIn: 'public/berserk/berserk-emscripten.data (one canonical preload package shared by every SIMD tier)',
      },
    ],
  },
  plentychess: {
    engine: 'plentychess',
    flavor: 'emscripten-single-thread',
    status: 'experimental',
    upstream: {
      repo: 'https://github.com/Yoshie2000/PlentyChess.git',
      commit: '58d8ba2505ae2b49f48dd410d214a457d15c12c6',
      version: '7.0.66',
      license: 'GPL-3.0',
    },
    build: {
      script: 'scripts/build_plentychess_emscripten.mjs',
      command: 'npm run plentychess:build-emscripten && npm run plentychess:build-sse41-emscripten && npm run plentychess:build-relaxed-simd-emscripten',
      patches: ['patches/plentychess-emscripten.patch'],
    },
    artifacts: [
      'public/plentychess/plentychess-emscripten.js',
      'public/plentychess/plentychess-emscripten.wasm',
      'public/plentychess/plentychess-emscripten.data',
      'public/plentychess/plentychess-emscripten-sse41.js',
      'public/plentychess/plentychess-emscripten-sse41.wasm',
      'public/plentychess/plentychess-emscripten-relaxed-simd128.js',
      'public/plentychess/plentychess-emscripten-relaxed-simd128.wasm',
    ],
    assets: [
      {
        name: '0134-2r24-s0.bin',
        sourceUrl: 'https://github.com/Yoshie2000/PlentyNetworks/releases/download/0134-2r24-s0/0134-2r24-s0.bin',
        rawSha256: '550a0b664b68113fd228f501524b25e0cea1be500a608bb0f26d42a6255c8061',
        processedPath: '/processed.bin',
        processedSha256: '691efaca9d6b32c85be9256d55d852559f470c3ee67d8d4bdeaf8e113169d4d4',
        processingCommand: 'tools/process_net false',
        licenseNote: 'Yoshie2000/PlentyNetworks is licensed under GPL-3.0; preserve GPL-3.0 notices with the network asset.',
        embeddedIn: 'public/plentychess/plentychess-emscripten.data (one canonical preload package shared by every SIMD tier)',
      },
    ],
  },
  stormphrax: {
    engine: 'stormphrax',
    flavor: 'emscripten-single-thread',
    status: 'experimental',
    upstream: {
      repo: 'https://github.com/Ciekce/Stormphrax.git',
      tag: 'v8.0.0',
      commit: '582965517ed2032d41a6b4cd6c2e66b1b934e2ad',
      version: '8.0.0',
      license: 'GPL-3.0-or-later',
    },
    build: {
      script: 'scripts/build_stormphrax_emscripten.mjs',
      command: 'npm run stormphrax:build-emscripten && npm run stormphrax:build-relaxed-simd-emscripten',
      patches: ['patches/stormphrax-emscripten.patch'],
      toolchain: 'Emscripten 6.0.2, WebAssembly SIMD plus an explicit Relaxed SIMD candidate, synchronous single-thread search, tablebases disabled by leaving SyzygyPath empty.',
    },
    artifacts: [
      'public/stormphrax/stormphrax-emscripten.js',
      'public/stormphrax/stormphrax-emscripten.wasm',
      'public/stormphrax/stormphrax-emscripten.data',
      'public/stormphrax/stormphrax-emscripten-relaxed-simd128.js',
      'public/stormphrax/stormphrax-emscripten-relaxed-simd128.wasm',
    ],
    assets: [
      {
        name: 'undertown.nnue',
        sourceUrl: 'https://github.com/Ciekce/stormphrax-nets/releases/download/undertown/undertown.nnue',
        rawSha256: '04d651e078b7c7334709dbd772d40a23c0a5480e93e19521a03020c7d633f2cf',
        licenseNote: 'Stormphrax documents undertown as its self-trained 8.0.0 release network; distribute it with the GPL corresponding source and provenance manifest.',
        embeddedIn: 'public/stormphrax/stormphrax-emscripten.data (one canonical preload package shared by every SIMD tier)',
      },
    ],
  },
  reckless: {
    engine: 'reckless',
    flavor: 'wasip1-browser',
    status: 'experimental',
    upstream: {
      repo: 'https://github.com/codedeliveryservice/Reckless.git',
      commit: '0010617448bdef4c8cd7d4f4825b7e42c8bc262a',
      license: 'AGPL-3.0',
    },
    build: {
      script: 'scripts/build_reckless_release_assets.mjs',
      command: 'npm run reckless:build-release',
      patches: [],
      toolchain: 'Rust cargo with wasm32-wasip1 target; scalar, SIMD, relaxed-SIMD, explicit non-default external-NNUE WASI prototype, and browser-API builds from the pinned Reckless source.',
    },
    artifacts: [
      'public/reckless/reckless.wasm',
      'public/reckless/reckless-simd128.wasm',
      'public/reckless/reckless-simd128-external.wasm',
      'public/reckless/reckless-relaxed-simd128.wasm',
      'public/reckless/reckless-browser-api.wasm',
      'public/reckless/reckless-browser-api-simd128.wasm',
      'public/reckless/reckless-browser-api-simd128-external.wasm',
      'public/reckless/reckless-v60-7f587dfb.nnue',
      'public/reckless/reckless-scalar-corresponding-source.tar.gz',
      'public/reckless/reckless-simd128-corresponding-source.tar.gz',
      'public/reckless/reckless-simd128-external-corresponding-source.tar.gz',
      'public/reckless/reckless-relaxed-simd128-corresponding-source.tar.gz',
    ],
    assets: [
      {
        name: 'v60-7f587dfb.nnue',
        sourceUrl: 'https://github.com/codedeliveryservice/Reckless.git',
        rawSha256: '7f587dfb1fe5d74d53909328afa6fd51650c8c7f45907602db7fbb1e52948c61',
        licenseNote: 'Reckless embeds and distributes this NNUE with the AGPL-3.0 engine source; preserve corresponding source archives with public WASM distribution.',
        embeddedIn: 'public/reckless/reckless.wasm, public/reckless/reckless-simd128.wasm, public/reckless/reckless-relaxed-simd128.wasm, public/reckless/reckless-browser-api.wasm, public/reckless/reckless-browser-api-simd128.wasm, and public/reckless/reckless-v60-7f587dfb.nnue for the explicit external-NNUE WASI and browser API prototypes',
      },
    ],
  },
  viridithas: {
    engine: 'viridithas',
    flavor: 'wasip1-scalar-simd128',
    status: 'experimental',
    upstream: {
      repo: 'https://github.com/cosmobobak/viridithas.git',
      commit: '20d7402065cae084715183e019fdd18089e2dfac',
      license: 'MIT',
    },
    build: {
      script: 'scripts/build_viridithas_wasi.mjs',
      command: 'npm run viridithas:build-wasi && npm run viridithas:build-simd-wasi && npm run viridithas:build-relaxed-simd-wasi',
      patches: ['patches/viridithas-wasip1.patch'],
      toolchain: 'Rust cargo with wasm32-wasip1 target; scalar build uses +bulk-memory, SIMD build also uses +simd128, and relaxed build adds +relaxed-simd.',
    },
    artifacts: [
      'public/viridithas/viridithas.wasm',
      'public/viridithas/viridithas-simd128.wasm',
      'public/viridithas/viridithas-relaxed-simd128.wasm',
    ],
    assets: [
      {
        name: 'atlantis-b800.nnue.zst',
        sourceUrl: 'https://github.com/cosmobobak/viridithas-networks/releases/download/v106/atlantis-b800.nnue.zst',
        rawSha256: '2d387407b926df4dbda441cdc3e2288fee2e6a2afa8e1bd22262309ec0fb668a',
        licenseNote: 'Viridithas network required by the WASI build; preserve upstream notices with the MIT engine source and network provider provenance.',
        embeddedIn: 'public/viridithas/viridithas.wasm, public/viridithas/viridithas-simd128.wasm, and public/viridithas/viridithas-relaxed-simd128.wasm',
      },
    ],
  },
  stockfish: {
    engine: 'stockfish',
    flavor: 'stockfish-js-18.0.7',
    status: 'release',
    upstream: {
      repo: 'https://github.com/nmrugg/stockfish.js.git',
      commit: '32d4b5ae40c01db88219bfbe2b82dbe6dec93832',
      version: '18.0.7',
      license: 'GPL-3.0',
    },
    build: {
      script: 'upstream build.js; scripts/build_stockfish_relaxed_simd.mjs for relaxed SIMD artifacts',
      command: 'cd upstream/stockfish-js-32d4b5ae40c01db88219bfbe2b82dbe6dec93832 && npm install && node build.js --all -f; npm run stockfish:build-relaxed-simd:lite-single',
      patches: ['scripts/build_stockfish_relaxed_simd.mjs applies the relaxed SIMD source/build edits from the corresponding source tarball; additional full/threaded relaxed variants remain buildable as unpromoted candidates'],
      toolchain: 'Emscripten 3.1.7 as required by Stockfish.js 18 upstream README for upstream artifacts; Emscripten 3.1.40 known-good for the promoted lite-single relaxed SIMD artifact. Lite-threaded/full-threaded relaxed candidates build with 3.1.40 and full-single relaxed builds with 6.0.1/linux-arm64, with 5.0.7 and current 6.x retained in the benchmark matrix before promotion.',
    },
    artifacts: [
      'public/stockfish/stockfish-18-lite-single.js',
      'public/stockfish/stockfish-18-lite-single.wasm',
      'public/stockfish/stockfish-18-lite-single-relaxed.js',
      'public/stockfish/stockfish-18-lite-single-relaxed.wasm',
      'public/stockfish/stockfish-18-lite.js',
      'public/stockfish/stockfish-18-lite.wasm',
      'public/stockfish/stockfish-18-single.js',
      'public/stockfish/stockfish-18-single.wasm',
      'public/stockfish/stockfish-18.js',
      'public/stockfish/stockfish-18.wasm',
    ],
    assets: [],
  },
};

function usage() {
  console.error('Usage: node scripts/write_engine_artifact_manifest.mjs <berserk|plentychess|stormphrax|reckless|viridithas|stockfish> [--out path] [--allow-missing] [--brotli-quality 0-11] [--skip-compression-estimates]');
}

function argValue(name) {
  const i = process.argv.indexOf(name);
  return i >= 0 ? process.argv[i + 1] : undefined;
}

function toolchainSummary(config) {
  const explicit = argValue('--toolchain') ?? process.env.ENGINE_ARTIFACT_TOOLCHAIN;
  if (explicit) return explicit;
  if (config.build.toolchain) return config.build.toolchain;
  const emcc = spawnSync('emcc', ['--version'], { encoding: 'utf8' });
  if (emcc.status === 0) return emcc.stdout.split('\n')[0]?.trim() || 'emcc available';
  return 'emcc not found on PATH while writing manifest; pass --toolchain or ENGINE_ARTIFACT_TOOLCHAIN for release manifests';
}

function compressionSummary(buf, brotliQuality) {
  const gzip = gzipSync(buf, { level: 9 });
  const brotli = brotliCompressSync(buf, { params: { [zlibConstants.BROTLI_PARAM_QUALITY]: brotliQuality } });
  const ratio = (bytes) => Number((bytes / buf.byteLength).toFixed(4));
  return {
    note: `Estimated precompressed transfer sizes using Node zlib gzip level 9 and brotli quality ${brotliQuality}; actual CDN/server settings may differ.`,
    gzip: { bytes: gzip.byteLength, ratio: ratio(gzip.byteLength) },
    brotli: { bytes: brotli.byteLength, ratio: ratio(brotli.byteLength) },
  };
}

function sumArtifactBytes(artifacts, field) {
  return artifacts.reduce((sum, artifact) => {
    if (artifact.missing) return sum;
    if (field === 'bytes') return sum + artifact.bytes;
    if (!artifact.compression?.[field]) return sum;
    return sum + artifact.compression[field].bytes;
  }, 0);
}

async function fileMetadata(path, allowMissing, label = 'artifact') {
  if (!existsSync(path)) {
    if (allowMissing) return { path, missing: true };
    throw new Error(`Missing ${label}: ${path}`);
  }
  const buf = await readFile(path);
  return {
    path,
    bytes: buf.byteLength,
    sha256: createHash('sha256').update(buf).digest('hex'),
  };
}

async function fileEntry(path, allowMissing, brotliQuality, skipCompressionEstimates) {
  const entry = await fileMetadata(path, allowMissing, 'artifact');
  if (entry.missing) return entry;
  if (skipCompressionEstimates) {
    return {
      ...entry,
      compression: {
        skipped: true,
        note: 'Compression estimates skipped for release generation; run the artifact-manifest command without --skip-compression-estimates for research measurements.',
      },
    };
  }
  const buf = await readFile(path);
  return {
    ...entry,
    compression: compressionSummary(buf, brotliQuality),
  };
}

const engine = process.argv[2];
const config = CONFIGS[engine];
if (!config) {
  usage();
  process.exitCode = 1;
} else {
  const allowMissing = process.argv.includes('--allow-missing');
  const skipCompressionEstimates = process.argv.includes('--skip-compression-estimates');
  const brotliQuality = Number(argValue('--brotli-quality') ?? 11);
  if (!Number.isInteger(brotliQuality) || brotliQuality < 0 || brotliQuality > 11) {
    throw new Error('--brotli-quality must be an integer from 0 through 11');
  }
  const out = argValue('--out') ?? `artifacts/engine-manifests/${engine}-${config.flavor}.manifest.json`;
  const sourceArchivePath = argValue('--source-archive');
  const sourceArchiveUrl = argValue('--source-url');
  const missingArtifacts = config.artifacts.filter((path) => !existsSync(path));
  if (missingArtifacts.length && !allowMissing) {
    throw new Error(`Missing artifacts for ${engine} manifest: ${missingArtifacts.join(', ')}`);
  }
  const artifacts = await Promise.all(config.artifacts.map((p) => fileEntry(p, allowMissing, brotliQuality, skipCompressionEstimates)));
  const totalBytes = sumArtifactBytes(artifacts, 'bytes');
  const totalGzipBytes = sumArtifactBytes(artifacts, 'gzip');
  const totalBrotliBytes = sumArtifactBytes(artifacts, 'brotli');
  const manifest = {
    schema: 'lc0-webgpu.browser-engine-artifact-manifest.v1',
    generatedAt: new Date().toISOString(),
    distributionPolicy: 'docs/engine_artifact_distribution.md',
    ...config,
    build: { ...config.build, toolchain: toolchainSummary(config) },
    artifacts,
    totals: {
      bytes: totalBytes,
      gzipBytes: skipCompressionEstimates ? null : totalGzipBytes,
      brotliBytes: skipCompressionEstimates ? null : totalBrotliBytes,
      gzipRatio: !skipCompressionEstimates && totalBytes ? Number((totalGzipBytes / totalBytes).toFixed(4)) : null,
      brotliRatio: !skipCompressionEstimates && totalBytes ? Number((totalBrotliBytes / totalBytes).toFixed(4)) : null,
    },
    sourceArchive: sourceArchivePath
      ? {
          required: true,
          ...(await fileMetadata(sourceArchivePath, false, 'source archive')),
          url: sourceArchiveUrl ?? null,
          note: sourceArchiveUrl ? 'Source archive recorded for public distribution.' : 'Source archive hash recorded; add --source-url before public distribution.',
        }
      : {
          required: true,
          url: null,
          sha256: null,
          note: 'Fill before public distribution; source archive must match this manifest.',
        },
  };
  await mkdir(dirname(out), { recursive: true });
  await writeFile(out, `${JSON.stringify(manifest, null, 2)}\n`);
  console.log(`Wrote ${relative(ROOT, out)}`);
}
