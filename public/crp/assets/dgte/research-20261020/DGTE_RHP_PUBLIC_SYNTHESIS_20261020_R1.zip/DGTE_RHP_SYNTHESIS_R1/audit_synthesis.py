#!/usr/bin/env python3
"""Targeted synthesis audit. Author: GPT, 2026-10-20.

Recomputes selected Claude C1 arithmetic, then extracts SHA-bound GPT R1
reference results. Neither operation validates a machine or an installation.
Usage: python audit_synthesis.py --root PATH --out NEW_JSON
PATH contains gpt/ (the scientific R1 subset) and claude_emp/ (C1 JSON).
Requires CoolProp==8.0.0. No network, external effects or overwriting output.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
from CoolProp.CoolProp import PropsSI as P
import CoolProp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, default=Path(__file__).parent)
    ap.add_argument('--out', type=Path, required=True)
    a = ap.parse_args()
    assert not a.out.exists(), 'Create-only audit output'
    checks = []

    def check(name, passed):
        checks.append({'name': name, 'passed': bool(passed)})
        assert passed, name

    def close(name, x, y, tol=1e-8):
        check(name, math.isclose(x, y, rel_tol=tol, abs_tol=tol))

    def load(p):
        return json.loads(p.read_text())

    def sha(p):
        return hashlib.sha256(p.read_bytes()).hexdigest()

    result_path = a.root/'gpt/results/results.json'
    post_path = a.root/'gpt/results/post_analysis.json'
    check('GPT_R1_numeric_sha', sha(result_path) == '9218abdd09427a284a4859395c5f9908413eab887233f9e6e75280f998319afe')
    check('GPT_R1_post_sha', sha(post_path) == 'e282d1e88d093a2e6dff5ce5fd5e6ef55353f66d54093e539a3c9d5c1b023a57')
    r, post = load(result_path), load(post_path)
    emp = a.root/'claude_emp'
    c2, c3, c4 = [load(emp/n) for n in ('emp2_modes_bounds.json', 'emp3_clapeyron_span.json', 'emp4_lift_band.json')]
    g, rho, head = 9.80665, 990., 5.45
    pcm_eta = 900*g*10*1.6e-4/180e3
    pcm_dT = 333*pcm_eta
    close('C1_PCM_eta_rounded', round(pcm_eta, 7), c3['PCM_paraffin_H10']['eta_ideal'])
    close('C1_PCM_dT_rounded', round(pcm_dT, 4), c3['PCM_paraffin_H10']['span_K'])
    saturation = []
    for f in ('Water', 'R1233zd(E)', 'R245fa', 'Isopentane', 'n-Pentane', 'n-Hexane'):
        ph, pc = [P('P', 'T', t+273.15, 'Q', 1, f) for t in (65, 35)]
        H = (ph-pc)/(985*g)
        close('C1_saturation_height_'+f, round(H, 2), c3['S90-F pinch temps'][f]['H_span_m'])
        saturation.append({'fluid': f, 'Th_C': 65, 'Tc_C': 35, 'carrier_rho_kg_m3': 985,
                           'pure_vapor_pressure_span_height_m': H,
                           'scope': 'Saturation-endpoint pressure equivalent; excludes carrier water vapor, losses, vacuum auxiliaries and a complete cycle.'})

    ph, pc = [P('P', 'T', t+273.15, 'Q', 1, 'R1233zd(E)') for t in (65, 35)]
    pwh, pwc = [P('P', 'T', t+273.15, 'Q', 1, 'Water') for t in (65, 35)]
    mixed_H = (ph+pwh-pc-pwc)/(990*g)

    # C1 E2: original arithmetic is correct for conversion-only stored energy.
    etag, aux, pnet, hours = .85*.93, 5., 26.1, 16.
    e_m3 = rho*g*head/3.6e6
    V_original = pnet*hours/(etag*e_m3)
    V_with_aux = (pnet+aux)*hours/(etag*e_m3)
    V_35 = pnet*hours/(etag*(rho*g*35/3.6e6))
    V_35_aux = (pnet+aux)*hours/(etag*(rho*g*35/3.6e6))
    close('C1_storage_conversion_only', V_original, c2['E2_storage']['reservoir_m3_turbine_head'])
    close('C1_storage_35m_conversion_only', V_35, c2['E2_storage']['reservoir_m3_full_tower_upper_bound'])
    Ph = rho*g*.744*head/1000
    avoided = Ph/.70-aux
    turbine = Ph*etag-aux
    close('C1_pump_hydraulic_power', Ph, c2['E3_pump_mode']['P_hydraulic_kW'])
    close('C1_pump_avoided_electric', avoided, c2['E3_pump_mode']['avoided_pump_electric_kW_if_duty_matches'])
    close('C1_pump_to_turbine_ratio', avoided/turbine, c2['E3_pump_mode']['ratio_value_pump_vs_turbine'])

    A = sum(1.08**(-y) for y in range(1, 16))
    capex_per_kw = (.12*8000*A)/(1+.03*A)
    close('NPV0_cost_per_net_kW', capex_per_kw, r['economics']['NPV0_EUR_per_net_kW'])
    lift_bands = []
    for scen, pg in [('S60-F', 29.6), ('S90-F', 71.3)]:
        for lift in (.2, .3, .36, .45, .55, .65):
            pn = lift*pg*etag-aux
            close('C1_lift_band_'+scen+'_'+str(lift), round(pn, 1), c4[scen]['lf_%.2f'%lift]['net_kW'])
            lift_bands.append({'scenario': scen, 'gas_work_kW_assumed': pg, 'lift_factor': lift, 'net_kW': pn})
    check('C1_own_S60_counterexample_positive', c4['S60-F']['lf_0.36']['net_kW'] > 0)

    # Cost-dependent necessary lift: no universal 0.45 rejection threshold.
    cost_lift = []
    for C in (100000, 170000, 200000, 450000):
        P_required = C/capex_per_kw
        ell = (P_required+aux)/(71.3*etag)
        cost_lift.append({'whole_installed_EUR_assumed': C, 'required_net_kW': P_required,
                          'required_lift_at_C1_S90_gas_budget': ell,
                          'scope': 'Conditional necessary NPV condition, fixed 5 kW auxiliary and C1 gas-work budget. No cost quotation.'})

    rankine = [{'scenario': x['scenario'], 'Th_C': x['Th_C'], 'Tc_C': x['Tc_C'],
                'gross_electric_kW': x['gross_electric_kW'],
                'feed_pump_electric_kW': x['feed_pump_electric_kW'],
                'external_aux_kW_assumed': 5,
                'net_kW': x['net_kW_by_external_aux_kW']['5']}
               for x in r['Rankine'] if x['eta_expander_assumed'] == .7]
    vl2 = [x for x in post['VL2_necessary_carrier_screen'] if x['thermal_budget_screen'] == 'PASSES_NECESSARY_SCREEN_ONLY']
    check('five_of_twelve_VL2_points_pass_necessary_screen_only', len(vl2)==5 and len(post['VL2_necessary_carrier_screen'])==12)
    vp = [x for x in r['body_models']['VP'] if x['fluid']=='R1233zd(E)']
    walls = [x for x in post['VP_cycled_wall_sensitivity'] if x['fluid']=='R1233zd(E)' and x['scenario']=='S90-F']
    selected = {'Rankine_eta_expander_0p7': rankine, 'VL2_necessary_screen_passes_only': vl2,
                'VP_R1233_ideal_cycle': vp, 'VP_S90_wall_sensitivity': walls}
    domains = {
        'Clapeyron': 'Local equilibrium phase boundary: dT/dp=T*delta_v/L. Not a universal work/power bound for gas GC, NiTi/TCP or externally loaded stationary pressure cells.',
        'PCM_original': 'For the stated single small-expansion gravity loop, W/m=rho*g*H*delta_v; dividing by required latent heat alone is an optimistic one-pass heat budget. Small positive work is not mathematical impossibility; it contradicts the original percent-efficiency target under these assumptions.',
        'lift_analog': 'Compare liquid hydraulic power over isothermal gas expansion work at measured absolute endpoints. Meter compressor electricity separately. Match gas/liquid density ratio, geometry, submergence, flow/void regimes; air is not a full phase-change or NCG test.',
        'C1_Falsifier_missing_code': 'C1 package contains a summary of 14/9 kW stacked-loss claims, but no fz.py-fz5.py code or detailed sweep results. Those values are reported sensitivities, not reproduced bounds.',
        'literature_absence': 'Failure to retrieve matching high-efficiency data is not a measured upper bound or automatic rejection.',
    }
    out = {'run_id': 'DGTE-RHP-SYNTHESIS-20261020-R1',
           'verdict': 'PASS_TARGETED_ARITHMETIC_AND_PROVENANCE_NOT_PHYSICAL_VALIDATION',
           'CoolProp': CoolProp.__version__, 'checks': checks,
           'PCM_C1_10m': {'eta_ideal_latent_only': pcm_eta, 'Clapeyron_shift_K': pcm_dT},
           'pure_saturation_pressure_heights': saturation,
           'mixed_R1233_water_R4_65_35_head_m_rho990': mixed_H,
           'storage': {'target_net_kW': pnet, 'hours': hours, 'head_m': head,
                       'C1_conversion_only_m3': V_original, 'including_5kW_discharge_aux_m3': V_with_aux,
                       '35m_conversion_only_m3': V_35, '35m_with_5kW_aux_m3': V_35_aux},
           'pump': {'hydraulic_kW': Ph, 'flow_m3h': .744*3600, 'head_m': head,
                    'avoided_pump_electric_kW_assuming_0p7_efficiency': avoided,
                    'turbine_net_kW': turbine, 'ratio': avoided/turbine,
                    'scope': 'One hydraulic duty, alternatives not additive. Export must preserve both mass/energy and pressure return balance.'},
           'C1_lift_band_recomputed': lift_bands, 'NPV0_EUR_per_net_kW': capex_per_kw,
           'cost_dependent_lift_requirement': cost_lift,
           'selected_GPT_R1': selected, 'domains': domains,
           'input_sha256': {str(p.relative_to(a.root)): sha(p) for p in (result_path, post_path, emp/'emp2_modes_bounds.json', emp/'emp3_clapeyron_span.json', emp/'emp4_lift_band.json')}}
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(json.dumps(out, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({'verdict': out['verdict'], 'checks': len(checks), 'sha256': sha(a.out)}))


if __name__ == '__main__':
    main()
