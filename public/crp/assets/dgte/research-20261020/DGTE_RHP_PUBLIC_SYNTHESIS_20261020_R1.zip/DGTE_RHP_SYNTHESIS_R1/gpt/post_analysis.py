#!/usr/bin/env python3
"""Post-result necessary-domain screens; does not edit the frozen numeric batch."""
from pathlib import Path
import argparse, hashlib, json

def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    root=Path(__file__).resolve().parent
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=root/'results');args=ap.parse_args()
    p=args.out/'results.json';r=json.loads(p.read_text());rules=json.loads((root/'POST_ANALYSIS_RULES.json').read_text())
    carrier=[]
    for row in r['VL2']:
        d={k:row.get(k) for k in ('scenario','H','D','vgj','status','carrier_dT_K')}
        if row['status']=='NO_ROOT_IN_SOURCE_BRACKET':
            d['thermal_budget_screen']='NOT_EVALUABLE_NO_HYDRAULIC_ROOT'
        else:
            margin=rules['carrier_screen']['available_carrier_temperature_drop_K']-row['carrier_dT_K']
            d.update(remaining_carrier_to_gas_temperature_K=margin,
                     thermal_budget_screen='PASSES_NECESSARY_SCREEN_ONLY' if margin>0 else 'EXCEEDS_ASSUMED_CARRIER_THERMAL_BUDGET',
                     net_kW_eta0p85_aux5=row['net_kW_by_eta_turbine_then_aux2_5_10']['0.85'][1])
        carrier.append(d)
    walls=[];a=rules['VP_wall_sensitivity']
    for row in r['body_models']['VP']:
        if row['status']!='CLOSED_IDEAL_REAL_FLUID_PATH':continue
        for mass in a['effective_cycled_wall_kg_per_Lmax']:
            for regen in a['sensible_regeneration_effectiveness_assumed']:
                wall=mass*a['wall_cp_J_kgK_assumed']*(row['Th_C']-row['Tc_C'])*(1-regen)
                eta=row['W_J_per_Lmax']/(row['Qin_J_per_Lmax']+wall)
                pnet=1000*eta*a['mechanical_to_electric_fraction_assumed']-a['auxiliary_kW_assumed']
                walls.append({'scenario':row['scenario'],'fluid':row['fluid'],
                              'wall_kg_per_Lmax_assumed':mass,'sensible_regen_assumed':regen,
                              'wall_heat_J_per_Lmax':wall,'conditional_work_over_heat':eta,
                              'conditional_net_kW_if_full_1MW_input_maintained':pnet,
                              'not_a_rate_or_plant_model':True})
    result={'numeric_batch_sha256':h(p),'post_analysis_rules_sha256':h(root/'POST_ANALYSIS_RULES.json'),
            'post_analysis_code_sha256':h(Path(__file__)),'rules':rules,
            'VL2_necessary_carrier_screen':carrier,'VP_cycled_wall_sensitivity':walls}
    out=args.out/'post_analysis.json'
    if out.exists():raise RuntimeError('Preserve existing post-analysis; select a new output directory.')
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'output':str(out),'sha256':h(out),
                      'VL2_screen_counts':{k:sum(x['thermal_budget_screen']==k for x in carrier) for k in sorted({x['thermal_budget_screen'] for x in carrier})}}))
if __name__=='__main__':main()
