#!/usr/bin/env python3
"""One bounded DGTE RHP comparison; conditional models, never a plant measurement.

Uses unchanged, SHA-bound GPT R2 / Claude R1 / Claude VL2 R4 sources.
New real-fluid VP and Rankine references and inverse engineering gates: GPT.
Run: python models_and_gates.py --out results
CoolProp==8.0.0 is required. Existing output is reused only at matching input/code hashes.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, itertools, json, math, os, platform
from datetime import datetime, timezone
import CoolProp
from CoolProp.CoolProp import PropsSI as P

ROOT = Path(__file__).resolve().parent
PIN = {
    'gpt_design_lab_R2.py': 'a1b32f53c965b1911d9717e46906232b63a27f93bfded12754d47c9b71461b9c',
    'claude_bounded_models_R1.py': '8713f507a36846c7877d90bd3873955fae69cdb3aa230121c5113d8840efe24b',
    'claude_vl2_R4.py': 'cf0a89df57a21594aacea03f8c484023d8c53135f09179363169de17b0d9a5d8',
}
K = 273.15
CHECKS = []

def sha(b): return hashlib.sha256(b).hexdigest()
def check(name, value, detail=None):
    row = {'name': name, 'passed': bool(value)}
    if detail is not None: row['detail'] = detail
    CHECKS.append(row)
    if not value: raise AssertionError(name + ': ' + str(detail))

def module(name):
    path = ROOT / 'sources' / name
    check('source_hash_' + name, sha(path.read_bytes()) == PIN[name])
    spec = importlib.util.spec_from_file_location(name.replace('.', '_'), path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj

def economic(f):
    e = f['economic_scenario']
    r, n, om = e['real_discount'], e['life_y'], e['annual_OM_fraction_total_CAPEX']
    A = sum((1+r)**(-y) for y in range(1, n+1))
    c = e['hours_y']*e['electricity_EUR_kWh']*A/(1+om*A)
    annual = e['hours_y']*e['electricity_EUR_kWh']
    npv = -c + sum((annual-om*c)/(1+r)**y for y in range(1,n+1))
    closed = annual*((1-(1+r)**(-n))/r)/(1+om*((1-(1+r)**(-n))/r))
    check('NPV_zero_direct_annual_cashflow', abs(npv) < 1e-7, npv)
    check('annuity_closed_vs_sum', abs(c-closed) < 1e-8)
    c5 = 5*annual/(1+5*om)
    return {'assumptions': e, 'annuity': A, 'NPV0_EUR_per_net_kW': c,
            'five_year_simple_EUR_per_net_kW': c5,
            '25kW_total_CAPEX_ceiling_EUR': 25*c,
            'illustrative_HX_area_m2_from_prior_S90_case': 164+272,
            'maximum_HX_EUR_m2_if_ALL_25kW_budget_spent_on_HX': 25*c/(164+272),
            'not_a_quote': True}

def pcm_gates(f, materials, econ, design):
    a = f['PCM_legacy_nominal_only']; dv = a['volume_expansion_fraction']/a['density_kg_m3']
    rows=[]
    for bar in a['pressure_swing_bar']:
        dp=bar*1e5; work=a['mass_kg']*dv*dp
        eta=dp*dv/a['heat_window_J_kg']
        shift=a['transition_K_illustration']*dv*dp/a['latent_J_kg_illustration']
        rows.append({'dp_bar':bar,'rectangle_J_for_100g':work,
                     'conditional_work_over_nominal_heat_window':eta,
                     'Clapeyron_linear_shift_K_ILLUSTRATIVE':shift,
                     'shaft_W_per_1MW_if_entire_nominal_stroke_retained':1e6*eta,
                     'active_PCM_kg_per_shaft_kW_at_40s_if_stroke_retained':1000*40/(dv*dp),
                     'status':'KINEMATIC_INVERSE_GATE_NOT_CLOSED_PCM_EOS'})
    g=design.G; dpcol=850*g*3
    needed_eta=(25000+5000)/0.75/1e6
    required_dp=needed_eta*a['heat_window_J_kg']/dv
    vc=math.pi*.02**2*.12
    cap=[]
    for fill in (0.5,0.8,1.0):
        expansion=.11*fill
        cap.append({'PCM_fill_fraction':fill,'external_expansion_PCM_only':expansion,
                    'ideal_W_for_40_capsules_at_0p4m_s':40*850*g*.4*vc*expansion/2})
    material_rows=[]
    for name in ('RT64HC','RT42'):
        m=materials[name]
        rho=m.get('density_solid_kg_m3_at_20C_approx',m.get('density_solid_kg_m3_at_15C'))
        q=m.get('heat_storage_J_kg_57_to_72C',m.get('heat_storage_J_kg_35_to_50C'))
        d=m['volume_expansion_fraction']/rho
        material_rows.append({'material':name,'nominal_dv_m3_kg':d,'nominal_heat_window_J_kg':q,
                             '3m_oil_ideal_work_over_stated_heat_window':dpcol*d/q,
                             '50bar_rectangle_over_stated_heat_window':50e5*d/q,
                             'melting_C':m['melting_C'],'congealing_C':m['congealing_C'],
                             'S60_44C_can_exceed_full_melting_range_at_low_pressure':44>max(m['melting_C']),
                             'S60_36C_can_cool_below_full_congealing_range_at_low_pressure':36<min(m['congealing_C']),
                             'thermal_window_and_pressure_EOS_still_open':True})
    check('passive_fixed_displacement_closed_equal_density', design.buoyancy(3,.001,0,850,850)['W_ideal_J']==0)
    check('buoyancy_zero_height', design.buoyancy(0,.001,.11,850,850)['W_ideal_J']==0)
    check('pressure_zero_swing', design.pressure_budget(.1,0)['work_rectangle_J']==0)
    return {'nominal_pressure_rectangles':rows,'capsule_fill_sensitivity':cap,
            '3m_oil_ideal_heat_efficiency_nominal_PCM':dpcol*dv/a['heat_window_J_kg'],
            '25kW_net_target_given_5kW_aux_0p75_conversion':{
                'required_shaft_W':40000,'required_work_over_heat':needed_eta,
                'required_dp_bar_if_legacy_stroke_retained':required_dp/1e5,
                'illustrative_linear_Clapeyron_shift_K':a['transition_K_illustration']*dv*required_dp/a['latent_J_kg_illustration']},
            'new_material_source_gates':material_rows,
            'thermal_slab_scaling':[design.thermal_slab(d) for d in (.00025,.001,.002,.005)],
            'interpretation':'Rectangles and source nominal heat windows are not a measured reset, loaded stroke, cycle heat or power.'}

def vp_cycle(fl, th, tc):
    """Closed-body VP reference: hot isobar, isochoric cooling, cold isobar,
    isothermal compressed-liquid return. No casing, valves or speed model.
    This is NOT the open Rankine reference and work is not additive with it.
    """
    ph=P('P','T',th,'Q',1,fl); pc=P('P','T',tc,'Q',0,fl)
    v1=1/P('D','T',tc,'P',ph,fl); u1=P('U','T',tc,'P',ph,fl)
    h1=P('H','T',tc,'P',ph,fl); s1=P('S','T',tc,'P',ph,fl)
    v2=1/P('D','T',th,'Q',1,fl); u2=P('U','T',th,'Q',1,fl)
    h2=P('H','T',th,'Q',1,fl)
    vl=1/P('D','T',tc,'Q',0,fl); vg=1/P('D','T',tc,'Q',1,fl)
    x=(v2-vl)/(vg-vl)
    if not 0<=x<=1: return {'status':'INFEASIBLE_FOR_SPECIFIED_VP_PATH','quality':x}
    u3=(1-x)*P('U','T',tc,'Q',0,fl)+x*P('U','T',tc,'Q',1,fl)
    h3=(1-x)*P('H','T',tc,'Q',0,fl)+x*P('H','T',tc,'Q',1,fl)
    u4=P('U','T',tc,'Q',0,fl); h4=P('H','T',tc,'Q',0,fl); s4=P('S','T',tc,'Q',0,fl)
    q12=h2-h1; q23=u3-u2; q34=h4-h3; q41=tc*(s1-s4)
    w12=ph*(v2-v1); w34=pc*(vl-v2); w41=q41-(u1-u4)
    w=w12+w34+w41; qin=sum(max(q,0) for q in (q12,q23,q34,q41))
    qout=-sum(min(q,0) for q in (q12,q23,q34,q41))
    mass_per_Lmax=.001/v2
    return {'status':'CLOSED_IDEAL_REAL_FLUID_PATH','p_hot_Pa':ph,'p_cold_Pa':pc,
            'quality_after_isochoric_cooling':x,'W_J_kg':w,'Qin_J_kg':qin,'Qout_J_kg':qout,
            'W_J_per_Lmax':w*mass_per_Lmax,'Qin_J_per_Lmax':qin*mass_per_Lmax,
            'W_return_compression_J_kg':w41,'eta_ideal':w/qin,
            'energy_residual_J_kg':qin-qout-w,'Sgen_J_kgK':qout/tc-qin/th,
            'carnot':1-tc/th}

def body_models(f, cm):
    mv=[]; vs=[]; vp=[]
    eps=f['matching_saturation_epsilon_K'];rho=f['MV_and_matched_VS_carrier_rho_kg_m3']
    for scen,(thc,tcc) in f['effective_body_cases_C'].items():
        th,tc=thc+K,tcc+K
        for fl in f['vapor_fluids_for_closed_body_cases']:
            v=vp_cycle(fl,th,tc);v.update(scenario=scen,fluid=fl,Th_C=thc,Tc_C=tcc)
            vp.append(v)
            if v['status'].startswith('CLOSED'):
                check('VP_energy_'+scen+fl,abs(v['energy_residual_J_kg'])/v['Qin_J_kg']<1e-7)
                check('VP_entropy_Carnot_'+scen+fl,v['Sgen_J_kgK']>=-1e-6 and 0<=v['eta_ideal']<=v['carnot']+1e-7)
            for H in f['MV_and_matched_VS_heights_m']:
                tag=scen+fl+str(H)
                for asc,target,kind in [('isothermal',mv,'MV'),('isentropic',vs,'VS_MATCHED_THERMO_ONLY')]:
                    c=cm.matched(fl,thc,tcc,rho,H,dh=eps,dc=eps,ascent=asc)
                    if c is None:
                        target.append({'scenario':scen,'fluid':fl,'H_m':H,'kind':kind,'status':'OUTSIDE_CHOSEN_PHASE_PRESSURE_WINDOW'})
                        continue
                    row={'scenario':scen,'fluid':fl,'H_m':H,'kind':kind,'status':'IDEAL_BODY_MODEL','Th_C':thc,'Tc_C':tcc,**c}
                    row['per_hot_active_m3_at_assumed_period']={}
                    for t in f['assumed_cycle_periods_s_for_density_illustration']:
                        shaft=f['MV_hot_inventory_fraction_for_density_illustration']*1000*c['W_J_per_L_maxbag']/t
                        row['per_hot_active_m3_at_assumed_period'][str(t)]={'shaft_W_m3':shaft,
                            'electric_W_m3_before_all_drag_aux':shaft*f['assumed_shaft_to_electric_fraction_for_body_density_illustration']}
                    target.append(row)
                    check(kind+'_energy_'+tag,abs(c['closure_J_per_kg'])/c['Qin_J_per_kg']<1e-3,c['closure_J_per_kg'])
                    check(kind+'_entropy_Carnot_'+tag,c['Sgen_J_per_kgK']>=-1e-3 and 0<=c['eta']<=c['eta_carnot']+1e-5)
    legacy=cm.matched('Water',90,25,850,3)
    check('MV_legacy_control_W_per_L',abs(legacy['W_J_per_L_bottom']-56.6)<1)
    return {'MV':mv,'VS_matched':vs,'VP':vp,'legacy_MV_control':legacy,
            'warning':'Common finite-stream body temperatures are imposed references, not globally optimized architectures. Inventory and period are assumptions; the computed density is not whole-plant net power.'}

def gas_models(f, design):
    rows=[]
    for scen,(thc,tcc) in f['effective_body_cases_C'].items():
        for H,pt,eps in itertools.product(f['GC_heights_m'],f['GC_top_pressure_Pa'],f['GC_regenerator_effectiveness']):
            c=design.ericsson(H,th=thc+K,tc=tcc+K,rho=850,pt=pt)
            pb=c['p_bottom_Pa'];nr=pb*.001/(thc+K)
            Qin=nr*(thc+K)*math.log(pb/pt)+(1-eps)*3.5*nr*(thc-tcc)
            Qout=Qin-c['W_ideal_J']; eta=c['W_ideal_J']/Qin
            def force(z):return 850*design.G*nr*((thc+K)/(pt+850*design.G*(H-z))-(tcc+K)/(pt+850*design.G*z))
            # Each individual force is increasing between a docking/reset.
            # For evenly staggered identical pairs, minima occur just after a reset.
            trains={str(M):sum(force(j*H/M) for j in range(M)) for M in (1,2,4,8,16,32,64)}
            row={'scenario':scen,'H_m':H,'p_top_Pa':pt,'regenerator_epsilon_assumed':eps,
                 'W_ideal_J_per_Lhotbottom':c['W_ideal_J'],'Qhot_J':Qin,'Qcold_J':Qout,
                 'eta_ideal':eta,'carnot':c['carnot'],
                 'W_J_per_L_hot_MAX':c['W_ideal_J']/(pb/pt),
                 'single_pair_start_force_N':c['opposed_pair_start_force_N'],
                 'single_pair_minimum_buffer_J':c['minimum_reversible_buffer_J'],
                 'ideal_staggered_train_min_force_N_by_pair_count':trains,
                 'status':'IDEAL_GAS_MODEL_NO_RATE_DOCKING_FRICTION_GENERATOR_AUX_VALIDATION'}
            check('GC_force_integral_'+scen+str(H)+str(pt)+str(eps),abs(c['independent_force_integral_J']-c['W_ideal_J'])<1e-4)
            check('GC_entropy_'+scen+str(H)+str(pt)+str(eps),Qout/(tcc+K)-Qin/(thc+K)>=-1e-9)
            check('GC_Carnot_'+scen+str(H)+str(pt)+str(eps),0<=eta<=c['carnot']+1e-12)
            rows.append(row)
    check('GC_zero_temperature_difference',abs(design.ericsson(3,th=310,tc=310)['W_ideal_J'])<1e-12)
    return rows

def rankine_models(f):
    rows=[]; fl=f['Rankine_fluid']; ep=f['Rankine_pump_isentropic_efficiency']
    em=f['Rankine_pump_motor_efficiency'];eg=f['Rankine_and_VL2_generator_efficiency']
    for scen,(thc,tcc) in f['effective_body_cases_C'].items():
        th,tc=thc+K,tcc+K
        ph=P('P','T',th,'Q',1,fl);pc=P('P','T',tc,'Q',0,fl)
        h1=P('H','T',tc,'Q',0,fl);s1=P('S','T',tc,'Q',0,fl)
        h2s=P('H','P',ph,'S',s1,fl);wp=(h2s-h1)/ep;h2=h1+wp
        h3=P('H','T',th,'Q',1,fl);s3=P('S','T',th,'Q',1,fl)
        h4s=P('H','P',pc,'S',s3,fl)
        qin=h3-h2;m=f['source_heat_W']/qin
        for et in f['Rankine_expander_isentropic_efficiency_sensitivity']:
            we=et*(h3-h4s);h4=h3-we;qc=h4-h1
            gross=m*we*eg;feed=m*wp/em;net={str(aux):gross/1000-feed/1000-aux for aux in f['external_auxiliary_kW_sensitivity']}
            row={'scenario':scen,'fluid':fl,'Th_C':thc,'Tc_C':tcc,'p_hot_Pa':ph,'p_cold_Pa':pc,
                 'eta_expander_assumed':et,'m_WF_kg_s':m,'Qin_J_kg':qin,'Qout_J_kg':qc,
                 'expander_W':m*we,'feed_fluid_pump_W':m*wp,
                 'gross_electric_kW':gross/1000,'feed_pump_electric_kW':feed/1000,
                 'net_kW_by_external_aux_kW':net,'shaft_net_eta':(we-wp)/qin,
                 'energy_residual_J_kg':qin-qc-(we-wp),
                 'reservoir_Sgen_J_kgK':qc/tc-qin/th,'carnot':1-tc/th,
                 'status':'PURE_FLUID_RANKINE_REFERENCE_NOT_SUPPLIER_QUOTE_OR_OPTIMIZED_ORC'}
            check('Rankine_energy_'+scen+str(et),abs(row['energy_residual_J_kg'])<1e-6)
            check('Rankine_entropy_Carnot_'+scen+str(et),row['reservoir_Sgen_J_kgK']>=-1e-6 and 0<=row['shaft_net_eta']<=row['carnot']+1e-8)
            rows.append(row)
    return rows

def vl2_models(f, vl):
    rows=[]
    for scen,(thc,tcc) in f['effective_body_cases_C'].items():
        Te,Tc=thc+K,tcc+K;cy=vl.cycle(Te,Tc)
        check('VL2_reduced_cycle_energy_'+scen,abs(cy['energy_closure_rel'])<1e-4)
        for (H,D),(C0,vgj) in itertools.product(f['VL2_geometries_not_reoptimized'][scen],f['VL2_drift_cases_C0_vgj']):
            pt=vl.solve(cy,Te,Tc,H,D,C0,vgj,accel=True)
            if pt is None:
                rows.append({'scenario':scen,'H':H,'D':D,'vgj':vgj,'status':'NO_ROOT_IN_SOURCE_BRACKET'})
            else:
                r=[a for a in pt['rows'] if a['K_loop']==f['VL2_K_loop']][0]
                rows.append({'scenario':scen,'Th_C':thc,'Tc_C':tcc,'status':'CLAUDE_R4_SOURCE_WITH_NEW_CONTACT_TEMPERATURES',
                             'H':H,'D':D,'C0':C0,'vgj':vgj,'Q_l_m3_s':pt['Q_l'],'m_WF_kg_s':pt['m_WF'],
                             'm_water_vapor_kg_s':pt['m_WF']*cy['mw'],
                             'hydrostatic_floor_m':(cy['pb']+cy['pw_e']-cy['p_top'])/(vl.RHO_L*vl.g),
                             'useful_head_m':r['head_m'],'hydraulic_kW':r['P_hydr_kW'],
                             'net_kW_by_eta_turbine_then_aux2_5_10':r['P_net_kW'],
                             'carrier_dT_K':pt['carrier_dT_K'],'carrier_evap_frac':pt['carrier_evap_frac'],
                             'condensate_return_min_height_m':pt['condensate_leg_m'],'condensate_return_ideal_ok':pt['condensate_leg_ok'],
                             'alpha_bottom':pt['alpha_bot'],'alpha_top':pt['alpha_top'],
                             'acceleration_pressure_kPa':pt['dp_acc_kPa'],
                             'hot_riser_volume_m3':math.pi*D*D*H/4,
                             'two_equal_vertical_pipes_volume_m3':2*math.pi*D*D*H/4,
                             'cycle_eta_ideal':cy['eta_ideal'],'cycle_energy_residual_rel':cy['energy_closure_rel'],
                             'open':'Uncalibrated drift, wall friction, contact, separator, NCG, full carrier/condensate closure, dynamics and all actual auxiliaries.'})
    return rows

def load_audits(design):
    # Source-discovery-triggered post-hoc algebra audit, not a preregistered discovery.
    tau_s,B=2.,3.
    points=[(i/100000*(tau_s/B)) for i in range(100001)]
    max_grid=max((tau_s-B*w)*w for w in points)
    analytic=tau_s*tau_s/(4*B)
    check('linear_torque_load_optimum_grid_vs_analytic',abs(max_grid-analytic)<1e-10)
    F,k=1.,1.;v=math.sqrt(F/(3*k));b=(F-k*v*v)/v
    m=design.loaded_motion(F,k,b)
    check('loaded_motion_energy_balance',abs(m['input_W']-m['drag_W']-m['generator_mechanical_W'])<1e-10)
    check('unloaded_motion_extracts_zero_generator_work',design.loaded_motion(1,1,0)['generator_mechanical_W']==0)
    return {'linear_torque_law': 'tau_load=tau_stall-B*omega',
            'correct_maximum': 'tau_stall**2/(4*B)', 'analytic_example_W':analytic,'grid_example_W':max_grid,
            'quadratic_drag_example':m,'W_eng_max_per_cycle_is_not_stall_torque_times_no_load_speed':True,
            'published_source_issue':'Primary PDF Eq.(6) renders denominator 2B while Eqs.(3)-(5) imply 4B; this audit does not invalidate or rescale measured TCP power.'}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,default=ROOT/'results');args=ap.parse_args()
    f=json.loads((ROOT/'FIXTURE.json').read_text());mats=json.loads((ROOT/'FIXTURE_ADDENDUM_RT42.json').read_text())
    identity={'code_sha256':sha(Path(__file__).read_bytes()),'fixture_sha256':sha((ROOT/'FIXTURE.json').read_bytes()),
              'material_addendum_sha256':sha((ROOT/'FIXTURE_ADDENDUM_RT42.json').read_bytes()),'source_sha256':PIN}
    target=args.out/'results.json'
    if target.exists():
        prior=json.loads(target.read_text())
        if prior['identity']!=identity:raise RuntimeError('Existing result belongs to other bytes; use a new output directory.')
        print('VERIFIED_IDENTITY_REUSE; no recalculation');return
    design=module('gpt_design_lab_R2.py');cm=module('claude_bounded_models_R1.py');vl=module('claude_vl2_R4.py')
    result={'run_id':f['run_id'],'identity':identity,'generated_utc':datetime.now(timezone.utc).isoformat(),
            'environment':{'python':platform.python_version(),'CoolProp':CoolProp.__version__,
                           'EOS_revision':CoolProp.__gitrevision__},
            'evidence':'CONDITIONAL_NUMERICAL_MODELS_AND_INVERSE_GATES_NOT_HARDWARE', 'fixture':f}
    result['economics']=economic(f)
    result['PCM_and_original_gates']=pcm_gates(f,mats,result['economics'],design);print('PCM / economics done',flush=True)
    result['body_models']=body_models(f,cm);print('MV / VS / VP done',flush=True)
    result['GC']=gas_models(f,design)
    result['Rankine']=rankine_models(f);print('GC / Rankine done',flush=True)
    result['VL2']=vl2_models(f,vl);print('VL2 selected new-temperature cases done',flush=True)
    result['load_audits']=load_audits(design)
    result['checks']=CHECKS
    result['not_run']=f['not_executed']
    args.out.mkdir(parents=True,exist_ok=True)
    body=(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    tmp=target.with_suffix('.tmp');tmp.write_bytes(body);os.replace(tmp,target)
    print(json.dumps({'status':'NUMERIC_BATCH_COMPLETE','checks_passed':len(CHECKS),'output':str(target),
                      'bytes':len(body),'sha256':sha(body)}),flush=True)

if __name__=='__main__':main()
