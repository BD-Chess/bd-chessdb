#!/usr/bin/env python3
"""DGTE Claude open review R1 - bounded models (2026-10-19).

Idealized models only. Real-fluid properties from CoolProp (HEOS).
No hardware result. Every cycle is checked by energy closure and S_gen >= 0.

Sections
 A  column-lever law: eta <= dp_column * dv / q   (all buoyancy variants)
 B  original PCM capsule: ceiling, throughput, melt time, NTU claim
 C  matched-vapor two-column cycle (DGTE-MV), isothermal / adiabatic ascent
 D  cross-check: GPT VS architecture (atm top, isentropic rise) with real pentane
 E  gas Ericsson with/without regeneration (where BD's recuperator belongs)
"""
import math, json, sys
from CoolProp.CoolProp import PropsSI as P

g = 9.81
OUT = {}

def K(c): return c + 273.15

# ---------------------------------------------------------------- A / B
def section_B():
    r = {}
    rho_oil, H = 850.0, 3.0
    dp = rho_oil * g * H                       # Pa, hydrostatic swing
    # Paraffin, RT64HC nominal: 11 % volume expansion, 250 kJ/kg (incl. sensible 57-72 C)
    rho_s = 880.0; dv = 0.11 / rho_s           # m3/kg external, ideal bladder
    for q_name, q in (("latent_only_200kJ", 200e3), ("rt64hc_nominal_250kJ", 250e3)):
        r["eta_ceiling_" + q_name] = dp * dv / q
    Tm = K(64.0)
    r["clapeyron_dTm_dp_K_per_bar"] = Tm * dv / 200e3 * 1e5
    r["melt_shift_over_column_mK"] = Tm * dv / 200e3 * dp * 1e3
    r["dp_column_kPa"] = dp / 1e3
    # Original claim: P_net = 2.4 kW module. External dV throughput needed (ideal, mech):
    P_claim = 2400.0
    r["needed_dV_rate_L_per_s_for_2p4kW"] = P_claim / dp * 1e3
    r["needed_PCM_melt_rate_kg_per_s"] = P_claim / dp / dv
    r["heat_needed_MW_at_ceiling"] = P_claim / (dp * dv / 250e3) / 1e6
    # GPT 1.257 W scenario reproduced
    V = math.pi * 0.02**2 * 0.12; dV = 0.125 * V
    r["gpt_1p257W_check"] = 40 * rho_oil * g * 0.4 * dV / 2
    # PCM fraction needed for 12.5 % external expansion at 11 % PCM expansion
    r["pcm_volume_fraction_needed_for_12p5pct"] = 0.125 / 0.11
    # melt time, cylinder R=20 mm, quasi-steady inward melt (low Stefan): t = rho L R^2 /(4 k dT)
    for k in (0.2, 2.0):
        t = 780 * 200e3 * 0.02**2 / (4 * k * (110 - 64))
        r[f"melt_time_s_k{k}"] = t
    r["stroke_time_s_3m_0p4"] = 3.0 / 0.4
    r["rule_t_inv_max_s"] = 0.1 * 3.0 / 0.4
    # NTU claim: NTU>=2.3, 0.6<=Cr<=1 => eps 0.90-0.95 ?
    def eps(NTU, Cr):
        if abs(Cr - 1) < 1e-12: return NTU / (1 + NTU)
        e = math.exp(-NTU * (1 - Cr)); return (1 - e) / (1 - Cr * e)
    r["eps_NTU2p3_Cr0p6"] = eps(2.3, 0.6); r["eps_NTU2p3_Cr1"] = eps(2.3, 1.0)
    r["eps_NTU2p3_Cr0"] = 1 - math.exp(-2.3)
    r["NTU_for_eps0p9_Cr1"] = 9.0
    # P/L (GPT): 100 g, 11 %, 900 kg/m3, 50 bar
    W_pl = 0.1 / 900 * 0.11 * 50e5
    r["PL_W_J"] = W_pl; r["PL_eta_vs_250kJkg"] = W_pl / (0.1 * 250e3)
    r["PL_dp_bar_for_eta_5pct"] = 0.05 * 250e3 / dv / 1e5
    return r

# ---------------------------------------------------------------- C / D
def isoT_path(fl, T, p1, p2, n=400):
    """quasi-static isothermal path p1->p2 (single phase); returns W=int p dv, Q=T ds (per kg)."""
    W = 0.0; Q = 0.0
    ps = [p1 + (p2 - p1) * i / n for i in range(n + 1)]
    v = [1 / P('D', 'T', T, 'P', p, fl) for p in ps]
    s = [P('S', 'T', T, 'P', p, fl) for p in ps]
    for i in range(n):
        W += 0.5 * (ps[i] + ps[i + 1]) * (v[i + 1] - v[i])
        Q += T * (s[i + 1] - s[i])
    return W, Q, v[-1]

def isobar_W(fl, p, T1, T2):
    v1 = 1 / P('D', 'T', T1, 'P', p, fl); v2 = 1 / P('D', 'T', T2, 'P', p, fl)
    h1 = P('H', 'T', T1, 'P', p, fl); h2 = P('H', 'T', T2, 'P', p, fl)
    return p * (v2 - v1), h2 - h1, v1, v2

def cycle(fl, Th, Tc, p_t, p_b, ascent="isothermal", descent="isothermal"):
    """Body (closed, compliant) cycle in two columns.
    1 liquid @Tc,p_b  -1->2 isobaric heat to Th at p_b (boil, superheat)
    2->3 ascent p_b->p_t : isothermal at Th (hot column) or isentropic
    3->4 isobaric @p_t cool to Tc (condense)
    4->1 descent p_t->p_b : isothermal at Tc (cold column, liquid) or isentropic
    Reservoir bookkeeping: all heat in at Th, all heat out at Tc."""
    W12, Q12, v1, v2 = isobar_W(fl, p_b, Tc, Th)
    if ascent == "isothermal":
        W23, Q23, v3 = isoT_path(fl, Th, p_b, p_t)
        T3 = Th
    else:
        s2 = P('S', 'T', Th, 'P', p_b, fl)
        h3 = P('H', 'P', p_t, 'S', s2, fl); h2 = P('H', 'T', Th, 'P', p_b, fl)
        T3 = P('T', 'P', p_t, 'S', s2, fl)
        # adiabatic: W = -(u3-u2)
        u2 = P('U', 'T', Th, 'P', p_b, fl); u3 = P('U', 'P', p_t, 'S', s2, fl)
        W23 = -(u3 - u2); Q23 = 0.0; v3 = 1 / P('D', 'P', p_t, 'S', s2, fl)
    h3 = P('H', 'T', T3, 'P', p_t, fl) if ascent == "isothermal" else P('H', 'P', p_t, 'S', P('S', 'T', Th, 'P', p_b, fl), fl)
    h4 = P('H', 'T', Tc, 'P', p_t, fl); v4 = 1 / P('D', 'T', Tc, 'P', p_t, fl)
    W34 = p_t * (v4 - v3); Q34 = h4 - h3                      # negative
    if descent == "isothermal":
        W41, Q41, _ = isoT_path(fl, Tc, p_t, p_b)
    else:
        # isentropic liquid compression 4->1, then isobaric heat from state 1 (not Tc) at p_b
        s4 = P('S', 'T', Tc, 'P', p_t, fl)
        u4 = P('U', 'T', Tc, 'P', p_t, fl); u1 = P('U', 'P', p_b, 'S', s4, fl)
        W41, Q41 = -(u1 - u4), 0.0
        h1 = P('H', 'P', p_b, 'S', s4, fl); v1 = 1 / P('D', 'P', p_b, 'S', s4, fl)
        h2 = P('H', 'T', Th, 'P', p_b, fl)
        Q12 = h2 - h1; W12 = p_b * (v2 - v1)
    W = W12 + W23 + W34 + W41
    Qin = Q12 + max(Q23, 0) + max(Q41, 0)
    Qout = -Q34 - min(Q23, 0) - min(Q41, 0)
    closure = (Q12 + Q23 + Q34 + Q41) - W
    Sgen = Qout / Tc - Qin / Th
    return dict(W_J_per_kg=W, Qin_J_per_kg=Qin, Qout_J_per_kg=Qout, eta=W / Qin,
                eta_carnot=1 - Tc / Th, frac_carnot=(W / Qin) / (1 - Tc / Th),
                closure_J_per_kg=closure, Sgen_J_per_kgK=Sgen,
                v2=v2, v3=v3, v4=v4, T3=T3, vol_ratio_top_over_bottom=v3 / v2)

def matched(fl, Th_c, Tc_c, rho, H, dh=5.0, dc=5.0, ascent="isothermal"):
    """Choose p_t minimal s.t. Tsat(p_t) >= Tc+dc and Tsat(p_t+rho g H) <= Th-dh."""
    Th, Tc = K(Th_c), K(Tc_c); dp = rho * g * H
    pt_min = P('P', 'T', Tc + dc, 'Q', 0, fl)
    pb_max = P('P', 'T', Th - dh, 'Q', 0, fl)
    if pb_max - dp < pt_min:      # column too tall for window -> infeasible with these margins
        return None
    p_t = pt_min
    if P('T', 'P', p_t + dp, 'Q', 0, fl) > Th - dh:
        p_t = pb_max - dp
    p_b = p_t + dp
    c = cycle(fl, Th, Tc, p_t, p_b, ascent=ascent)
    c.update(fluid=fl, p_t_kPa=p_t / 1e3, p_b_kPa=p_b / 1e3,
             Tsat_t_C=P('T', 'P', p_t, 'Q', 0, fl) - 273.15,
             Tsat_b_C=P('T', 'P', p_b, 'Q', 0, fl) - 273.15)
    # per 1 L of vapour at bottom (state 2) and per 1 L of max bag volume (state 3)
    m = 1e-3 / c["v2"]
    c["fluid_mass_g_per_L_bottom"] = m * 1e3
    c["W_J_per_L_bottom"] = c["W_J_per_kg"] * m
    c["Qin_J_per_L_bottom"] = c["Qin_J_per_kg"] * m
    c["W_J_per_L_maxbag"] = c["W_J_per_kg"] / c["v3"] * 1e-3
    return c

def section_C():
    res = {}
    fluids = ["Water", "Ethanol", "Methanol", "Acetone", "n-Pentane", "Cyclopentane", "R245fa"]
    cases = {"oil3m_110_25": (110, 25, 850, 3.0), "oil3m_90_25": (90, 25, 850, 3.0),
             "oil3m_60_25": (60, 25, 850, 3.0), "water4m_60_25": (60, 25, 1000, 4.0)}
    for cname, (Th, Tc, rho, H) in cases.items():
        res[cname] = {}
        for fl in fluids:
            for asc in ("isothermal", "isentropic"):
                try:
                    c = matched(fl, Th, Tc, rho, H, ascent=asc)
                except Exception as e:
                    c = {"error": str(e)[:120]}
                res[cname][fl + "|" + asc] = c
    return res

def section_D():
    """GPT VS: top at 1 atm, water 4 m, 60/25 C, isentropic rise, 1 L vapour at bottom, pentane."""
    fl = "n-Pentane"; Th, Tc = K(60), K(25); p_t = 101325.0; p_b = p_t + 1000 * g * 4
    c = cycle(fl, Th, Tc, p_t, p_b, ascent="isentropic", descent="isentropic")
    m = 1e-3 / c["v2"]
    c.update(W_J_1L=c["W_J_per_kg"] * m, Qin_J_1L=c["Qin_J_per_kg"] * m,
             Tsat_b_C=P('T', 'P', p_b, 'Q', 0, fl) - 273.15,
             Tsat_t_C=P('T', 'P', p_t, 'Q', 0, fl) - 273.15, V_top_L=c["v3"] * m * 1e3)
    # same pentane, same column, isothermal ascent in a hot column (two-column layout)
    c2 = cycle(fl, Th, Tc, p_t, p_b, ascent="isothermal")
    m2 = 1e-3 / c2["v2"]
    c2.update(W_J_1L=c2["W_J_per_kg"] * m2, Qin_J_1L=c2["Qin_J_per_kg"] * m2)
    return {"VS_gpt_layout_real_pentane": c, "same_but_isothermal_ascent": c2,
            "gpt_surrogate_reference": {"W_J": 45.302, "Qh_J": 1560.295, "eta": 0.02903}}

def section_E():
    """Ideal-gas Ericsson body, two isothermal columns; regeneration effectiveness eps."""
    r = {}
    for label, rho, H, p_t, Th_c, Tc_c in (("oil3m_atm_110_25", 850, 3, 101325, 110, 25),
                                          ("oil3m_10kPa_110_25", 850, 3, 10000, 110, 25),
                                          ("water20m_atm_90_25", 1000, 20, 101325, 90, 25)):
        Th, Tc = K(Th_c), K(Tc_c); p_b = p_t + rho * g * H; rr = p_b / p_t
        nR = p_b * 1e-3 / Th                         # 1 L hot gas at bottom
        W = nR * (Th - Tc) * math.log(rr)
        for eps in (0.0, 0.8, 0.9, 1.0):
            Q = nR * Th * math.log(rr) + (1 - eps) * 3.5 * nR * (Th - Tc)
            r[f"{label}|eps{eps}"] = dict(r=rr, W_J_1L=W, Qin_J=Q, eta=W / Q,
                                          carnot=1 - Tc / Th, V_top_L=rr * 1e-3 * 1e3 * Tc / Th)
    return r

def skin_penalty():
    """Sensible heat of a 50 um PET/Al film bag vs vapour heat, water MV 110/25 example."""
    out = {}
    for V_top_L in (6.0, 20.0):
        r_top = (3 * V_top_L * 1e-3 / (4 * math.pi)) ** (1 / 3)
        A = 4 * math.pi * r_top ** 2
        m_skin = A * 50e-6 * 1400
        out[f"V_top_{V_top_L}L"] = dict(area_m2=A, skin_g=m_skin * 1e3,
                                        skin_heat_J_dT85=m_skin * 1100 * 85)
    return out

if __name__ == "__main__":
    OUT["B_original_and_PL"] = section_B()
    OUT["C_matched_vapor"] = section_C()
    OUT["D_VS_crosscheck"] = section_D()
    OUT["E_gas_ericsson"] = section_E()
    OUT["skin_penalty"] = skin_penalty()
    json.dump(OUT, open(sys.argv[1] if len(sys.argv) > 1 else "results.json", "w"), indent=1, default=float)
    print("ok")

# ---------------------------------------------------------------- F: first practical corrections (appended)
def section_F(res):
    """Water MV 90/25 C, 3 m oil: effect of cycled skin/magnet heat; tower power order of magnitude."""
    c = res["C_matched_vapor"]["oil3m_90_25"]["Water|isothermal"]
    W = c["W_J_per_L_bottom"]; Q = c["Qin_J_per_L_bottom"]; Vmax = c["vol_ratio_top_over_bottom"]  # L per L bottom
    dT = 65.0
    r_top = (3 * Vmax * 1e-3 / (4 * math.pi)) ** (1 / 3); A = 4 * math.pi * r_top ** 2
    out = {"W_J": W, "Qvap_J": Q, "eta_ideal": W / Q, "bag_area_m2": A}
    for t_um in (50, 12):
        skin = A * t_um * 1e-6 * 1400 * 1100 * dT
        out[f"skin_{t_um}um_J"] = skin
        out[f"eta_skin_{t_um}um"] = W / (Q + skin)
        out[f"eta_skin_{t_um}um_runaround_eps0p8"] = W / (Q + 0.2 * skin)
    mag = 0.030 * 440 * dT
    out["magnet_30g_J"] = mag
    out["eta_skin50_plus_magnet"] = W / (Q + out["skin_50um_J"] + mag)
    # tower: hot column ID 0.25 m, H 3 m, bag inventory 30 % of hot-column volume at max size, cycle 40 s
    Vcol_L = math.pi * 0.125 ** 2 * 3.0 * 1e3
    inv_maxL = 0.30 * Vcol_L
    W_per_Lmax = W / Vmax
    for tc in (40.0, 120.0):
        out[f"tower_P_mech_W_cycle{int(tc)}s"] = inv_maxL * W_per_Lmax / tc
    out["tower_hot_column_L"] = Vcol_L
    return out

if __name__ == "__main__":
    OUT["F_practical"] = section_F(OUT)
    json.dump(OUT, open(sys.argv[1] if len(sys.argv) > 1 else "results.json", "w"), indent=1, default=float)
    print("F ok")
