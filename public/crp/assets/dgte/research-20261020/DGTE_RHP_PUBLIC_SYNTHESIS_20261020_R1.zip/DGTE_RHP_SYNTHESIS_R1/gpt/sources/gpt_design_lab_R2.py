#!/usr/bin/env python3
"""Bounded DGTE development calculator, not a research campaign/arena.

Standard library only. Models are explicit ideal cycles or work budgets.
run: deterministic one-batch calculation (<1 second normally), atomic commit.
status: read-only integrity/status snapshot. Same command verifies/reuses output.
Full batch is the maximum replay unit. No background/remote/hardware actions.
"""
from pathlib import Path
import argparse, csv, hashlib, io, json, math, os, sys

VERSION='DGTE-design-lab-0.1-R2'
G=9.81
R=8.314462618

def digest(b): return hashlib.sha256(b).hexdigest()
def canon(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()

def buoyancy(h, vc, expansion, rh, rc):
    vh=vc*(1+expansion)
    return {'W_ideal_J':G*h*(rh*vh-rc*vc),'mass_min_kg':rc*vc,'mass_max_kg':rh*vh,'free_force_feasible':rh*vh>rc*vc,'V_cold_m3':vc,'V_hot_m3':vh}

def pressure_budget(mass_kg,dp_Pa,eta=0.3,period_s=600.,aux_W=0.):
    """RT64HC nominal low-pressure properties; high-pressure stroke is OPEN.
    250 kJ/kg is total heat storage over 57–72 C, not pure latent enthalpy.
    eta is an explicitly assumed work-to-electrical fraction, not a heat efficiency.
    """
    dv=mass_kg*.11/900
    w=dp_Pa*dv
    e=w*eta-aux_W*period_s
    return {'mass_PCM_kg':mass_kg,'dp_Pa':dp_Pa,'deltaV_assumed_m3':dv,'work_rectangle_J':w,'heat_window_J':mass_kg*250000,'assumed_work_to_electric_fraction':eta,'period_assumed_s':period_s,'aux_assumed_W':aux_W,'conditional_net_electric_J':e,'conditional_net_average_W':e/period_s,'status':'KINEMATIC_BUDGET_ONLY; stroke under pressure, cycle time and PTO are unmeasured'}

def ericsson(h,th=363.15,tc=298.15,volume_bottom_hot_m3=.001,rho=1000.,pt=101325.):
    """Ideal gas: cold isothermal compression, isobaric heating,
    hot isothermal expansion, isobaric cooling. No regeneration.
    Varying-volume buoyancy work equals ideal thermodynamic net work.
    Mechanical coupling may traverse negative local force with a buffer.
    """
    if h<0 or th<tc or tc<=0:raise ValueError('Require H>=0 and Th>=Tc>0')
    pb=pt+rho*G*h
    nr=pb*volume_bottom_hot_m3/th
    cp_molar=3.5*R
    n=nr/R
    lr=math.log(pb/pt)
    hot_iso=nr*th*lr
    cold_iso=nr*tc*lr
    q_reset=n*cp_molar*(th-tc)
    qh=hot_iso+q_reset
    qc=cold_iso+q_reset
    w=nr*(th-tc)*lr
    def force(z):
        # ACTUAL two-body geometry: opposed elevations, not same-z shortcut.
        return rho*G*nr*(th/(pt+rho*G*(h-z))-tc/(pt+rho*G*z))
    def cumulative(z):
        return nr*(th*math.log(pb/(pb-rho*G*z))-tc*math.log((pt+rho*G*z)/pt))
    zmin=max(0.,min(h,(tc*rho*G*h-(th-tc)*pt)/((th+tc)*rho*G)))
    buffer=max(0.,-cumulative(zmin))
    # Independent numerical integral of the actual opposed-elevation force.
    N=10000
    dz=h/N
    wi=dz*(.5*force(0)+sum(force(i*dz) for i in range(1,N))+.5*force(h))
    return {'H_m':h,'Th_K':th,'Tc_K':tc,'rho_bath_kg_m3':rho,'p_top_Pa':pt,'p_bottom_Pa':pb,'n_moles':n,'V_bottom_hot_m3':volume_bottom_hot_m3,'V_top_hot_m3':nr*th/pt,'V_top_cold_m3':nr*tc/pt,'W_ideal_J':w,'Qhot_J':qh,'Qcold_J':qc,'first_law_residual_J':qh-qc-w,'reservoir_Sgen_J_K':qc/tc-qh/th,'eta_ideal_no_regen':w/qh if qh else 0.,'carnot':1-tc/th,'free_capsule_feasible':pb/pt<th/tc,'opposed_pair_start_force_N':force(0),'opposed_pair_end_force_N':force(h),'pair_force_zero_z_m':zmin,'minimum_reversible_buffer_J':buffer,'independent_force_integral_J':wi,'cycle_status':'CLOSED_IDEAL_GAS_MODEL; no shell, heat-transfer speed, friction, generator or auxiliaries validated'}

def loaded_motion(F,kdrag,kgenerator):
    """1D quadratic drag + electromagnetic viscous load, steady state.
    F = kdrag*v² + kgenerator*v. kdrag>0; kgenerator>=0.
    """
    if F<0 or kdrag<=0 or kgenerator<0:raise ValueError('Invalid force coefficients')
    v=2*F/(kgenerator+math.sqrt(kgenerator**2+4*kdrag*F)) if F else 0.
    return {'v_m_s':v,'input_W':F*v,'drag_W':kdrag*v**3,'generator_mechanical_W':kgenerator*v**2}

def hx(ntu,cr):
    if not (ntu>=0 and 0<=cr<=1):raise ValueError('Invalid NTU/Cr')
    if abs(cr-1)<1e-10:return ntu/(1+ntu)
    e=math.exp(-ntu*(1-cr));return (1-e)/(1-cr*e)

def thermal_slab(d,skin=.00005,rhopcm=900.,rhoskin=8000.,k=.2,h=100.,latent=200000.,dt=10.):
    # Scaling illustration only; skins NOT qualified as pressure containment.
    ratio=2*rhoskin*skin/(rhopcm*d)
    return {'PCM_layer_m':d,'assumed_skin_m':skin,'skin_to_PCM_mass_ratio':ratio,'skin_heat_over_PCM_latent_for_15K':ratio*500*15/latent,'ideal_conduction_front_s':rhopcm*latent*d*d/(8*k*dt),'external_convection_lower_scale_s':rhopcm*latent*d/(2*h*dt),'status':'SCALING_ONLY; no strength or actual cycle-time qualification'}

def cases():
    return {'model_version':VERSION,'evidence':'STATIC_IDEAL_MODELS_AND_CONDITIONAL_BUDGETS; no DGTE hardware measurement',
      'baseline':buoyancy(3,.001,.125,850,850),
      'pressure_PCM':[pressure_budget(.1,bar*1e5) for bar in [.25,10,50,100,200]],
      'pressure_conditional_aux_sensitivity':[pressure_budget(.1,50e5,period_s=900,aux_W=a) for a in [0,.005,.02,.05]],
      'closed_gas':[ericsson(h) for h in [0,1,2,4,10,20]],
      'closed_isothermal_control':ericsson(4,th=300,tc=300),
      'loaded_motion':[loaded_motion(1,1,b) for b in [0,.1,1,5,20]],
      'thin_cell_scaling':[thermal_slab(d) for d in [.00025,.001,.002,.005]],
      'event_load':{'voltage_V':3.3,'radio_style_pulses':3,'current_A':.03,'pulse_s':.1,'sense_current_A':.001,'sense_s':.01,'nominal_energy_J':3.3*(3*.03*.1+.001*.01),'energy_acceptance_J':.0297,'minimum_output_V':2.97,'target_stored_energy_J':.15,'actual_radio':'OPEN; this is an explicit synthetic load, not a universal LoRa budget'},
      'pressure_vs_gravity_same_deltaV':{'deltaV_m3':.00001,'H_m':3,'rho_bath':850,'buoyancy_J':850*G*3*.00001,'new_pressure_cycle_dp_Pa':50e5,'pressure_rectangle_J':50e5*.00001,'ratio':50e5/(850*G*3),'note':'ALTERNATIVE cycles; never sum these as independent work from one stroke'},
      'scope':['Ideal gas heat/pressure closure checked; practical EOS/material/container behavior is OPEN.','PCM pressure rectangle is a conditional work budget, not a closed material EOS.','A 600/900-second cycle and 30% mechanical-to-electric conversion are assumptions only.','Same work can be delivered in a short pulse; average power remains energy/full cycle time.','Thermal source/sink pumps and switching belong inside DUT auxiliaries when required.']}

def atomic(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.tmp')
    with tmp.open('wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)

def read_verified(out,code_sha):
    p=out/'results.json'
    obj=json.loads(p.read_text())
    if obj['code_sha256']!=code_sha or obj['model_version']!=VERSION:raise ValueError('Code/version mismatch; use a new output directory')
    if digest(canon(obj['results']))!=obj['results_sha256']:raise ValueError('Corrupt result checksum; preserved for review, no overwrite')
    return obj

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('command',choices=['run','status'],nargs='?',default='run')
    ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parent/'results')
    args=ap.parse_args();sha=digest(Path(__file__).read_bytes());p=args.out/'results.json'
    if args.command=='status':
        d=read_verified(args.out,sha);print(json.dumps({'status':'VERIFIED_COMMIT','model':VERSION,'sha256':d['results_sha256'],'evidence':'STATIC','readonly':True}));return
    if p.exists():
        d=read_verified(args.out,sha);print('VERIFIED_REUSE: completed bounded calculation; no duplicate work or append.');return
    print('DGTE design calculator / one bounded batch / no hardware or remote actions')
    d=cases()
    obj={'model_version':VERSION,'code_sha256':sha,'results_sha256':digest(canon(d)),'results':d}
    csvio=io.StringIO(newline='');rows=d['pressure_PCM'];w=csv.DictWriter(csvio,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    atomic(args.out/'pressure_sensitivity.csv',csvio.getvalue().encode())
    atomic(p,json.dumps(obj,ensure_ascii=False,indent=2).encode()+b'\n')
    print('100% / committed results.json + pressure_sensitivity.csv / max replay: this subsecond batch')

if __name__=='__main__':
    try:main()
    except Exception as e:print('ERROR: '+str(e),file=sys.stderr);sys.exit(2)
