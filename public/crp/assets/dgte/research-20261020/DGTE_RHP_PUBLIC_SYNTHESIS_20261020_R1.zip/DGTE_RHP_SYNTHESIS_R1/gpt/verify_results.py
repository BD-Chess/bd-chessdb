#!/usr/bin/env python3
"""Separate implementation of conformance and selected thermodynamic oracles.

Same GPT session and same CoolProp EOS: code separation, NOT empirical independence.
Does not import builder or author source functions. No hardware validation.
"""
from pathlib import Path
from decimal import Decimal, getcontext
import argparse, hashlib, json, math
from CoolProp.CoolProp import PropsSI as P

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def simpson(fn,a,b,n=800):
    dx=(b-a)/n
    return dx/3*(fn(a)+fn(b)+sum((4 if i%2 else 2)*fn(a+i*dx) for i in range(1,n)))

def main():
    root=Path(__file__).resolve().parent
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=root/'results');args=ap.parse_args()
    p=args.out/'results.json';r=json.loads(p.read_text());tests=[]
    def ck(name,v,detail=None):
        tests.append({'name':name,'passed':bool(v),'detail':detail})
        if not v:raise AssertionError(name+': '+str(detail))
    ck('builder_identity',sha(root/'models_and_gates.py')==r['identity']['code_sha256'])
    ck('fixture_identity',sha(root/'FIXTURE.json')==r['identity']['fixture_sha256'])
    ck('addendum_identity',sha(root/'FIXTURE_ADDENDUM_RT42.json')==r['identity']['material_addendum_sha256'])
    for name,digest in r['identity']['source_sha256'].items():ck('source_'+name,sha(root/'sources'/name)==digest)
    ck('builder_checks_all_recorded_and_passed',len(r['checks'])==191 and all(t['passed'] for t in r['checks']))
    ck('body_case_denominators',len(r['body_models']['MV'])==24 and len(r['body_models']['VS_matched'])==24 and len(r['body_models']['VP'])==8)
    ck('comparison_denominators',len(r['GC'])==24 and len(r['Rankine'])==6 and len(r['VL2'])==12)
    # An unchanged rigid body through a water/air pressure boundary, with reversible access.
    rho_w,rho_a,g,H,V=1000.,1.2,9.81,3.,.001
    rise_gain=(rho_w-rho_a)*g*H*V
    bottom_pressure_access_work=((rho_w*g*H)-(rho_a*g*H))*V
    ck('B0_closed_pressure_boundary_cancels_buoyancy',abs(rise_gain-bottom_pressure_access_work)<1e-12,
       {'ideal_gain_J':rise_gain,'minimum_access_work_J':bottom_pressure_access_work,
        'scope':'fixed external volume, same height, reversible access/reset, no thermally changing state'})
    # Exact arithmetic controls of the economic gate.
    getcontext().prec=45
    rate=Decimal('0.08');om=Decimal('0.03');annual=Decimal('8000')*Decimal('0.12')
    A=sum((1+rate)**(-y) for y in range(1,16))
    cap=annual*A/(1+om*A)
    ck('economic_decimal_oracle',abs(float(cap)-r['economics']['NPV0_EUR_per_net_kW'])<1e-8)
    # VP work via integration by parts, independent of builder's heat/U return calculation:
    # W = (ph-pc)*v_hot - integral_pc^ph v_liquid(Tc,p) dp.
    vp_checks=[]
    for row in r['body_models']['VP']:
        if row['status']!='CLOSED_IDEAL_REAL_FLUID_PATH':continue
        fl=row['fluid'];th=row['Th_C']+273.15;tc=row['Tc_C']+273.15
        ph=row['p_hot_Pa'];pc=row['p_cold_Pa']
        vg=1/P('D','T',th,'Q',1,fl);vl=1/P('D','T',tc,'Q',0,fl)
        def vliquid(pressure):return vl if abs(pressure-pc)<1e-7 else 1/P('D','T',tc,'P',pressure,fl)
        work=(ph-pc)*vg-simpson(vliquid,pc,ph)
        rel=abs(work-row['W_J_kg'])/max(abs(work),1.)
        ck('VP_independent_PdV_'+row['scenario']+fl,rel<1e-6,rel)
        vp_checks.append({'scenario':row['scenario'],'fluid':fl,'W_by_pressure_integral_J_kg':work,'relative_difference':rel})
    body_checks=[]
    for kind in ('MV','VS_matched'):
        for row in r['body_models'][kind]:
            if row['status']!='IDEAL_BODY_MODEL' or row['H_m']!=3 or row['fluid'] not in ('Ethanol','R1233zd(E)'):continue
            th=row['Th_C']+273.15;tc=row['Tc_C']+273.15;fl=row['fluid']
            pt=row['p_t_kPa']*1000;pb=row['p_b_kPa']*1000
            s_hot=P('S','T',th,'P',pb,fl)
            def vdiff(pressure):
                hot=1/P('D','T',th,'P',pressure,fl) if kind=='MV' else 1/P('D','P',pressure,'S',s_hot,fl)
                return hot-1/P('D','T',tc,'P',pressure,fl)
            work=simpson(vdiff,pt,pb)
            rel=abs(work-row['W_J_per_kg'])/max(abs(work),1.)
            ck('body_independent_buoyancy_integral_'+kind+row['scenario']+fl,rel<1e-4,rel)
            body_checks.append({'kind':kind,'scenario':row['scenario'],'fluid':fl,'relative_difference':rel})
    # Regenerator effectiveness claim must be scoped to heat-capacity ratio.
    ck('balanced_NTU_2p3_does_not_give_eps_0p9',abs(2.3/(1+2.3)-0.696969696969697)<1e-12)
    ck('balanced_NTU_9_gives_eps_0p9',abs(9/(1+9)-.9)<1e-12)
    post=json.loads((args.out/'post_analysis.json').read_text())
    ck('post_analysis_binds_numeric_batch',post['numeric_batch_sha256']==sha(p))
    ck('post_analysis_binds_rules',post['post_analysis_rules_sha256']==sha(root/'POST_ANALYSIS_RULES.json'))
    ck('post_analysis_binds_code',post['post_analysis_code_sha256']==sha(root/'post_analysis.py'))
    ck('all_VL2_rows_have_domain_classification',len(post['VL2_necessary_carrier_screen'])==12)
    for row in post['VL2_necessary_carrier_screen']:
        if row['thermal_budget_screen']=='PASSES_NECESSARY_SCREEN_ONLY':
            ck('positive_carrier_margin_'+row['scenario']+str(row['H'])+str(row['vgj']),row['remaining_carrier_to_gas_temperature_K']>0)
    out={'verdict':'PASS_NUMERICAL_CONFORMITY_WITH_RECORDED_MODEL_DOMAIN_GAPS',
         'scope':'Actual artifact identities, eight VP independent PdV integrals, six selected body force/pressure integrals, neutral/reset, economic Decimal, and recorded thermal-budget classification.',
         'physical_device_status':'PARTIAL_NO_HARDWARE_OR_COST_VALIDATION',
         'source_dependence':'One GPT session, shared history, same CoolProp EOS. No independent-agent or alternative-EOS claim.',
         'numeric_results_sha256':sha(p),'post_analysis_sha256':sha(args.out/'post_analysis.json'),
         'verifier_code_sha256':sha(Path(__file__)),'tests':tests,
         'VP_integral_crosschecks':vp_checks,'body_integral_crosschecks':body_checks}
    target=args.out/'verification.json'
    target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'verdict':out['verdict'],'checks_passed':len(tests),'output':str(target),'sha256':sha(target)}))
if __name__=='__main__':main()
