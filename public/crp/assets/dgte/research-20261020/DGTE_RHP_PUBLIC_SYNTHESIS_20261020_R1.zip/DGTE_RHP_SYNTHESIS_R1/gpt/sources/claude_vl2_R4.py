"""DGTE-VL2 R4 (Claude line, 2026-10-20) - two-phase lift loop "0": component balances, losses, Pareto.

Builds on R3 (Drive 1nenz9WHrtybnNiOcTFsu-ieBPM9fTI7-). Requested by GPT T009 in DGTE-LOOP-20261020-01:
  (1) one UNFILTERED Pareto set + a separate reporting view head >= 2 m (best case on each side kept);
  (2) component balances of carrier water and condensate return;
  (3) losses that R3 left out.
R4 changes vs R3:
  - water taken into the gas is returned as condensate at T_c and reheated: Qw = mw*(h_g,w(Te) - h_l,w(Tc))
    (R3 counted latent heat at Te only);
  - riser momentum term: separated-flow momentum flux M = G_l^2/(rho_l(1-a)) + G_g^2/(rho_g a), starting from
    single-phase liquid below the injection point (acceleration pressure drop);
  - loop minor losses on the downcomer velocity head: K_loop in {0, 1.5, 3} (separator re-acceleration,
    inlet, bends, turbine exit) - sensitivity, not a design value;
  - turbine efficiency 0.85 nominal and 0.75 sensitivity (low-head machines);
  - balances reported per point: carrier mass fraction evaporated, carrier temperature drop along the riser
    dT = Q/(rho Q_l cp) (validity of the isothermal-gas assumption), condensate gravity leg height
    H_c = (p_boil - p_top)/(rho_WF,l g) <= H (no feed pump), energy closure Q_in = W_gas + Q_cond;
  - unfiltered grid H 5..40 m x D 0.3..2.5 m; Pareto front on (P_net max, H min, D min).
STILL IDEALISED / OPEN: isothermal gas at T_e, instantaneous WF preheat+boiling at the riser bottom, C0 and v_gj
are sensitivity inputs (not validated for this flow), no NCG, no instability/geysering, no time dependence,
no separator efficiency, no HX/condenser pressure drops on the external streams, no prices. No measurement.
Usage: python3 DGTE_CLAUDE_VL2_MODEL_20261020_R4.py out.json  (fluid sweep: DGTE_CLAUDE_VL2_R4_FLUID_SWEEP_20261020.py, same folder)
"""
import json, math, sys
import CoolProp.CoolProp as CP

g = 9.80665
K = 273.15
RW = 8.314462618 / 0.018015
WF = 'R1233zd(E)'
RHO_L = 990.0       # carrier water
CP_L = 4180.0
F_DARCY = 0.02
ETA_GEN = 0.93
Q_HEAT = 1e6
H_GRID = (5, 7.5, 10, 12.5, 15, 20, 25, 30, 35, 40)
D_GRID = (0.3, 0.4, 0.5, 0.6, 0.8, 1.0, 1.3, 1.6, 2.0, 2.5)
DRIFT = ((1.0, 0.0), (1.2, 0.25), (1.2, 0.5), (1.2, 1.0))
K_LOOP = (0.0, 1.5, 3.0)
ETA_T = (0.85, 0.75)
AUX = (2.0, 5.0, 10.0)
REPORT_HEAD_M = 2.0  # reporting view only - R4 never drops points from the unfiltered set


def cycle(Te, Tc, fluid=None):
    fluid = fluid or WF
    pb = CP.PropsSI('P', 'T', Te, 'Q', 1, fluid)
    pt_wf = CP.PropsSI('P', 'T', Tc, 'Q', 1, fluid)
    pw_e = CP.PropsSI('P', 'T', Te, 'Q', 1, 'Water')
    pw_c = CP.PropsSI('P', 'T', Tc, 'Q', 1, 'Water')
    p_top = pt_wf + pw_c
    p_wf_top = p_top - pw_e
    hl_c = CP.PropsSI('H', 'T', Tc, 'Q', 0, fluid)
    hg_e = CP.PropsSI('H', 'T', Te, 'Q', 1, fluid)
    sg_e = CP.PropsSI('S', 'T', Te, 'Q', 1, fluid)
    n = 300
    w = 0.0
    for i in range(n):
        p1 = pb - (pb - p_wf_top) * i / n
        p2 = pb - (pb - p_wf_top) * (i + 1) / n
        w += (p1 - p2) / CP.PropsSI('D', 'T', Te, 'P', 0.5 * (p1 + p2), fluid)
    s_top = CP.PropsSI('S', 'T', Te, 'P', p_wf_top, fluid)
    h_top = CP.PropsSI('H', 'T', Te, 'P', p_wf_top, fluid)
    q_in = (hg_e - hl_c) + Te * (s_top - sg_e)
    rho_wf_top = CP.PropsSI('D', 'T', Te, 'P', p_wf_top, fluid)
    mw = (pw_e / (RW * Te)) / rho_wf_top
    hw_g_e = CP.PropsSI('H', 'T', Te, 'Q', 1, 'Water')
    hw_l_e = CP.PropsSI('H', 'T', Te, 'Q', 0, 'Water')
    hw_l_c = CP.PropsSI('H', 'T', Tc, 'Q', 0, 'Water')
    Qw_R3 = mw * (hw_g_e - hw_l_e)
    Qw = mw * (hw_g_e - hw_l_c)                       # R4: condensate returned at Tc and reheated
    q_cond = (h_top - hl_c) + mw * (hw_g_e - hw_l_c)  # condenser duty per kg WF (water condensed at Tc)
    rho_wf_liq = CP.PropsSI('D', 'T', Tc, 'Q', 0, fluid)
    closure = (q_in + Qw - w - q_cond) / (q_in + Qw)
    return dict(pb=pb, pt=pt_wf, p_top=p_top, p_wf_top=p_wf_top, pw_e=pw_e, pw_c=pw_c, w=w, q_in=q_in,
                mw=mw, Qw=Qw, Qw_R3=Qw_R3, q_cond=q_cond, rho_wf_liq=rho_wf_liq, energy_closure_rel=closure,
                eta_ideal=w / (q_in + Qw), eta_ideal_R3=w / (q_in + Qw_R3), carnot=1 - Tc / Te)


_TAB = {}


def wf_density(Te, p_wf, fluid=None):
    fluid = fluid or WF
    key = (round(Te, 3), fluid)
    if key not in _TAB:
        psat = CP.PropsSI('P', 'T', Te, 'Q', 1, fluid)
        ps = [1000.0 + (psat * 0.99999 - 1000.0) * i / 400 for i in range(401)]
        _TAB[key] = (ps, [CP.PropsSI('D', 'T', Te, 'P', x, fluid) for x in ps])
    ps, rs = _TAB[key]
    p_wf = min(max(p_wf, ps[0]), ps[-1])
    i = min(int((p_wf - ps[0]) / (ps[1] - ps[0])), len(ps) - 2)
    t = (p_wf - ps[i]) / (ps[i + 1] - ps[i])
    return rs[i] + t * (rs[i + 1] - rs[i])


def local_state(p, Q_l, m_wf, Te, pw_e, A, C0, vgj):
    rwf = wf_density(Te, p - pw_e)
    rg = rwf + pw_e / (RW * Te)
    jg = m_wf / rwf / A
    jl = Q_l / A
    alpha = jg / (C0 * (jg + jl) + vgj)
    rm = (1 - alpha) * RHO_L + alpha * rg
    mom = (RHO_L * jl) ** 2 / (RHO_L * (1 - alpha)) + (rg * jg) ** 2 / (rg * alpha)
    return rm, jg + jl, alpha, mom


def riser(Q_l, m_wf, Te, p_bot, pw_e, H, D, C0, vgj, accel=True, nz=120):
    A = math.pi * D * D / 4
    dz = H / nz
    p = p_bot
    rm, j, alpha, mom = local_state(p, Q_l, m_wf, Te, pw_e, A, C0, vgj)
    p -= (mom - RHO_L * (Q_l / A) ** 2) if accel else 0.0   # injection: single-phase liquid -> two-phase
    dp_acc = (mom - RHO_L * (Q_l / A) ** 2) if accel else 0.0
    alpha_bot = alpha
    for _ in range(nz):
        rm, j, alpha, mom0 = local_state(max(p, 2000.0), Q_l, m_wf, Te, pw_e, A, C0, vgj)
        p_pred = p - (rm * g + F_DARCY * rm * j * j / (2 * D)) * dz
        if p_pred < pw_e + 2000:
            return -1e9, None
        if accel:
            _, _, _, mom1 = local_state(p_pred, Q_l, m_wf, Te, pw_e, A, C0, vgj)
            p_pred -= (mom1 - mom0)
            dp_acc += (mom1 - mom0)
        p = p_pred
        if p < pw_e + 2000:
            return -1e9, None
    _, _, alpha_top, _ = local_state(p, Q_l, m_wf, Te, pw_e, A, C0, vgj)
    u_l_top = (Q_l / A) / (1 - alpha_top)
    return p, dict(alpha_bot=alpha_bot, alpha_top=alpha_top, dp_acc=dp_acc, u_l_top=u_l_top)


def solve(cy, Te, Tc, H, D, C0, vgj, accel=True):
    m_wf = Q_HEAT / (cy['q_in'] + cy['Qw'])
    p_boil = cy['pb'] + cy['pw_e']
    p_top = cy['p_top']
    lo, hi = 1e-4, 60.0
    if riser(lo, m_wf, Te, p_boil, cy['pw_e'], H, D, C0, vgj, accel)[0] - p_top < 0:
        return None
    if riser(hi, m_wf, Te, p_boil, cy['pw_e'], H, D, C0, vgj, accel)[0] - p_top > 0:
        return None
    for _ in range(55):
        mid = math.sqrt(lo * hi)
        if riser(mid, m_wf, Te, p_boil, cy['pw_e'], H, D, C0, vgj, accel)[0] - p_top > 0:
            lo = mid
        else:
            hi = mid
    Q_l = math.sqrt(lo * hi)
    _, info = riser(Q_l, m_wf, Te, p_boil, cy['pw_e'], H, D, C0, vgj, accel)
    A = math.pi * D * D / 4
    v_down = Q_l / A
    dp_fric_down = F_DARCY * RHO_L * v_down ** 2 / 2 * H / D
    P_gas = m_wf * cy['w']
    rows = []
    for kl in K_LOOP:
        dp_minor = kl * 0.5 * RHO_L * v_down ** 2
        dp_t = p_top + RHO_L * g * H - p_boil - dp_fric_down - dp_minor
        P_h = Q_l * dp_t
        rows.append(dict(K_loop=kl, head_m=dp_t / (RHO_L * g), P_hydr_kW=P_h / 1e3,
                         lift=P_h / P_gas,
                         P_net_kW={'%.2f' % et: [P_h * et * ETA_GEN / 1e3 - a for a in AUX] for et in ETA_T}))
    m_water = cy['mw'] * m_wf
    H_c = (p_boil - p_top) / (cy['rho_wf_liq'] * g)
    return dict(H=H, D=D, C0=C0, vgj=vgj, Q_l=Q_l, v_down=v_down, m_WF=m_wf, P_gas_kW=P_gas / 1e3,
                alpha_bot=info['alpha_bot'], alpha_top=info['alpha_top'], dp_acc_kPa=info['dp_acc'] / 1e3,
                u_l_top=info['u_l_top'], dp_fric_down_kPa=dp_fric_down / 1e3,
                carrier_evap_frac=m_water / (RHO_L * Q_l), carrier_dT_K=Q_HEAT / (RHO_L * Q_l * CP_L),
                condensate_leg_m=H_c, condensate_leg_ok=H_c <= H, rows=rows)


def econ(P_net_kW, h=8000, price=0.12, om=0.03, r=0.08, n=15):
    A = (1 - (1 + r) ** -n) / r
    return P_net_kW * h * price * A / (1 + om * A) if P_net_kW > 0 else 0.0


def pnet(pt, kl=1.5, et='0.85', aux_i=1):
    row = [r for r in pt['rows'] if r['K_loop'] == kl][0]
    return row['P_net_kW'][et][aux_i], row['head_m']


def pareto(points, kl=1.5, et='0.85'):
    """Non-dominated on (P_net max, H min, D min)."""
    vals = [(pnet(p, kl, et)[0], p['H'], p['D'], p) for p in points if pnet(p, kl, et)[0] > 0]
    front = []
    for a in vals:
        dom = False
        for b in vals:
            if b is a:
                continue
            if b[0] >= a[0] and b[1] <= a[1] and b[2] <= a[2] and (b[0] > a[0] or b[1] < a[1] or b[2] < a[2]):
                dom = True
                break
        if not dom:
            front.append(a[3])
    return sorted(front, key=lambda p: (p['H'], p['D']))


def compact(p, kl=1.5, et='0.85'):
    row = [r for r in p['rows'] if r['K_loop'] == kl][0]
    pn = row['P_net_kW'][et]
    return dict(H=p['H'], D=p['D'], Q_l=round(p['Q_l'], 3), head_m=round(row['head_m'], 2), lift=round(row['lift'], 3),
                net_aux2_5_10=[round(x, 1) for x in pn], Cmax_kEUR_aux5=round(econ(pn[1]) / 1e3, 1),
                a_top=round(p['alpha_top'], 3), dT_carrier=round(p['carrier_dT_K'], 2))


def run(accel=True):
    out = dict(model='DGTE-VL2 R4', status='IDEAL reduced 1-D drift-flux + balances + losses; sensitivity; no measurement',
               coolprop=CP.get_global_param_string('version'), WF=WF, carrier_rho=RHO_L, f_darcy=F_DARCY,
               eta_gen=ETA_GEN, eta_turb=ETA_T, K_loop=K_LOOP, aux_kW=AUX, H_grid=H_GRID, D_grid=D_GRID,
               accel=accel, scenarios=[])
    scen = [('S60 (45/30, idealised sink)', 45, 30), ('S60-F (45/35, sink 25->30)', 45, 35),
            ('S90 (65/30, idealised sink)', 65, 30), ('S90-F (65/35, sink 25->30)', 65, 35)]
    for name, te, tc in scen:
        Te, Tc = te + K, tc + K
        cy = cycle(Te, Tc)
        sc = dict(scenario=name, cycle={k: cy[k] for k in ('pb', 'p_top', 'pw_e', 'w', 'q_in', 'mw', 'Qw', 'Qw_R3',
                                                           'q_cond', 'energy_closure_rel', 'eta_ideal',
                                                           'eta_ideal_R3', 'carnot', 'rho_wf_liq')}, cases=[])
        for C0, vgj in DRIFT:
            pts = []
            for H in H_GRID:
                for D in D_GRID:
                    r = solve(cy, Te, Tc, H, D, C0, vgj, accel)
                    if r:
                        pts.append(r)
            case = dict(C0=C0, vgj=vgj, n_points=len(pts), views={})
            for kl in K_LOOP:
                for et in ('0.85', '0.75'):
                    key = 'K%.1f_eta%s' % (kl, et)
                    ok = [p for p in pts if pnet(p, kl, et)[0] > -1e9]
                    hi = [p for p in ok if pnet(p, kl, et)[1] >= REPORT_HEAD_M]
                    lo = [p for p in ok if pnet(p, kl, et)[1] < REPORT_HEAD_M]
                    best = lambda s: compact(max(s, key=lambda p: pnet(p, kl, et)[0]), kl, et) if s else None
                    case['views'][key] = dict(best_unfiltered=best(ok), best_head_ge_2m=best(hi), best_head_lt_2m=best(lo))
            case['pareto_K1.5_eta0.85'] = [compact(p) for p in pareto(pts)]
            case['balances_at_best'] = None
            if pts:
                b = max(pts, key=lambda p: pnet(p)[0])
                case['balances_at_best'] = dict(H=b['H'], D=b['D'], carrier_evap_frac=b['carrier_evap_frac'],
                                                carrier_dT_K=b['carrier_dT_K'], condensate_leg_m=b['condensate_leg_m'],
                                                condensate_leg_ok=b['condensate_leg_ok'], dp_acc_kPa=b['dp_acc_kPa'],
                                                u_l_top=b['u_l_top'], alpha_bot=b['alpha_bot'], alpha_top=b['alpha_top'],
                                                dp_fric_down_kPa=b['dp_fric_down_kPa'])
            case['points'] = [dict(H=p['H'], D=p['D'], Q_l=round(p['Q_l'], 4), dT=round(p['carrier_dT_K'], 3),
                                   dp_acc_kPa=round(p['dp_acc_kPa'], 3),
                                   head_K=[round(r['head_m'], 3) for r in p['rows']],
                                   Ph_K_kW=[round(r['P_hydr_kW'], 2) for r in p['rows']]) for p in pts]
            sc['cases'].append(case)
        out['scenarios'].append(sc)
    return out


if __name__ == '__main__':
    accel = '--no-accel' not in sys.argv
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    res = run(accel)
    path = args[0] if args else 'dgte_vl2_r4_results.json'
    with open(path, 'w') as fh:
        json.dump(res, fh, indent=1)
    for sc in res['scenarios']:
        c = sc['cycle']
        print(sc['scenario'], 'eta_id %.4f (R3 %.4f) closure %.1e Hc_needs rho %.0f' % (
            c['eta_ideal'], c['eta_ideal_R3'], c['energy_closure_rel'], c['rho_wf_liq']))
        for case in sc['cases']:
            v = case['views']
            print('  C0 %.1f vgj %.2f n=%d' % (case['C0'], case['vgj'], case['n_points']))
            for key in ('K0.0_eta0.85', 'K1.5_eta0.85', 'K3.0_eta0.85', 'K1.5_eta0.75'):
                print('    %-13s unf %s\n                  >=2 %s\n                  <2  %s' % (
                    key, v[key]['best_unfiltered'], v[key]['best_head_ge_2m'], v[key]['best_head_lt_2m']))
            print('    pareto n=%d' % len(case['pareto_K1.5_eta0.85']))
            print('    balances', case['balances_at_best'])
