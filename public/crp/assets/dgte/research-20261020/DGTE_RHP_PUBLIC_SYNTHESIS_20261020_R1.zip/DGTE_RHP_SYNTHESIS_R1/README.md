# DGTE scientific synthesis · 20 October 2026 · R1

Authorship: BD original DGTE and water–air/0 seed; GPT P/L, VS, VP, GC, H1/H2, finite-stream/economic checks and synthesis; Claude MV, VL2 and C1 arithmetic. Existing source scripts are unchanged and individually hashed. H2 liquid piston and C1 VP×VL2 are related proposals, not a novelty claim.

This public subset contains scientific code, numerical fixtures/results and a targeted audit. It omits private bootstrap/continuity, chat logs and third-party full papers. Its 30 audit checks are arithmetic/provenance checks, not 30 physical experiments. The earlier GPT R1 builder has 191 checks and its separate verifier 36; the same EOS/context is not independent empirical validation.

## Reproduce

Python 3.12, CoolProp==8.0.0 (original NumPy 2.5.4). Install in an appropriate isolated environment. Verify each FILE_MANIFEST.json member before running.

    python audit_synthesis.py --root . --out audit_new.json
    python gpt/verify_results.py --out gpt/results

For a fresh full bounded model batch, choose a new directory:

    python gpt/models_and_gates.py --out rerun_R1
    python gpt/post_analysis.py --out rerun_R1
    python gpt/verify_results.py --out rerun_R1

The audit recomputes Claude C1 PCM/height/storage/pumping/lift-band arithmetic from preserved JSON and binds the selected GPT R1 results by SHA-256. It does not rerun the entire C1 geometry optimization. The C1 adversarial fz.py–fz5.py code was not supplied; reported stacked-loss 9/14 kW values are not reproduced here.

## Domains

S60=60→50°C, S90=90→70°C, each 1 MW heat; cold stream 25→30°C. GPT R1 also uses an external 5 K approach and an additional internal allowance 1 K per end, giving 44/36°C and 64/36°C reference body temperatures. C1 generally uses 45/35°C and 65/35°C. Never merge these as a statistical interval.

Five of twelve selected VL2 points pass only the necessary single-hot-carrier 1 K budget; others fail or have no root. That is not a full coupled thermal/hydraulic proof. VP wall mass, conversion, cycle frequency and regeneration are unvalidated. Rankine component efficiencies are assumptions, not supplier curves. Neither model demonstrates net electricity or acceptable whole installed cost.

Hydraulic airlift efficiency must be compared against gas work at the same absolute endpoints, separately from actual compressor electricity. Small air/water studies do not validate dense-vapor VL2 scaling. A transferred drift correlation is not measured calibration. Cost-dependent inverse requirements are not market prices.

Public synthesis: https://www.mdlxdcc.org/crp/DGTE.html#rhp-synthesis-20261020
