"""DGTE-VL2 R3 (Claude line, 2026-10-20) - closed 1-D drift-flux riser for the two-phase lift loop "0".

R3 vs R2 (consistent water-vapour / pressure balance): the carrier keeps water vapour at its saturation
partial pressure pw(T_e) in the gas; the gas VOLUME is set by the WF alone at its partial pressure
p_wf = p - pw(T_e); WF partial pressure runs from p_sat,WF(T_e) (bottom) to p_top - pw(T_e) (top), where
p_top = p_sat,WF(T_c) + pw(T_c) is the condenser total pressure. Water evaporated into the expanding gas is
taken from the carrier (heat counted at the top state). Reference work = m_WF * int v_WF dp_WF over that range.

Changes vs R1 (after GPT #03/#05 in DGTE-LOOP-20261020-01):
  - condensing temperature is a scenario input (Tc 30 idealised sink, Tc 35 finite sink 25->30 C)
  - WF mass flow from the heat balance: m_WF = Q / (q_in + Q_water)  (GPT correction)
  - riser solved as 1-D drift-flux column (Zuber-Findlay alpha = j_g / (C0 j + v_gj)), real-gas WF density
    (CoolProp) + carrier water vapour, homogeneous wall friction; Q_l found by shooting so that the riser
    reproduces the top pressure; turbine pressure from the downcomer; lift efficiency is DERIVED, not assumed.
STILL IDEALISED: isothermal gas at T_e, no acceleration term, no separator/turbine/HX losses inside the loop,
C0 and v_gj are sensitivity inputs (not a validated correlation for this flow), no instability model.
No measurement. Usage: python3 dgte_vl2_model_r2.py out.json
"""
import json, math, sys
import CoolProp.CoolProp as CP

g = 9.80665
K = 273.15
RW = 8.314462618 / 0.018015
WF = 'R1233zd(E)'
RHO_L = 990.0       # carrier water
F_DARCY = 0.02
MIN_HEAD_M = 2.0     # R3: exclude unrealistic ultra-low-head optima


def cycle(Te, Tc, fluid=WF):
    pb = CP.PropsSI('P', 'T', Te, 'Q', 1, fluid)               # WF partial pressure at boiling level
    pt_wf = CP.PropsSI('P', 'T', Tc, 'Q', 1, fluid)
    pw_e = CP.PropsSI('P', 'T', Te, 'Q', 1, 'Water')
    pw_c = CP.PropsSI('P', 'T', Tc, 'Q', 1, 'Water')
    p_top = pt_wf + pw_c                                          # condenser total pressure
    p_wf_top = p_top - pw_e                                       # WF partial pressure at riser top (T_e)
    hl_c = CP.PropsSI('H', 'T', Tc, 'Q', 0, fluid)
    hg_e = CP.PropsSI('H', 'T', Te, 'Q', 1, fluid)
    sg_e = CP.PropsSI('S', 'T', Te, 'Q', 1, fluid)
    n = 300
    w = 0.0
    for i in range(n):
        p1 = pb - (pb - p_wf_top) * i / n
        p2 = pb - (pb - p_wf_top) * (i + 1) / n
        w += (p1 - p2) / CP.PropsSI('D', 'T', Te, 'P', 0.5 * (p1 + p2), fluid)
    s_top = CP.PropsSI('S', 'T', Te, 'P', p_wf_top, fluid)
    q_in = (hg_e - hl_c) + Te * (s_top - sg_e)
    rho_wf_top = CP.PropsSI('D', 'T', Te, 'P', p_wf_top, fluid)
    mw = (pw_e / (RW * Te)) / rho_wf_top                          # kg water vapour per kg WF leaving the riser
    Lw = CP.PropsSI('H', 'T', Te, 'Q', 1, 'Water') - CP.PropsSI('H', 'T', Te, 'Q', 0, 'Water')
    return dict(pb=pb, pt=pt_wf, p_top=p_top, p_wf_top=p_wf_top, pw_e=pw_e, pw_c=pw_c, w=w, q_in=q_in,
                mw=mw, Qw=mw * Lw, ww=0.0, eta_ideal=w / (q_in + mw * Lw), carnot=1 - Tc / Te)


_TAB = {}


def gas_density(Te, p, pw_e, fluid=WF):
    """Real-gas WF density at its partial pressure (tabulated, linear interp) + ideal water vapour."""
    key = (round(Te, 3), fluid)
    if key not in _TAB:
        psat = CP.PropsSI('P', 'T', Te, 'Q', 1, fluid)
        rho_sat = CP.PropsSI('D', 'T', Te, 'Q', 1, fluid)
        ps = [1000.0 + (psat * 0.99999 - 1000.0) * i / 400 for i in range(401)]
        _TAB[key] = (ps, [CP.PropsSI('D', 'T', Te, 'P', x, fluid) for x in ps], psat, rho_sat)
    ps, rs, psat, rho_sat = _TAB[key]
    p_wf = min(max(p - pw_e, ps[0]), ps[-1])
    i = min(int((p_wf - ps[0]) / (ps[1] - ps[0])), len(ps) - 2)
    t = (p_wf - ps[i]) / (ps[i + 1] - ps[i])
    return rs[i] + t * (rs[i + 1] - rs[i]) + pw_e / (RW * Te)


def riser_top_pressure(Q_l, m_g, Te, p_bot, pw_e, H, D, C0, vgj, nz=120):
    """m_g here is the WF mass flow; gas volume = WF volume at its partial pressure (water rides along)."""
    A = math.pi * D * D / 4
    p = p_bot
    dz = H / nz
    for _ in range(nz):
        rg = gas_density(Te, p, pw_e)
        rwf = rg - pw_e / (RW * Te)
        jg = m_g / rwf / A
        jl = Q_l / A
        alpha = jg / (C0 * (jg + jl) + vgj)
        rm = (1 - alpha) * RHO_L + alpha * rg
        j = jg + jl
        dpdz = rm * g + F_DARCY * rm * j * j / (2 * D)
        p -= dpdz * dz
        if p < 1000:
            return -1e9, alpha
    return p, alpha


def solve_loop(cy, Te, Q_heat, H, D, C0, vgj):
    m_wf = Q_heat / (cy['q_in'] + cy['Qw'])
    m_g = m_wf                                 # gas volume carried by the WF (R3)
    p_boil = cy['pb'] + cy['pw_e']            # WF starts to boil where riser pressure falls to this
    p_top = cy['p_top']                        # condenser total pressure
    lo, hi = 1e-4, 50.0
    f_lo = riser_top_pressure(lo, m_g, Te, p_boil, cy['pw_e'], H, D, C0, vgj)[0] - p_top
    f_hi = riser_top_pressure(hi, m_g, Te, p_boil, cy['pw_e'], H, D, C0, vgj)[0] - p_top
    if f_lo < 0:      # even with ~no liquid the column is too heavy: gas cannot lift to this height
        return None
    if f_hi > 0:
        return None
    for _ in range(60):
        mid = math.sqrt(lo * hi)
        f = riser_top_pressure(mid, m_g, Te, p_boil, cy['pw_e'], H, D, C0, vgj)[0] - p_top
        if f > 0:
            lo = mid
        else:
            hi = mid
    Q_l = math.sqrt(lo * hi)
    A = math.pi * D * D / 4
    v_down = Q_l / A                           # downcomer of the same diameter
    dp_fric_down = F_DARCY * RHO_L * v_down ** 2 / 2 * H / D
    dp_turb = p_top + RHO_L * g * H - p_boil - dp_fric_down
    P_turb_ideal = Q_l * dp_turb               # hydraulic power available to the turbine
    P_gas_ideal = m_wf * cy['w']               # = m_WF * int v_WF dp_WF, p_WF: pb -> p_top - pw_e
    _, alpha_top = riser_top_pressure(Q_l, m_g, Te, p_boil, cy['pw_e'], H, D, C0, vgj)
    return dict(H_m=H, D_m=D, C0=C0, vgj=vgj, m_WF_kgs=m_wf, Q_l_m3s=Q_l, turbine_head_m=dp_turb / (RHO_L * g),
                P_hydraulic_kW=P_turb_ideal / 1e3, P_gas_ideal_kW=P_gas_ideal / 1e3,
                lift_eff=P_turb_ideal / P_gas_ideal if P_gas_ideal > 0 else None, alpha_top=alpha_top,
                riser_volume_m3=A * H)


def econ(P_net_kW, h=8000, price=0.12, om=0.03, r=0.08, n=15):
    A = (1 - (1 + r) ** -n) / r
    return P_net_kW * h * price * A / (1 + om * A)


def run():
    out = dict(model='DGTE-VL2 R3', status='IDEAL 1-D drift-flux; sensitivity on C0, v_gj; no measurement',
               coolprop=CP.get_global_param_string('version'), WF=WF, carrier_rho=RHO_L, f_darcy=F_DARCY,
               scenarios=[])
    scen = [('S60 (45/30, idealised sink)', 45, 30), ('S60-F (45/35, sink 25->30)', 45, 35),
            ('S90 (65/30, idealised sink)', 65, 30), ('S90-F (65/35, sink 25->30)', 65, 35)]
    for name, te, tc in scen:
        Te, Tc = te + K, tc + K
        cy = cycle(Te, Tc)
        sc = dict(scenario=name, p_boil_kPa=(cy['pb'] + cy['pw_e']) / 1e3, p_top_kPa=(cy['pt'] + cy['pw_c']) / 1e3,
                  eta_ideal=cy['eta_ideal'], carnot=cy['carnot'], w_WF_J_kg=cy['w'], cases=[])
        for C0, vgj in ((1.0, 0.0), (1.2, 0.25), (1.2, 0.5), (1.2, 1.0)):
            best = None
            for H in (10, 15, 20, 30, 40):
                for D in (0.4, 0.6, 0.8, 1.0, 1.3, 1.6, 2.0):
                    r = solve_loop(cy, Te, 1e6, H, D, C0, vgj)
                    if r and r['turbine_head_m'] >= MIN_HEAD_M and (best is None or r['P_hydraulic_kW'] > best['P_hydraulic_kW']):
                        best = r
            if best:
                Pg = best['P_hydraulic_kW'] * 0.85 * 0.93
                best['P_gross_el_kW'] = Pg
                best['P_net_kW_aux2_5_10'] = [Pg - a for a in (2, 5, 10)]
                best['Cmax_EUR_aux2_5_10'] = [econ(Pg - a) if Pg - a > 0 else 0 for a in (2, 5, 10)]
            sc['cases'].append(dict(C0=C0, vgj=vgj, best=best))
        out['scenarios'].append(sc)
    return out


if __name__ == '__main__':
    res = run()
    path = sys.argv[1] if len(sys.argv) > 1 else 'dgte_vl2_r3_results.json'
    with open(path, 'w') as fh:
        json.dump(res, fh, indent=1)
    for sc in res['scenarios']:
        print(sc['scenario'], 'p_boil %.1f p_top %.1f kPa eta_id %.4f carnot %.4f' % (sc['p_boil_kPa'], sc['p_top_kPa'], sc['eta_ideal'], sc['carnot']))
        for c in sc['cases']:
            b = c['best']
            if not b:
                print('   C0 %.1f vgj %.2f : no solution' % (c['C0'], c['vgj'])); continue
            print('   C0 %.1f vgj %.2f : H %d D %.1f  Q_l %.3f  head %.1f m  hydr %.1f kW / gas %.1f kW  lift %.2f  a_top %.2f  gross %.1f  net(2/5/10) %s  Cmax %s' % (
                c['C0'], c['vgj'], b['H_m'], b['D_m'], b['Q_l_m3s'], b['turbine_head_m'], b['P_hydraulic_kW'], b['P_gas_ideal_kW'],
                b['lift_eff'], b['alpha_top'], b['P_gross_el_kW'], [round(x, 1) for x in b['P_net_kW_aux2_5_10']],
                [round(x / 1e3) for x in b['Cmax_EUR_aux2_5_10']]))
