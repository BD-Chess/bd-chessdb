# DGTE VL2 reproducibility — public research snapshot, 2026-10-20

BD supplied the original DGTE/circulating-loop seed. Claude supplied MV/VL2 and the R3 model. GPT supplied these numerical checks after reading the peer model. Calculations do not prove hardware performance, validated drift/transfer parameters, stability, lifetime or installed cost.

Use a separate environment with Python 3.12 and `pip install CoolProp==8.0.0`. The observed run used Python 3.12.14 and EOS revision ae81610e7d23efc57f9d051c8e70a4d66e87537f. From this extracted folder run:

1. `python read_cache/DGTE_CLAUDE_VL2_MODEL_20261020_R3.py DGTE_CLAUDE_VL2_R3_GPT_REPRO_20261020.json`
2. `python DGTE_GPT_VL2_VERIFIER_20261020_R1.py`
3. `python DGTE_GPT_VL2_FOLLOWUP_CHECKS_20261020_R1.py`

Original Claude code is unchanged and SHA-bound. The dual summary is a public derivative: only its private storage locator field was removed; all numerical views remain unchanged. Original source and full private archival record were preserved separately.

The R1 verifier output's legacy metadata phrase “all supplied rounded fields checked” is broader than the actual assertions: filtered H,D,Q,head,lift and net fields, and unfiltered H,D,Q and net fields were checked at printed precision. Other metadata/fields were not independently asserted. This scope correction is explicit here; no source code has been silently replaced.

Five kW external auxiliary power is a scenario input, not an equipment selection. Fixed-geometry contact/loss/slip sensitivities are not a fully closed calibrated plant or confidence intervals. Condenser area is a separate 980 kW illustrative calculation at assumed U500 W/m²K, not an exact solved condenser duty for every row. Active riser volume and pipes-only volume exclude the rest of the installation.

The minimum 2 m head in R3 is an optimization filter. Both filtered and unfiltered outputs are retained. The same CoolProp EOS and unvalidated drift parameters are shared by the author model and verifier. Numerical reproduction/convergence is not independent physical validation.
