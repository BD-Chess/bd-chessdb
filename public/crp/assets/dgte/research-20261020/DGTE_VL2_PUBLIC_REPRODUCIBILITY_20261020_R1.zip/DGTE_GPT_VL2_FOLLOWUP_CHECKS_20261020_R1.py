"""GPT numerical convergence and slip sensitivities after main verifier; no new physics validation."""
import json
from pathlib import Path
import DGTE_GPT_VL2_VERIFIER_20261020_R1 as v

convergence=[];profiles=[]
for name,T,H,Ds in [('S60-F',44,10,[.8,.8,.6]),('S90-F',64,40,[.6,.6,.4])]:
    c=v.props(T,water_sensible=True)
    a=v.solve(c,H,Ds[0],nz=120,acceleration=True,phase_mass=True,extra_dp=1000)
    b=v.solve(c,H,Ds[0],nz=480,acceleration=True,phase_mass=True,extra_dp=1000)
    delta=b['P_net_aux5_kW']-a['P_net_aux5_kW']
    assert abs(delta)<.001 and abs(b['pressure_residual_Pa'])<.001
    convergence.append(dict(scenario=name,nz120=a,nz480=b,net_difference_kW=delta,status='PASS_NUMERICAL_ONLY'))
    for slip,D in zip([.25,.5,1.0],Ds):
        r=v.solve(c,H,D,vgj=slip,nz=240,acceleration=True,phase_mass=True,extra_dp=1000)
        profiles.append(dict(scenario=name,assumed_min_contact_K=1,result=r))
        print(name,'vgj',slip,'net kW',r['P_net_aux5_kW'])
Path('DGTE_GPT_VL2_CONVERGENCE_20261020.json').write_text(json.dumps(convergence,indent=2)+'\n')
Path('DGTE_GPT_VL2_SLIP_SENSITIVITY_20261020.json').write_text(json.dumps(profiles,indent=2)+'\n')
