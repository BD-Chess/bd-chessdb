"""GPT post-loop verification, after exposure to Claude VL2 R3.

Same CoolProp EOS and unvalidated C0/vgj closure; not independent physical validation.
Independent RK4 pressure implementation with optional phase-water mass and acceleration.
No unstable-flow, interfacial momentum profile, separator or complete plant model.
"""
from pathlib import Path
import sys, json, math, hashlib, importlib.util, bisect, platform, datetime
import CoolProp.CoolProp as CP

G=9.80665
RHO=990.0
RW=8.314462618/.018015
WF='R1233zd(E)'
ROOT=Path(__file__).resolve().parent
PEER=ROOT/'read_cache/DGTE_CLAUDE_VL2_MODEL_20261020_R3.py'
EXPECTED='1ede72128eaf293405e4cf1c69fbc266b5eefd1e2c605afe83ae5efb4ef5b023'
assert hashlib.sha256(PEER.read_bytes()).hexdigest()==EXPECTED

def props(te,tc=35,water_sensible=False):
    T,C=te+273.15,tc+273.15
    pb=CP.PropsSI('P','T',T,'Q',1,WF)
    pws=CP.PropsSI('P','T',T,'Q',1,'Water')
    pt=CP.PropsSI('P','T',C,'Q',1,WF)+CP.PropsSI('P','T',C,'Q',1,'Water')
    pwft=pt-pws
    # independent Simpson integration in log pressure; no peer quadrature code.
    n=2000; a,b=math.log(pwft),math.log(pb);h=(b-a)/n
    def vp(y):
        p=math.exp(y)
        dens=CP.PropsSI('D','T',T,'Q',1,WF) if abs(p/pb-1)<1e-6 else CP.PropsSI('D','T',T,'P',p,WF)
        return p/dens
    I=h/3*(vp(a)+vp(b)+sum((4 if i%2 else 2)*vp(a+i*h) for i in range(1,n)))
    hc=CP.PropsSI('H','T',C,'Q',0,WF)
    ht=CP.PropsSI('H','T',T,'P',pwft,WF)
    hg=CP.PropsSI('H','T',T,'Q',1,WF)
    st=CP.PropsSI('S','T',T,'P',pwft,WF)
    sg=CP.PropsSI('S','T',T,'Q',1,WF)
    qwf=ht-hc+I
    q_entropy=hg-hc+T*(st-sg)
    assert abs(qwf-q_entropy)<.1
    rho_wv=pws/(RW*T)
    rho_wft=CP.PropsSI('D','T',T,'P',pwft,WF)
    mu=rho_wv/rho_wft
    h_wv=CP.PropsSI('H','T',T,'Q',1,'Water')
    h_wl=CP.PropsSI('H','T',C if water_sensible else T,'Q',0,'Water')
    qwater=mu*(h_wv-h_wl)
    lo=max(1000,pwft*.25);np=2000;step=(pb-lo)/np
    grid=[lo+step*i for i in range(np+1)]
    density=[CP.PropsSI('D','T',T,'P',p,WF) for p in grid[:-1]]+[CP.PropsSI('D','T',T,'Q',1,WF)]
    rho_cond=CP.PropsSI('D','T',C,'Q',0,WF)
    return dict(Te_C=te,Tc_C=tc,T=T,pb=pb+pws,pt=pt,pws=pws,rwv=rho_wv,I=I,qwf=qwf,
                qwater=qwater,qin=qwf+qwater,mu=mu,grid=grid,density=density,rho_cond=rho_cond,
                thermo_residual_Jkg=qwf-q_entropy,water_sensible=water_sensible)

def wf_density(c,p):
    x=p-c['pws'];grid=c['grid'];dens=c['density']
    if x<grid[0]:raise ValueError('pressure below property table')
    if x>=grid[-1]:return dens[-1]
    i=bisect.bisect_right(grid,x)-1;t=(x-grid[i])/(grid[i+1]-grid[i])
    return dens[i]+t*(dens[i+1]-dens[i])

def solve(c,H,D,C0=1.2,vgj=.25,nz=240,acceleration=False,phase_mass=False,extra_dp=0):
    area=math.pi*D*D/4;mf=1e6/c['qin'];dz=H/nz;fric=.02
    def state(p,mc):
        rf=wf_density(c,p);rg=rf+c['rwv'];mwater=mf*c['rwv']/rf
        ml=mc-mwater if phase_mass else mc
        if ml<=0:raise ValueError('nonpositive carrier liquid')
        jg=mf/rf/area;jl=ml/RHO/area
        alpha=jg/(C0*(jg+jl)+vgj)
        if not 0<alpha<1:raise ValueError('invalid void fraction')
        rm=RHO*(1-alpha)+rg*alpha
        momentum=RHO*jl*jl/(1-alpha)+rg*jg*jg/alpha
        return rm,jg+jl,alpha,momentum,mwater,ml
    def grad(p,mc):
        rm,j,alpha,mom,mwater,ml=state(p,mc)
        denom=1.0
        if acceleration:
            dp=5.0;pl=p-dp;ph=min(p+dp,c['pb'])
            dmdp=(state(ph,mc)[3]-state(pl,mc)[3])/(ph-pl)
            denom+=dmdp
            if denom<=.05:raise ValueError('momentum singularity/critical-flow region')
        return -(rm*G+fric*rm*j*j/(2*D))/denom
    def top(mc,trace=False):
        p=c['pb'];points=[]
        try:
            for iz in range(nz):
                if trace:points.append(dict(z_m=iz*dz,p_Pa=p,alpha=state(p,mc)[2],water_vapour_kgs=state(p,mc)[4]))
                k1=grad(p,mc);k2=grad(p+dz*k1/2,mc);k3=grad(p+dz*k2/2,mc);k4=grad(p+dz*k3,mc)
                p+=dz*(k1+2*k2+2*k3+k4)/6
            return p,points
        except ValueError:
            return -1e9,points
    lo,hi=1.,50000.
    if top(lo)[0]<c['pt'] or top(hi)[0]>c['pt']:return None
    for _ in range(40):
        mid=(lo*hi)**.5
        if top(mid)[0]>c['pt']:lo=mid
        else:hi=mid
    mc=(lo*hi)**.5;pout,trace=top(mc,True)
    qdown=mc/RHO;vdown=qdown/area
    dpdown=fric*RHO*vdown*vdown/2*H/D
    dpt=c['pt']+RHO*G*H-c['pb']-dpdown-extra_dp
    Ph=qdown*dpt/1000;gross=Ph*.85*.93;net=gross-5
    am=state(c['pb'],mc);at=state(c['pt'],mc)
    cp=4180.
    return dict(H_m=H,D_m=D,C0=C0,vgj=vgj,Te_C=c['Te_C'],Tc_C=c['Tc_C'],nz=nz,
                acceleration=acceleration,phase_water_mass=phase_mass,water_sensible=c['water_sensible'],
                extra_loop_pressure_loss_Pa=extra_dp,m_WF_kgs=mf,m_carrier_down_kgs=mc,Q_down_m3s=qdown,
                P_hydraulic_kW=Ph,P_gross_electric_kW=gross,P_net_aux5_kW=net,
                turbine_head_m=dpt/(RHO*G),lift_factor=Ph*1000/(mf*c['I']),
                Cmax_NPV0_EUR=net*6538.193661 if net>0 else 0,
                water_vapour_bottom_kgs=am[4],water_vapour_top_kgs=at[4],alpha_bottom=am[2],alpha_top=at[2],
                pressure_residual_Pa=pout-c['pt'],carrier_temperature_drop_K=1e6/(mc*cp),
                WF_gravity_return_min_height_m=(c['pb']-c['pt'])/(c['rho_cond']*G),
                active_riser_volume_m3=area*H,total_vertical_pipe_volume_m3=2*area*H)

def lmtd(a,b):return a if abs(a-b)<1e-10 else (a-b)/math.log(a/b)

def main():
    spec=importlib.util.spec_from_file_location('claude_r3',PEER);peer=importlib.util.module_from_spec(spec);spec.loader.exec_module(peer)
    full=json.loads((ROOT/'DGTE_CLAUDE_VL2_R3_GPT_REPRO_20261020.json').read_text())
    supplied=json.loads((ROOT/'read_cache/DGTE_CLAUDE_VL2_R3_RESULTS_DUAL_20261020.json').read_text())
    comparisons=[]
    for sc,sp in zip(full['scenarios'],supplied['views']['filtered_head_ge_2m']):
        for case,cp in zip(sc['cases'],sp['cases']):
            b=case['best'];errs={}
            for key,pkey,tol in [('H_m','H',1e-9),('D_m','D',1e-9),('Q_l_m3s','Q_l',.00051),('turbine_head_m','head_m',.0051),('lift_eff','lift',.00051)]:
                errs[key]=b[key]-cp[pkey];assert abs(errs[key])<tol,(sc['scenario'],key,errs[key])
            for a,bn in zip(b['P_net_kW_aux2_5_10'],cp['net_aux2_5_10']):assert abs(a-bn)<.05001
            comparisons.append(dict(scenario=sc['scenario'],C0=case['C0'],vgj=case['vgj'],errors=errs,status='PASS_ROUNDING'))
    # Replay the author algorithm without head filter; never edit the source file.
    peer.MIN_HEAD_M=0.0
    unfiltered=peer.run()
    (ROOT/'DGTE_CLAUDE_R3_GPT_REPRO_UNFILTERED_20261020.json').write_text(json.dumps(unfiltered,indent=2)+'\n')
    for sc,sp in zip(unfiltered['scenarios'],supplied['views']['unfiltered']):
        for case,cp in zip(sc['cases'],sp['cases']):
            b=case['best'];assert b['H_m']==cp['H'] and b['D_m']==cp['D']
            assert abs(b['Q_l_m3s']-cp['Q_l'])<.00051
            assert all(abs(a-bn)<.05001 for a,bn in zip(b['P_net_kW_aux2_5_10'],cp['net_aux2_5_10']))
    checks=[];sens=[]
    for name,te,H,D,hotin,hotout in [('S60-F',45,10,.8,60,50),('S90-F',65,40,.6,90,70)]:
        c=props(te)
        for nz in [120,480]:
            checks.append(dict(scenario=name,kind='independent_RK4_same_reduced_physics',result=solve(c,H,D,nz=nz)))
        for accel,phase in [(True,False),(True,True)]:
            checks.append(dict(scenario=name,kind='acceleration_and_phase_mass_sensitivity',result=solve(c,H,D,nz=240,acceleration=accel,phase_mass=phase)))
        for dt in [0,1,2]:
            cs=props(te-dt,water_sensible=True)
            for loss in [0,1000,5000,10000]:
                r=solve(cs,H,D,nz=240,acceleration=True,phase_mass=True,extra_dp=loss)
                if r and dt>0:
                    carrier_low=te;carrier_high=carrier_low+r['carrier_temperature_drop_K']
                    lmh=lmtd(hotin-carrier_high,hotout-carrier_low)
                    r['assumed_min_direct_contact_approach_K']=dt
                    r['UA_direct_contact_required_W_K']=1e6/lmtd(carrier_high-(te-dt),carrier_low-(te-dt))
                    r['source_HX_area_at_U500_m2']=1e6/(500*lmh)
                    r['condenser_area_at_980kW_U500_m2']=980000/(500*lmtd(35-25,35-30))
                sens.append(dict(scenario=name,gas_temperature_reduction_K=dt,result=r))
    out=dict(author='GPT',scope='POST_LOOP_NUMERICAL_VERIFICATION_AND_REDUCED_SENSITIVITY_NOT_PLANT_VALIDATION',
             source_sha256=EXPECTED,CoolProp=CP.get_global_param_string('version'),EOS_revision=CP.get_global_param_string('gitrevision'),
             python=platform.python_version(),timestamp_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             shared_dependencies='same EOS, source states and unvalidated C0/vgj; full peer replay is not independent implementation',
             independent_implementation='Simpson property integral, first-law vs entropy heat identity, RK4 momentum pressure solver',
             peer_summary_comparisons=comparisons,unfiltered_summary='all supplied rounded fields checked',checks=checks,sensitivities=sens,
             exclusions=['dynamic instability','NCG','validated drift closure','separator constitutive relation','finite interfacial heat model','complete condensate/water enthalpy and mixing model','installed cost quote'])
    dest=ROOT/'DGTE_GPT_VL2_VERIFICATION_20261020_R1.json';dest.write_text(json.dumps(out,indent=2)+'\n')
    print('PASS: filtered and unfiltered peer JSON rounding checks',len(comparisons))
    for r in checks:
        b=r['result'];print(r['scenario'],r['kind'],'nz',b['nz'],'net',round(b['P_net_aux5_kW'],5),'head',round(b['turbine_head_m'],5))
    for r in sens:
        b=r['result'];print(r['scenario'],'gas reduction',r['gas_temperature_reduction_K'],'loss kPa',b['extra_loop_pressure_loss_Pa']/1000,'net',round(b['P_net_aux5_kW'],4))

if __name__=='__main__':main()
