# WEBSITE file map

Total files: **31**

- `BD/BD_AIM3.html`
- `BD/BD_AIM3_RHP.html`
- `crp/AC.html`
- `crp/AI8_AGI_Positioning.html`
- `crp/AI8_Architecture.html`
- `crp/AI8_CLV_AIM3_Good_ASI_CouncilSeed_v0_3_REDACTED_PUBLIC.md`
- `crp/AI8_CLV_E0_Repair_Debt.py`
- `crp/AI8_CLV_E0_Repair_Debt_EXPECTED.txt`
- `crp/AI8_CLV_E0_Repair_Debt_MANIFEST.json`
- `crp/AI8_CLV_E0_Repair_Debt_RUN.json`
- `crp/AI8_Companion.html`
- `crp/AI8_Components.html`
- `crp/AI8_Conscious_Love_Valuation.html`
- `crp/AI8_Conscious_Love_Valuation_v0_4_2.html`
- `crp/AI8_Conscious_Love_Valuation_v0_4_2.md`
- `crp/AI8_Conscious_Love_Valuation_v0_4_2_CRPPackage.zip`
- `crp/AI8_Conscious_Love_Valuation_v0_4_2_LICENSE.md`
- `crp/AI8_Conscious_Love_Valuation_v0_4_2_REDACTION_MANIFEST.md`
- `crp/AI8_God_Mode.html`
- `crp/AI8_God_Mode_E0.py`
- `crp/AI8_God_Mode_E0_EXPECTED.txt`
- `crp/AI8_God_Mode_E0_LEDGER.jsonl`
- `crp/AI8_God_Mode_E0_MANIFEST.json`
- `crp/AI8_God_Mode_E0_RUN.json`
- `crp/AI8_Reasoning.html`
- `crp/AIM3_MentalArena_mRHP.html`
- `crp/MDLxDCC.html`
- `crp/index.html`
- `index.html`
- `llms.txt`
- `sitemap.xml`
