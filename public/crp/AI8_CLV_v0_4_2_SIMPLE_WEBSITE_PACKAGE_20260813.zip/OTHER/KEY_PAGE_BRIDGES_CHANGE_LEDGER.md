# AI8 × CLV Key-Page Bridge Integration

**Status:** targeted candidate-bridge release  
**Date:** 2026-08-13  
**Scope:** semantic links and bounded candidate interfaces only; no global architecture rewrite.

## Design decision

The pages remain separate:

- **AI8 Architecture** — the system map and self-selecting governor;
- **From God-Mode Access to Governed Agency** — capability, permissions, continuity, and governed execution;
- **Conscious Love Valuation in AI8** — worth, standing, legitimacy, responsibility, and the route from V0 toward V3 without claiming V4.

The integration therefore adds short reciprocal bridges and clearly labelled candidate interfaces. It does not promote CLV or AIM³-VR into a validated core.

## Exact page changes

1. **AI8_God_Mode.html**
   - Preserved the existing “Improvement according to what?” callout.
   - Added EN/SL CLV card in Sources and Related Work, directly after AI8 Architecture.

2. **AI8_Conscious_Love_Valuation.html**
   - Added an early reciprocal companion-agency bridge to God-Mode.
   - Moved the God-Mode related card directly after AI8 Architecture.

3. **AI8_Architecture.html**
   - Added MDL scope boundary: candidate-description economy, not truth or moral oracle.
   - Added Candidate Power-and-Worth Extension linking God-Mode and CLV as distinct questions.

4. **AI8_Components.html**
   - Added proposed/research-seed component interfaces: CLV, AIM³-VR, Persistent Stake State, Consequence Ledger, Governance Proposal, Legitimacy Gate, Responsibility Ledger.

5. **AI8_AGI_Positioning.html**
   - Added V0–V4 table and the hard boundary: research route toward V3; no V4 claim.

6. **AIM3_MentalArena_mRHP.html**
   - Added optional AIM³-VR bridge while preserving core AIM³/MentalArena modularity.

7. **AI8_Reasoning.html**
   - Added a valuation checkpoint between evidence and consequential action.

8. **AI8_Companion.html**
   - Added relational CLV bridge: consent, non-instrumentalization, truth without manipulation, corrigibility, responsibility, and repair.

9. **BD_AIM3.html**
   - Added optional AIM³-VR module; explicitly not required by core AIM³.

10. **BD_AIM3_RHP.html**
    - Added constitutional boundary: RHP is deliberative and epistemic, not sovereign.

11. **MDLxDCC.html**
    - Narrowed three over-broad MDL formulations.
    - Added explicit MDL/DCC scope boundary and governance-proposal input contract.

12. **AC.html**
    - Added careful epistemic firewall: ontological Conscious Love (X/P) and engineering CLV (H/O) are not the same claim; neither validates the other.

## Deployment note

The current God-Mode and CLV files were taken from the latest local v0.5.1 / v0.4.2 release artifacts. The remaining pages were taken from `BD_web_slim.zip`. Deploy whole files only when they match the current live base; otherwise apply the neutral patches in `PATCHES/` to avoid deleting unrelated newer work.
