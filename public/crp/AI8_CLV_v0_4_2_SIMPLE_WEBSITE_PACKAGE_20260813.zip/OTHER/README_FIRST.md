# AI8 CLV v0.4.2 — preprost website paket

V ZIP-u sta samo dve mapi.

## WEBSITE

To je edina mapa za website. Njena struktura je enaka strukturi `www.MDLxDCC.org`.

Kopiraj **vsebino** mape `WEBSITE/` v korensko mapo spletne strani in ohrani podmape:

```text
WEBSITE/index.html       → /index.html
WEBSITE/llms.txt         → /llms.txt
WEBSITE/sitemap.xml      → /sitemap.xml
WEBSITE/crp/...          → /crp/...
WEBSITE/BD/...           → /BD/...
```

V njej so vse datoteke, ki jih je treba objaviti za ta release:

- CLV in God-Mode kanonični strani;
- zamrznjeni CLV v0.4.2 paper;
- CLV in God-Mode E0 artefakti;
- javni CLV release ZIP pod pravilnim imenom;
- root index, CRP index, llms.txt in sitemap.xml;
- posodobljene ključne AI8, AIM³, RHP, MDL×DCC in AC strani.

Javni ZIP mora na strežniku ostati poimenovan natanko:

```text
/crp/AI8_Conscious_Love_Valuation_v0_4_2_CRPPackage.zip
```

Pred uploadom naredi backup trenutnega websitea. Če si po 13. avgustu 2026 ročno spreminjal `/crp/index.html`, `/llms.txt` ali `/sitemap.xml`, te tri datoteke pred overwriteom hitro primerjaj, da ne izgubiš poznejših nepovezanih vnosov.

## OTHER

Ta mapa ni za upload. Vsebuje samo README, change ledgerje, validacije, browser teste, odprta ustavna vprašanja in SHA-256 manifeste.

Stari trije izvorni ZIP paketi, patch gozd in podvojene deployment mape niso vključeni.

## Prednost različic

Živi strani:

```text
/crp/AI8_God_Mode.html
/crp/AI8_Conscious_Love_Valuation.html
```

Zamrznjeni CLV release:

```text
/crp/AI8_Conscious_Love_Valuation_v0_4_2.html
```

Živa CLV stran vsebuje najnovejši recipročni most proti God-Mode. Versioned HTML ostaja natančen zamrznjeni release artefakt.
