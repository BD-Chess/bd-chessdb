# AI8 Conscious Love Valuation v0.4.2 — Site Integration Change Ledger

**Release type:** discovery-chain correction and merge-safe site integration  
**Conceptual scope:** no expansion of CLV or AI8 God‑Mode  
**Date:** 2026-08-13

## 1. Root `index.html`

- Preserved the existing flagship order:
  1. AI8 God‑Mode → Governed Agency
  2. Conscious Love Valuation — Worth Constitution for AI8
- Normalized every God‑Mode route in the root card, detailed index entry, search corpus, and JSON‑LD `ItemList` to:

```text
/crp/ai8_god_mode
```

- Preserved the CLV lowercase extensionless route:

```text
/crp/ai8_conscious_love_valuation
```

- Kept `ItemList` positions consecutive.
- Added no new ethics essay or duplicate CLV explanation to the root atlas.

## 2. `/crp/AI8_God_Mode.html`

- Preserved the compact EN/SL bridge:

> Improvement according to what?

- Did not add a new numbered section or broaden the conceptual content.
- Normalized God‑Mode canonical, Open Graph URL, JSON‑LD `@id` / `url`, and `ai8-genesis-spec.canonical_url` to:

```text
https://www.mdlxdcc.org/crp/ai8_god_mode
```

- Updated `project-glossary.document_version` from `0.5` to `0.5.1`.
- Preserved all Genesis Arena, Permission DCC, safety-gate, glossary, provenance, and Code Capsule content.

## 3. `/crp/index.html`

The candidate merged CRP hub now places the AI8 sequence in this order:

```text
AI8 Architecture
AI8 God‑Mode
AI8 Conscious Love Valuation
AI8 Components
AI8 AGI Positioning
```

- Added the missing God‑Mode card directly before CLV.
- Preserved the current APSV card in the physical-engineering group.
- Added narrow responsive wrapping rules so long paper titles and paths do not create horizontal overflow at 320 px or 280 px.
- No unrelated baseline links were removed in the candidate merge.

**Deployment rule:** this full file remains merge-sensitive. Diff or apply the supplied snippet/patch to the current live CRP hub; do not blindly overwrite a newer live file.

## 4. `llms.txt`

Added immediately before CLV:

```text
- AI8 God-Mode → Governed Agency — Permission DCC, computational
  continuity, Genesis Arena, and the boundary between access, agency,
  persistence, and consciousness —
  /crp/ai8_god_mode
```

The CLV entry follows directly after it.

**Deployment rule:** merge into the current live `llms.txt` and preserve unrelated newer entries.

## 5. `sitemap.xml`

Added immediately before the CLV URL:

```xml
<url>
  <loc>https://www.mdlxdcc.org/crp/ai8_god_mode</loc>
  <lastmod>2026-08-13</lastmod>
  <changefreq>monthly</changefreq>
  <priority>0.90</priority>
</url>
```

**Deployment rule:** merge into the current live sitemap and preserve unrelated newer URLs.

## 6. Merge support

The integration package contains:

- full candidate files for inspection;
- neutral unified patches;
- minimal merge snippets for CRP hub, `llms.txt`, and `sitemap.xml`;
- an explicit APSV preservation snippet;
- browser and structural validation reports.

No patch contains local `/mnt/data/...` paths.

## 7. Validation

- Root, CRP hub, and God‑Mode HTML parse successfully.
- No duplicate IDs.
- All internal anchors resolve.
- Inline JavaScript passes Node syntax validation.
- Root JSON‑LD positions are consecutive.
- God‑Mode precedes CLV in root, CRP hub, `llms.txt`, and `sitemap.xml`.
- God‑Mode canonical metadata is internally consistent.
- God‑Mode glossary version is `0.5.1`.
- EN/SL CLV bridge remains present.
- Browser tests pass at 1440, 390, 360, 320, and 280 px.
- God‑Mode font controls pass at 100% and 140%.
- Maximum horizontal overflow: `0 px`.
- Console errors: `0`.
