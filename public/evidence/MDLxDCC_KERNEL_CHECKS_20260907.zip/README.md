# MDL×DCC cross-domain controller receipt — PUBLIC SAFE

This public package intentionally contains **no project source code**.

It records:
- finite conformance test names and counts;
- PASS/FAIL status;
- SHA-256 identities of the internally audited source snapshots;
- scope limitations.

The original source snapshots and executable conformance harness remain private.
This is sufficient to publish the audit receipt without publishing the implementation.
