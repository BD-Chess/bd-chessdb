# MDL×DCC TSP tour evidence — PUBLIC SAFE

Included:
- public benchmark instance files used by the verifier;
- final audited tour artifacts;
- a standalone verifier;
- a sanitized result receipt.

Intentionally excluded:
- internal checkpoints;
- generation histories;
- feature maps;
- branch/recipe configuration;
- budget contracts;
- elite memory;
- private search-source code.

Run:

`python verify_tours_public.py`
