"""Public-safe independent TSPLIB EUC_2D verifier. No project solver code."""
from pathlib import Path
from decimal import Decimal
from math import isqrt
import json, hashlib, struct

BASE = Path(__file__).resolve().parent
DATA = json.loads((BASE / "independent_tour_verification_public.json").read_text())

def coords_for(name):
    p = BASE / "instances" / f"{name}.tsp"
    rows=[]; on=False
    for line in p.read_text().splitlines():
        if line.strip()=="NODE_COORD_SECTION":
            on=True; continue
        if not on: continue
        t=line.split()
        if not t or t[0]=="EOF": break
        rows.append((int(t[0]), Decimal(t[1]), Decimal(t[2])))
    assert [r[0] for r in rows] == list(range(1,len(rows)+1))
    digits=max(max(0,-v.as_tuple().exponent) for r in rows for v in r[1:])
    scale=10**digits
    return [(int(x*scale), int(y*scale)) for _,x,y in rows], scale

def read_tour(p):
    body=p.read_text().split("TOUR_SECTION",1)[1]
    out=[]
    for tok in body.split():
        if tok in ("-1","EOF"): break
        out.append(int(tok)-1)
    return out

for rec in DATA["checks"]:
    coords,scale=coords_for(rec["instance"])
    tour=read_tour(BASE/"tours"/rec["tour_artifact"])
    n=len(coords)
    assert len(tour)==n and set(tour)==set(range(n))
    length=0
    for i,a in enumerate(tour):
        b=tour[(i+1)%n]
        dx=coords[a][0]-coords[b][0]
        dy=coords[a][1]-coords[b][1]
        ss=dx*dx+dy*dy
        q=isqrt(ss)//scale
        if 4*ss >= scale*scale*(2*q+1)**2:
            q+=1
        length+=q
    assert length==rec["recomputed_length"], (rec["label"], length, rec["recomputed_length"])
    print(rec["label"], length, "PASS")
print("TOTAL", len(DATA["checks"]), "PASS")
