# RouteSignal Scout — allocating expert attention

RSS illustrates a smaller but useful role: arranging observations into an explainable order for human review. The inspected generation compares cases in their context and considers evidence quality rather than simply ranking raw activity.

This applies the broader research-economy idea to human attention. A reviewer receives reasons to inspect a case and indications of what evidence is still missing; the ranking is not itself an incident determination.

**Implementation depth.** The retained review describes a fixed ranking policy. It does not establish a learned feedback loop that updates the policy from operator outcomes, nor a literal full MDL coding objective. RSS is therefore a partial attention-ranking member of the architectural family, not the same online controller as TSP.

**Evidence boundary.** The older source review is preserved internally. The newer archive was not executed in that review, and no original RSS implementation is bundled or newly tested here. A changed ranking alone does not prove greater usefulness to its human operator.


---
**Record:** P03 · **Summary version:** 3 · **Date:** 2026-09-07.
Derived from a retained project-review record; see [the provenance register](../PROVENANCE.json) and [the disclosure scope](../DISCLOSURE_AND_EVIDENCE_SCOPE.md).
