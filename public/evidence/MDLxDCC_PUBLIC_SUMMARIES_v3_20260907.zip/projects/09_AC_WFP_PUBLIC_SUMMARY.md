# AC–WFP — discovering what should count as a part

AC–WFP adds a question that comes before choosing among existing specialists: can useful, stable units of organization be discovered rather than assumed in advance?

The operational whole-first arena investigates candidate organizations using description costs and separate tests of prediction, recovery, stability and representation robustness. Its valuable contribution is a noncompensating verifier: strength on one required axis cannot simply pay away failure on another. A short description is a candidate explanation, not permission to redefine success.

The retained audit describes real candidate-encoding and evaluation machinery, while also identifying an incomplete connection between proposal-stage resource accounting and final scoring. Cross-arm online DCC allocation is deferred in the reviewed generation. The possible transfer to AI8 is discovery and certification of modules; that transfer is still a research proposal.

AC itself is a serious philosophical hypothesis about presence, not merely a decorative label. Its relationship to whole-first research can remain intellectually important without treating finite computational results as a proof of consciousness or the nature of reality.

**Evidence boundary.** Historical finite-world results and their limitations remain in the internal review. The current collection retains source excerpts, check records and scripts, but not the full original arena and run inputs. This v3 packaging audit did not repeat those scientific experiments. No implementation listings, evaluator thresholds or hidden data are released here.


---
**Record:** P09 · **Summary version:** 3 · **Date:** 2026-09-07.
Derived from a retained project-review record; see [the provenance register](../PROVENANCE.json) and [the disclosure scope](../DISCLOSURE_AND_EVIDENCE_SCOPE.md).
