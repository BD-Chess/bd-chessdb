# DNA / FASTA / AMR — three connected but distinct roles

The DNA work contains three separate technical questions: storing a sequence accurately, finding economical explanations of its structure, and choosing interventions in an abstract simulation. They should not be collapsed into one biological claim.

The discovery tools compare candidate descriptions with what those descriptions leave unexplained. They progressively direct effort toward candidates that warrant stronger checks. A particularly useful methodological distinction is between testing a frozen model on null data and allowing the whole search procedure to fit null data again. The latter asks how easily the search itself can produce attractive apparent findings.

The compression line supplies a literal reconstruction objective, while AMR supplies a separate history-dependent controller in an abstract simulator. The older discovery pipeline is an organizational and description-economy connection; it is not the same online numerical controller as TSP.

**Evidence boundary.** The retained source audit identifies version-specific defects in an older codec, candidate selection and simulation resumability. Those defects remain recorded rather than erased. Later compression reports and generator-validation papers must remain bound to their own versions. The v3 check confirmed consistency of the saved observations; it did not rerun genomic campaigns or establish biological, clinical or protein-level efficacy. Implementation source, parameter grids and reconstruction recipes are not published in this summary.


---
**Record:** P04 · **Summary version:** 3 · **Date:** 2026-09-07.
Derived from a retained project-review record; see [the provenance register](../PROVENANCE.json) and [the disclosure scope](../DISCLOSURE_AND_EVIDENCE_SCOPE.md).
