# APSV — engineering design search with explicit costs

APSV explores alternative physical designs across operating contexts instead of optimizing only one fixed concept. Its retained review describes an explicit engineering cost ledger alongside mission performance, conventional reference designs, protected search lanes and opportunities to reconsider dormant ideas.

The MDL connection is substantive but should be named accurately: description-inspired engineering economics. It weighs the complexity and resource implications of a design; it is not a literal compressed physical vehicle or a universal prefix-code construction.

The allocation layer is currently strongest as staged research organization. The reviewed generation does not establish a fully closed-loop governor that continuously learns how to reassign effort across research lanes. Such a controller is a plausible extension, not an implementation claim to add retroactively.

**Evidence boundary.** The available material here is the retained APSV review, not its complete arena source or a physical prototype. Simulation and engineering research can be valuable without being represented as experimental vehicle validation. This summary releases no search weights, control settings, detailed mechanism recipes or unpublished designs.


---
**Record:** P07 · **Summary version:** 3 · **Date:** 2026-09-07.
Derived from a retained project-review record; see [the provenance register](../PROVENANCE.json) and [the disclosure scope](../DISCLOSURE_AND_EVIDENCE_SCOPE.md).
