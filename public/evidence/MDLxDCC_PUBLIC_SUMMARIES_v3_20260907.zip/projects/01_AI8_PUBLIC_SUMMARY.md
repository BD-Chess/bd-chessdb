# AI8 — research work as the controlled object

AI8's useful contribution is durable research organization: competing proposals, explicit resource records, separated evaluation, and retained evidence across work sessions. The review describes executable governance rather than only an aspirational diagram.

MDL-related economics appears here primarily as explicit cost and evidence accounting. The broader control pattern governs which research step happens next, while validity remains with the declared tests and evaluators. This is an organizational implementation, not a claim that every research task imports the same numerical controller used in an optimizer.

The cross-domain lesson is practical: an architecture can govern investigations as well as solver moves. A useful discovery, an unresolved disagreement and a condition for reopening a branch can survive beyond the model or session that produced them.

**Evidence boundary.** This public summary derives from the retained AI8 review. Original governance implementations and tests are not distributed here or newly rerun in the v3 package check. The summary does not establish general superiority of the research workflow or conscious AI.


---
**Record:** P01 · **Summary version:** 3 · **Date:** 2026-09-07.
Derived from a retained project-review record; see [the provenance register](../PROVENANCE.json) and [the disclosure scope](../DISCLOSURE_AND_EVIDENCE_SCOPE.md).
