# TSP / TSPES — adaptive optimization with checked outputs

The optimization lineage provides a concrete combination of search control, alternative representations, retained candidates and verification in the original problem. It includes a direct algorithmic bridge to a compression-search branch; their domain actions differ while specific control primitives are shared.

Selected retained outputs include a route of 79,114 for uy734, matching the supplied optimal reference; 95,348 for zi929, three units above its reference; and 96,780 for nu3496 against the supplied reference of 96,132. Eleven selected routes were rechecked during this v3 audit using the retained, separate tour verifier. The resulting record is byte-identical to the earlier check.

The important architectural idea is that search can revise its next problem representation, not merely keep a better scalar score. Retaining complementary paths also allows a simple route to remain useful alongside more elaborate alternatives.

**Evidence boundary.** Route legality and length are artifact claims. They do not isolate the contribution of a controller or show superiority over every solver. Supplied optimal references are not reproved here. This public summary releases neither solver source, numerical update rules, search settings nor internal checkpoints. The full retained evidence is available only in the separate internal collection.


---
**Record:** P02 · **Summary version:** 3 · **Date:** 2026-09-07.
Derived from a retained project-review record; see [the provenance register](../PROVENANCE.json) and [the disclosure scope](../DISCLOSURE_AND_EVIDENCE_SCOPE.md).
