# Private trading research — public architectural note

The private project uses MDL×DCC-related ideas in more than one role: as a standalone research approach and as a component or supervisory layer within a broader system of domain specialists. Its contribution to the cross-domain discussion is role separation, not a public trading recipe.

A specialist may identify an opportunity, while a different layer chooses whether that specialist should act or receive resources. A framework can also investigate alternative configurations without itself being the best direct predictor.

The general research rule is to evaluate the resulting system rather than protect a named component. Retaining a simpler alternative is a useful outcome, but its performance must be credited to the mechanism actually used; it is not automatic evidence that an omitted controller added value.

**Privacy and evidence boundary.** This note releases no strategy names, source-module names, instruments, market-specific comparisons, signal definitions, entry or exit rules, timings, parameter values, position formulas, account configuration or profit figures. It neither certifies profitability nor supplies a reproducible trading method. The underlying private review remains solely in the internal collection.


---
**Record:** P06 · **Summary version:** 3 · **Date:** 2026-09-07.
Derived from a retained project-review record; see [the provenance register](../PROVENANCE.json) and [the disclosure scope](../DISCLOSURE_AND_EVIDENCE_SCOPE.md).
