# 8Z / 8zipLab — reusable control and complete-artifact economics

The strongest direct bridge in this review tour is between TSPES and a recipe-search generation of 8zipLab. The retained implementations share four control-law families. Finite conformance checks, including 8,191 binary histories and sequential state tests, were repeated in this v3 audit and produced a byte-identical result record. This establishes a specific implementation relationship, not identity of the whole applications.

A separate native archive result is also valuable. The retained audit reports exact restoration of 320 files and a complete archive size of 18,275,337 bytes versus a bundled controlled alternative of 18,374,488 bytes: a difference of 99,151 bytes. The specified corpus includes real and controlled examples. Full-size accounting includes overhead rather than highlighting only an attractive payload.

These are two different positive findings. The native archive's entire size advantage is not attributed to the older shared-controller branch. Audio records separately report exact-sample checks on short synthetic fixtures, not a new music-corpus benchmark.

**Evidence boundary.** Only the finite controller checks were newly rerun for v3. The large archive comparison and audio checks remain retained prior results. Public material does not include encoder recipes, controller thresholds, source listings, private corpus trees or state traces. A result for one corpus is not a universal compression claim.


---
**Record:** P05 · **Summary version:** 3 · **Date:** 2026-09-07.
Derived from a retained project-review record; see [the provenance register](../PROVENANCE.json) and [the disclosure scope](../DISCLOSURE_AND_EVIDENCE_SCOPE.md).
