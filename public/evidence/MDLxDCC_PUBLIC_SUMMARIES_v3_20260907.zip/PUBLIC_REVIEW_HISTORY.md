# Review history and scope

An initial public-only review was followed by a tour of project materials. Later reviews identified concrete implementations and, in some domains, directly comparable algorithmic components. The current summaries retain that expanded understanding rather than treating the initial public-only assessment as the final code-audit verdict.

The original detailed review and internal handoffs remain in the internal archive. They are not reproduced wholesale here: later documents qualify some older numerical and interpretation claims, and full handoffs can expose implementation detail.

This v3 release changes packaging, disclosure and evidence indexing. It does not claim that every project has received a new independent review, a fresh benchmark run or an external replication.
