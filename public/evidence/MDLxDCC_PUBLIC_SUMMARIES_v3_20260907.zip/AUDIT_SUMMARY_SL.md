# Kaj je popravljeno v javnem paketu v3

Prejšnji PUBLIC_SAFE ni bil dovolj očiščen: poleg javnega trading povzetka je vseboval dobesedne izvlečke druge raziskovalne kode. Zato novi paket ni kopija internega arhiva z eno odstranjeno datoteko, temveč ločeno sestavljen in pregledan nabor povzetkov.

Izključeni so vsi source receipts, podrobni izvirni handoffi, izvedbena koda, nastavitve krmilnikov, recepti iskanja, notranji checkpointi, zasebna drevesa korpusov ter konkretni trading podatki. Namesto njih so vključeni novi povzetki vseh devetih obiskanih projektnih področij, skupna karta z AC–WFP in jasen zapis dokaznega obsega.

Pozitivni dosežki ostanejo vidni. Posebej je ohranjen konkretni prenos med TSP in 8zipLab, vendar je ločen od merjenja uspešnosti celotnih aplikacij. Rezultati in izvedbe različnih generacij niso združeni v navidezno eno univerzalno meritev.

CRC in manifesti starih paketov so bili pravilni; napaka je bila predvsem v razkritju in popolnosti prilog, ne v poškodovanih ZIP-ih. Novi paket se pred izdajo ponovno preveri po čisti razširitvi. To ne pomeni nove ponovitve vseh projektnih poskusov.

**Za javno deljenje uporabi v3 PUBLIC_SAFE. V2 PUBLIC_SAFE ne objavljaj.** Interni paket ima drugačen namen in se ne nalaga na javno spletno mesto.
