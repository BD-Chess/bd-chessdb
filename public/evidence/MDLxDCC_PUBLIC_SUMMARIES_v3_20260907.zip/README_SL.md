# MDL×DCC — PUBLIC SAFE v3

**Datum:** 7. september 2026. **Namen:** javno deljenje arhitekturnih povzetkov. **Ne vsebuje zasebnega trading audita ali izvorne raziskovalne kode.**

To je nov, vsebinsko očiščen javni komplet, ne zgolj interni paket brez trading dokumenta. Podrobni izvirniki ostanejo v ločenem INTERNAL_FULL. Oznaka »public safe« pomeni pregledano omejitev vsebine, ne zagotovila, da iz objavljenih idej ni mogoče ničesar izvedeti.

## Projektni povzetki

- [AI8](projects/01_AI8_PUBLIC_SUMMARY.md)
- [TSP](projects/02_TSP_PUBLIC_SUMMARY.md)
- [RSS](projects/03_RSS_PUBLIC_SUMMARY.md)
- [DNA](projects/04_DNA_PUBLIC_SUMMARY.md)
- [8Z](projects/05_8Z_PUBLIC_SUMMARY.md)
- [Trading](projects/06_TRADING_PUBLIC_SUMMARY.md)
- [APSV](projects/07_APSV_PUBLIC_SUMMARY.md)
- [ARC](projects/08_ARC_PUBLIC_SUMMARY.md)
- [AC_WFP](projects/09_AC_WFP_PUBLIC_SUMMARY.md)

## Skupna dokumentacija

- [Skupna karta v3](CROSS_PROJECT_LEDGER_PUBLIC_v3.md)
- [Popravki javnega paketa](AUDIT_SUMMARY_SL.md)
- [Meja razkritja in dokazov](DISCLOSURE_AND_EVIDENCE_SCOPE.md)
- [Zgodovina pregledov](PUBLIC_REVIEW_HISTORY.md)
- [Provenienca povzetkov](PROVENANCE.json)
- [Manifest datotek](MANIFEST.json)
- [Končna preverba paketa](VERIFY_RESULT.json)

Sudoku in 8zCoding še nimata zaključenega namenskega pregleda te turneje; to ne izničuje njunih že dokumentiranih rezultatov. Monografija v1.4 je ločen dokument. Ta ZIP ne nadomešča objavne mape spletne strani.

Prejšnjega v2 PUBLIC_SAFE ne objavljaj. Če je že dostopen javno, ga odstrani ali nadomesti tudi na dejanskem mestu objave.
