# Disclosure and evidence scope — v3

This package is a deliberately limited publication set. It contains reviewed prose and a small provenance register. It does not contain source-receipt documents, implementation listings, detailed search recipes, numerical controller traces, internal checkpoints or raw private experiment records. The trading contribution is restricted to general architectural roles.

The previous v2 PUBLIC_SAFE archive was incorrectly classified: it retained implementation excerpts. Do not publish that earlier archive as a safe substitute for this one. If it was already uploaded, creating this new archive does not remove the old copy from any server or recipient.

## What the summaries establish

Each summary is an account derived from a retained project review. Source hashes identify that review document. They neither independently prove its scientific claims nor give a reader the ability to reproduce withheld-source experiments.

During the v3 file audit, retained TSP tour/primitive checks and the cross-domain compression-controller conformance check were rerun in separate internal copies. Their result records matched the saved versions. Consistency of saved DNA observations was checked without redoing all of its source tests.

Other results remain historical evidence from their stated project reviews. No long campaign was rerun for this packaging exercise. Source code and primary input availability differ by project; the individual notes say where evidence is limited to a retained review.

## What is intentionally retained

The release preserves high-level mechanisms, useful architectural lessons and selected already-described aggregate artifact results. It is not a claim that no technical idea can be inferred from public prose. Its boundary is withholding executable/reconstructive implementation detail and private strategy information, not making ideas impossible to learn from.

AC and consciousness remain serious research questions. Software or finite-world results are not treated as proof of an ontology, phenomenal consciousness or general intelligence.

## Archive verification

MANIFEST.json records every payload file's size, SHA-256 and SHA3-256; it excludes itself to avoid circular hashing. Archive hashes are supplied separately with the release. These detect changes relative to the recorded release, not malicious replacement of both an archive and its manifest, and are not external signatures.

This is an audit-summary archive, not a website deployment package.
