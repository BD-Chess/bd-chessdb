# Cross-project architecture map — public summary v3

**Date:** 7 September 2026. The map covers reviewed historical versions. It is not a live performance scoreboard.

| Project | Useful contribution | Relationship to the broader architecture |
|---|---|---|
| AI8 | Durable work and evidence governance | Organizational implementation |
| TSP / TSPES | Adaptive search and feedback into representations | Concrete control primitives and domain execution |
| RSS | Explainable allocation of human review attention | Partial organization; fixed ranking policy |
| DNA / FASTA | Competing structural descriptions and reconstruction objectives | Description economics plus staged verification |
| AMR | Feedback-driven intervention selection in an abstract model | Domain-specific controller contract, not biological validation |
| 8Z / 8zipLab | Whole-artifact economics and a direct TSP control bridge | Specific shared algorithms; multiple separate codec branches |
| Private trading | Standalone research and supervision of specialists | Abstract role separation only; operational detail withheld |
| APSV | Cost-aware physical-design exploration | Engineering economics and staged allocation |
| ARC-AGI | Representation, reasoning-mode and compute choice | Interactive control and governor-configuration research |
| AC–WFP | Discovery and evaluation of effective organization | MDL-related candidate scoring and layered verification |

Sudoku/R6 and 8zCoding are connected research lines whose dedicated source inspections were not completed in this tour. That is a boundary of this collection, not a statement that their earlier documented work does not exist.

## Two distinct questions

What transferred can be source, an algorithm, a controller contract or a research organization. Whether it helped requires the corresponding artifact or comparative evidence. Implementation depth and demonstrated benefit are separate axes.

The TSP–8zipLab relationship has specific finite conformance evidence. It should not be diluted into a mere shared slogan, or inflated into a universal performance theorem. Some other projects implement only selected parts of the broader organization.

A simpler specialist may be a useful research outcome. Its success does not become evidence for a component removed from that specialist. Likewise, preserving an alternative is not the same as deciding to activate it now.

The AC hypothesis remains a serious source of questions, while operational whole-first findings and claims about experience require distinct evidence.

Read the [project index](README_SL.md), [evidence scope](DISCLOSURE_AND_EVIDENCE_SCOPE.md) and [provenance register](PROVENANCE.json) for the limits of each summary.
