TSP NU3496 INDEPENDENT VERIFY / EXPORT / VIEW KIT
=================================================

Install: extract these files directly into:
  D:\8Z\8z\8zA\dev2_cpu_gpu

Run anytime (also safe while a long arena variant is running):
  RUN_305_NU3496_VERIFY_EXPORT_VIEW_CURRENT_BEST_NO_PAUSE.bat

The script does NOT import the arena code. It independently:
  1. parses the original nu3496.tsp;
  2. checks that a tour contains every city ID exactly once;
  3. computes every edge with exact TSPLIB EUC_2D rounding;
  4. includes the closing edge from last city back to first;
  5. compares claimed and recomputed length;
  6. exports the best valid complete tour.

Output folder contains:
  *.tour                portable TSPLIB TOUR format, 1-based node IDs
  *_verification.json   length, gap, hash, validity and provenance
  *.csv                 ordered coordinates
  *_route.svg           static route drawing
  *_interactive.html    standalone pan/zoom browser viewer
  all_validated_candidates.json

Important:
  nu3496 has 3,496 city IDs but only 2,373 distinct coordinates. Duplicate
  coordinates are part of the official instance and are valid; city ID
  uniqueness, not coordinate uniqueness, defines a legal tour.

To validate an externally downloaded optimal tour:
  RUN_306_NU3496_VERIFY_SPECIFIC_TOUR_NO_PAUSE.bat C:\path\nu3496_opt.tour
