@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PY=D:\8Z\.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=C:\8Z\tools\.8zvenv\Scripts\python.exe"
if not exist "%PY%" set "PY=python"

echo ==============================================================================
echo NU3496 independent verifier + TSPLIB tour export + HTML/SVG viewer
echo Reads current DEV2.1/DEV2 outputs and selects the shortest complete valid tour.
echo This is read-only and is safe while the arena is running.
echo ==============================================================================
"%PY%" TSP_VERIFY_EXPORT_VIEW.py --tsp "..\tsplib_folder\nu3496.tsp" --root "." --out-root "exports"
set "RC=%ERRORLEVEL%"
echo ==============================================================================
echo DONE. ERRORLEVEL=%RC%
echo Open the newest exports\NU3496_8ZRP_*\*_interactive.html file.
echo ==============================================================================
exit /b %RC%
