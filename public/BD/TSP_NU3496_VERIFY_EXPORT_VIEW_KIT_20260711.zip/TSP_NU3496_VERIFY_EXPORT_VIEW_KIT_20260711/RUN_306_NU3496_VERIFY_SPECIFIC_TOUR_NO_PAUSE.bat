@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if "%~1"=="" (
  echo Usage: %~nx0 path_to_tour_or_json
  exit /b 2
)
set "PY=D:\8Z\.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=C:\8Z\tools\.8zvenv\Scripts\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" TSP_VERIFY_EXPORT_VIEW.py --tsp "..\tsplib_folder\nu3496.tsp" --tour-source "%~1" --root "." --out-root "exports"
set "RC=%ERRORLEVEL%"
echo DONE. ERRORLEVEL=%RC%
exit /b %RC%
