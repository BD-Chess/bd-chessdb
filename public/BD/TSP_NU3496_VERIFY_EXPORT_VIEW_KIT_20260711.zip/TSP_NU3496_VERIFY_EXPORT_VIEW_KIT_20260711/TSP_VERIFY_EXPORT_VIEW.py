#!/usr/bin/env python3
"""Independent TSPLIB EUC_2D tour validator, exporter, and HTML/SVG viewer.

Standard-library only. It intentionally does not import the 8Z-RP arena code.
It can auto-discover the best full tour in current DEV2/DEV2.1 outputs, validate
it against the original .tsp coordinates, and export portable artifacts.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import math
import os
from pathlib import Path
from datetime import datetime
from typing import Any, Iterable

VERSION = "TSP Verify/Export/View v1.0 (2026-07-11)"


def parse_decimal_scaled(s: str, decimals: int) -> int:
    s = s.strip()
    sign = -1 if s.startswith("-") else 1
    if s[:1] in "+-":
        s = s[1:]
    if "." in s:
        a, b = s.split(".", 1)
    else:
        a, b = s, ""
    a = a or "0"
    b = (b + "0" * decimals)[:decimals]
    return sign * (int(a) * (10 ** decimals) + (int(b) if b else 0))


def parse_tsplib(path: Path) -> dict[str, Any]:
    name = "unknown"
    dim = None
    ewt = None
    raw: dict[int, tuple[str, str]] = {}
    in_coords = False
    max_dec = 0
    for raw_line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        upper = line.upper()
        if upper == "NODE_COORD_SECTION":
            in_coords = True
            continue
        if upper == "EOF":
            break
        if not in_coords:
            if ":" in line:
                k, v = line.split(":", 1)
                k, v = k.strip().upper(), v.strip()
            else:
                parts = line.split(maxsplit=1)
                if len(parts) != 2:
                    continue
                k, v = parts[0].strip().upper(), parts[1].strip()
            if k == "NAME":
                name = v
            elif k == "DIMENSION":
                dim = int(v)
            elif k == "EDGE_WEIGHT_TYPE":
                ewt = v.upper()
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        idx = int(parts[0])
        xs, ys = parts[1], parts[2]
        for v in (xs, ys):
            if "." in v:
                max_dec = max(max_dec, len(v.split(".", 1)[1]))
        raw[idx] = (xs, ys)
    if dim is None:
        raise ValueError(f"DIMENSION missing in {path}")
    if ewt != "EUC_2D":
        raise ValueError(f"Only EDGE_WEIGHT_TYPE EUC_2D is supported, got {ewt!r}")
    if len(raw) != dim:
        raise ValueError(f"Expected {dim} coordinates, found {len(raw)}")
    scale = 10 ** max_dec
    coords_scaled: list[tuple[int, int]] = []
    coords_float: list[tuple[float, float]] = []
    for node_id in range(1, dim + 1):
        xs, ys = raw[node_id]
        coords_scaled.append((parse_decimal_scaled(xs, max_dec), parse_decimal_scaled(ys, max_dec)))
        coords_float.append((float(xs), float(ys)))
    return {
        "name": name,
        "dimension": dim,
        "edge_weight_type": ewt,
        "scale": scale,
        "coords_scaled": coords_scaled,
        "coords_float": coords_float,
    }


def euc2d_exact(a: tuple[int, int], b: tuple[int, int], scale: int) -> int:
    """Exact TSPLIB nint(sqrt(dx^2+dy^2)/scale), no floating-point rounding."""
    dx = a[0] - b[0]
    dy = a[1] - b[1]
    d2 = dx * dx + dy * dy
    if d2 == 0:
        return 0
    base = math.isqrt(d2) // scale
    # nearest integer, ties upward: distance >= base + 0.5
    if 4 * d2 >= ((2 * base + 1) ** 2) * (scale ** 2):
        return base + 1
    return base


def canonical_cycle(tour: list[int]) -> list[int]:
    if not tour:
        return []
    m = min(tour)
    i = tour.index(m)
    fwd = tour[i:] + tour[:i]
    rev = list(reversed(tour))
    j = rev.index(m)
    bwd = rev[j:] + rev[:j]
    return fwd if tuple(fwd) <= tuple(bwd) else bwd


def tour_sha256(tour: list[int]) -> str:
    can = canonical_cycle(tour)
    return hashlib.sha256(",".join(map(str, can)).encode("ascii")).hexdigest()


def tour_length(tour: list[int], coords: list[tuple[int, int]], scale: int) -> int:
    total = 0
    n = len(tour)
    for i, u in enumerate(tour):
        v = tour[(i + 1) % n]
        total += euc2d_exact(coords[u], coords[v], scale)
    return total


def normalize_tour(values: Iterable[Any], n: int) -> list[int]:
    tour = [int(x) for x in values]
    if len(tour) == n + 1 and tour[0] == tour[-1]:
        tour = tour[:-1]
    vals = set(tour)
    if len(tour) == n and vals == set(range(n)):
        return canonical_cycle(tour)
    if len(tour) == n and vals == set(range(1, n + 1)):
        return canonical_cycle([x - 1 for x in tour])
    raise ValueError(
        f"Tour is not a permutation of 0..{n-1} or 1..{n}; "
        f"len={len(tour)}, unique={len(vals)}, min={min(tour) if tour else None}, max={max(tour) if tour else None}"
    )


def parse_tour_file(path: Path, n: int) -> tuple[list[int], dict[str, Any]]:
    vals: list[int] = []
    in_sec = False
    for raw_line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        upper = line.upper()
        if upper == "TOUR_SECTION":
            in_sec = True
            continue
        if upper == "EOF" or line == "-1":
            break
        if in_sec:
            vals.extend(int(x) for x in line.replace(",", " ").split())
    if not in_sec:
        vals = []
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            for token in line.replace(",", " ").split():
                try:
                    vals.append(int(token))
                except ValueError:
                    pass
    return normalize_tour(vals, n), {"source_type": "tour_file", "declared_length": None}


def extract_candidates_from_json(data: Any, source: Path, n: int) -> list[tuple[list[int], dict[str, Any]]]:
    out: list[tuple[list[int], dict[str, Any]]] = []

    def add(values: Any, meta: dict[str, Any]) -> None:
        if not isinstance(values, list):
            return
        try:
            t = normalize_tour(values, n)
        except Exception:
            return
        m = dict(meta)
        m["source_type"] = "json"
        m["source_path"] = str(source)
        out.append((t, m))

    if isinstance(data, dict):
        for key in ("tour_zero_based", "best_tour", "tour"):
            if isinstance(data.get(key), list):
                add(data[key], {
                    "variant_id": data.get("variant_id") or data.get("name") or source.stem,
                    "declared_length": data.get("length") or data.get("best_length"),
                    "json_key": key,
                })
        if isinstance(data.get("results"), list):
            for i, row in enumerate(data["results"]):
                if not isinstance(row, dict):
                    continue
                for key in ("best_tour", "tour_zero_based", "tour"):
                    if isinstance(row.get(key), list):
                        add(row[key], {
                            "variant_id": row.get("variant_id") or row.get("name") or f"result_{i}",
                            "declared_length": row.get("best_length") or row.get("length"),
                            "gap_pct": row.get("gap_pct"),
                            "L_total": row.get("L_total"),
                            "json_key": key,
                        })
                        break
    elif isinstance(data, list):
        add(data, {"variant_id": source.stem, "declared_length": None, "json_key": "root_list"})
    return out


def parse_json_tours(path: Path, n: int) -> list[tuple[list[int], dict[str, Any]]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    return extract_candidates_from_json(data, path, n)


def candidate_sources(root: Path) -> list[Path]:
    priority = [
        root / "out" / "nu3496_dev2_gpu_sub1_focused_surgery_s42_b1920" / "arena_progress.json",
        root / "out" / "nu3496_dev2_gpu_sub1_focused_seed_factory_s42" / "focused_seed_best.json",
        root / "SEED_NU3496_ELITE_FUSION_OROPT_97110.json",
        root / "NU3496_ELITE_FUSION_OROPT_97110.tour",
    ]
    found: list[Path] = []
    seen: set[Path] = set()
    for p in priority:
        if p.exists() and p not in seen:
            found.append(p); seen.add(p)
    out_dir = root / "out"
    if out_dir.exists():
        patterns = ("**/arena_progress.json", "**/focused_seed_best.json")
        for pat in patterns:
            for p in sorted(out_dir.glob(pat)):
                if p not in seen:
                    found.append(p); seen.add(p)
    return found


def write_tour(path: Path, name: str, tour: list[int], length: int, source: str) -> None:
    lines = [
        f"NAME : {name}",
        "TYPE : TOUR",
        f"COMMENT : independently validated length={length}; source={source}",
        f"DIMENSION : {len(tour)}",
        "TOUR_SECTION",
    ]
    lines.extend(str(x + 1) for x in tour)
    lines.extend(["-1", "EOF", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def write_csv(path: Path, tour: list[int], coords_float: list[tuple[float, float]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["order", "node_id_1based", "x", "y", "next_node_id_1based"])
        n = len(tour)
        for i, node in enumerate(tour):
            x, y = coords_float[node]
            w.writerow([i, node + 1, repr(x), repr(y), tour[(i + 1) % n] + 1])


def make_svg(path: Path, tour: list[int], coords: list[tuple[float, float]], title: str, length: int) -> None:
    xs = [p[0] for p in coords]; ys = [p[1] for p in coords]
    xmin, xmax, ymin, ymax = min(xs), max(xs), min(ys), max(ys)
    W, H, pad = 1400, 1000, 30
    sx = (W - 2 * pad) / max(1e-12, xmax - xmin)
    sy = (H - 2 * pad) / max(1e-12, ymax - ymin)
    s = min(sx, sy)
    ox = (W - (xmax - xmin) * s) / 2
    oy = (H - (ymax - ymin) * s) / 2
    def pt(node: int) -> str:
        x, y = coords[node]
        X = ox + (x - xmin) * s
        Y = H - (oy + (y - ymin) * s)
        return f"{X:.2f},{Y:.2f}"
    poly = " ".join(pt(n) for n in tour + [tour[0]])
    txt = f'''<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">
<rect width="100%" height="100%" fill="#071018"/>
<text x="24" y="28" fill="#e8f4ff" font-family="system-ui,sans-serif" font-size="18">{html.escape(title)} · length {length:,}</text>
<polyline points="{poly}" fill="none" stroke="#35d8ff" stroke-opacity="0.72" stroke-width="0.70" stroke-linejoin="round" stroke-linecap="round"/>
</svg>'''
    path.write_text(txt, encoding="utf-8")


def make_html(path: Path, tour: list[int], coords: list[tuple[float, float]], meta: dict[str, Any]) -> None:
    payload = json.dumps({"tour": tour, "coords": coords, "meta": meta}, separators=(",", ":"))
    doc = r'''<!doctype html>
<html lang="sl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>NU3496 · interaktivni prikaz ture</title>
<style>
:root{color-scheme:dark;font-family:Inter,system-ui,Segoe UI,Arial,sans-serif}*{box-sizing:border-box}
body{margin:0;background:#050b11;color:#e8f4ff;overflow:hidden}.bar{position:fixed;z-index:3;top:0;left:0;right:0;display:flex;gap:12px;align-items:center;flex-wrap:wrap;padding:10px 14px;background:rgba(5,11,17,.94);border-bottom:1px solid #183647;backdrop-filter:blur(8px)}
.title{font-weight:800;color:#52ddff}.stat{font-size:13px;color:#b7cad6}.good{color:#76f5a7}button{background:#102433;border:1px solid #28516a;color:#e8f4ff;border-radius:8px;padding:7px 10px;cursor:pointer}button:hover{background:#173449}
#c{position:fixed;inset:0;top:58px;width:100%;height:calc(100% - 58px);touch-action:none}.hint{position:fixed;z-index:3;right:12px;bottom:10px;padding:7px 10px;border-radius:8px;background:rgba(5,11,17,.82);font-size:12px;color:#9eb5c4}.tooltip{position:fixed;z-index:4;display:none;pointer-events:none;background:#07131d;border:1px solid #2a5b75;border-radius:7px;padding:6px 8px;font-size:12px}
@media(max-width:850px){.bar{gap:7px;padding:8px}.stat{font-size:11px}#c{top:96px;height:calc(100% - 96px)}}
</style></head><body>
<div class="bar"><span class="title">NU3496 · naša tura</span><span id="stats" class="stat"></span><button id="fit">Prilagodi</button><button id="points">Točke</button><button id="gradient">Barvni vrstni red</button><button id="width">Debelejša črta</button></div>
<canvas id="c"></canvas><div class="hint">Kolešček: zoom · povleci: premik · dvojni klik: fit</div><div id="tip" class="tooltip"></div>
<script>
const DATA=__PAYLOAD__;
const canvas=document.getElementById('c'),ctx=canvas.getContext('2d'),tip=document.getElementById('tip');
const C=DATA.coords,T=DATA.tour,M=DATA.meta;
let showPoints=false,gradient=false,lineW=0.72,scale=1,tx=0,ty=0,dpr=1,drag=false,lastX=0,lastY=0;
const xs=C.map(p=>p[0]),ys=C.map(p=>p[1]); const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);
function resize(){dpr=Math.max(1,Math.min(2,window.devicePixelRatio||1));const r=canvas.getBoundingClientRect();canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);fit();}
function fit(){const w=canvas.width/dpr,h=canvas.height/dpr,p=24;scale=Math.min((w-2*p)/(maxX-minX),(h-2*p)/(maxY-minY));tx=(w-(maxX-minX)*scale)/2-minX*scale;ty=(h-(maxY-minY)*scale)/2+maxY*scale;draw();}
function sp(n){const p=C[n];return [p[0]*scale+tx,-p[1]*scale+ty]}
function draw(){const w=canvas.width/dpr,h=canvas.height/dpr;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);ctx.fillStyle='#050b11';ctx.fillRect(0,0,w,h);ctx.lineJoin='round';ctx.lineCap='round';ctx.lineWidth=lineW;
 if(!gradient){ctx.strokeStyle='rgba(53,216,255,.68)';ctx.beginPath();let q=sp(T[0]);ctx.moveTo(q[0],q[1]);for(let i=1;i<T.length;i++){q=sp(T[i]);ctx.lineTo(q[0],q[1])}q=sp(T[0]);ctx.lineTo(q[0],q[1]);ctx.stroke()}
 else{for(let i=0;i<T.length;i++){const a=sp(T[i]),b=sp(T[(i+1)%T.length]);ctx.strokeStyle=`hsla(${220+300*i/T.length},95%,65%,.72)`;ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke()}}
 if(showPoints){ctx.fillStyle='rgba(255,255,255,.75)';for(const n of T){const p=sp(n);ctx.beginPath();ctx.arc(p[0],p[1],1.15,0,Math.PI*2);ctx.fill()}}
}
canvas.addEventListener('wheel',e=>{e.preventDefault();const r=canvas.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top;const old=scale,f=e.deltaY<0?1.16:1/1.16;scale*=f;tx=mx-(mx-tx)*(scale/old);ty=my-(my-ty)*(scale/old);draw()},{passive:false});
canvas.addEventListener('pointerdown',e=>{drag=true;lastX=e.clientX;lastY=e.clientY;canvas.setPointerCapture(e.pointerId)});canvas.addEventListener('pointermove',e=>{if(drag){tx+=e.clientX-lastX;ty+=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;draw()}});canvas.addEventListener('pointerup',()=>drag=false);canvas.addEventListener('dblclick',fit);
document.getElementById('fit').onclick=fit;document.getElementById('points').onclick=()=>{showPoints=!showPoints;draw()};document.getElementById('gradient').onclick=()=>{gradient=!gradient;draw()};document.getElementById('width').onclick=()=>{lineW=lineW<1?1.45:.72;draw()};
document.getElementById('stats').innerHTML=`dolžina <b class="good">${Number(M.length).toLocaleString('sl-SI')}</b> · optimum ${Number(M.optimum).toLocaleString('sl-SI')} · gap <b>${M.gap_pct.toFixed(6)}%</b> · ${M.dimension.toLocaleString('sl-SI')} ID-jev · ${M.distinct_coordinates.toLocaleString('sl-SI')} različnih koordinat`;
window.addEventListener('resize',resize);resize();
</script></body></html>'''.replace("__PAYLOAD__", payload)
    path.write_text(doc, encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--tsp", required=True, help="Original TSPLIB EUC_2D .tsp file")
    ap.add_argument("--tour-source", action="append", default=[], help=".tour or JSON source; repeatable")
    ap.add_argument("--root", default=".", help="Arena root for automatic discovery")
    ap.add_argument("--out-root", default="exports", help="Output root")
    ap.add_argument("--optimum", type=int, default=96132)
    ap.add_argument("--name", default=None)
    args = ap.parse_args()

    tsp = Path(args.tsp)
    root = Path(args.root)
    inst = parse_tsplib(tsp)
    n = inst["dimension"]
    sources = [Path(p) for p in args.tour_source] if args.tour_source else candidate_sources(root)
    if not sources:
        raise SystemExit("No tour sources found. Supply --tour-source path.")

    checked: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []
    for source in sources:
        if not source.exists():
            continue
        try:
            if source.suffix.lower() == ".tour":
                candidates = [parse_tour_file(source, n)]
            elif source.suffix.lower() == ".json":
                candidates = parse_json_tours(source, n)
            else:
                continue
            for tour, meta in candidates:
                actual = tour_length(tour, inst["coords_scaled"], inst["scale"])
                declared = meta.get("declared_length")
                declared_ok = declared is None or int(declared) == actual
                checked.append({
                    "tour": tour,
                    "actual_length": actual,
                    "declared_length": int(declared) if declared is not None else None,
                    "declared_length_matches": declared_ok,
                    "source_path": str(source),
                    "variant_id": meta.get("variant_id") or source.stem,
                    "gap_pct": ((actual - args.optimum) / args.optimum * 100.0) if args.optimum else None,
                    "L_total": meta.get("L_total"),
                    "tour_sha256": tour_sha256(tour),
                })
        except Exception as e:
            errors.append({"source": str(source), "error": f"{type(e).__name__}: {e}"})

    if not checked:
        raise SystemExit("No valid complete tours found. Errors: " + json.dumps(errors, indent=2))
    checked.sort(key=lambda x: (x["actual_length"], x["variant_id"], x["source_path"]))
    best = checked[0]
    tour = best.pop("tour")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = args.name or f"{inst['name'].upper()}_8ZRP_{best['actual_length']}"
    out_dir = Path(args.out_root) / f"{name}_{timestamp}"
    out_dir.mkdir(parents=True, exist_ok=True)

    distinct_coords = len(set(inst["coords_scaled"]))
    meta = {
        "tool": VERSION,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "instance": inst["name"],
        "dimension": n,
        "edge_weight_type": inst["edge_weight_type"],
        "distance_rule": "TSPLIB EUC_2D: floor(sqrt(dx^2+dy^2)+0.5), implemented with exact scaled integers",
        "length": best["actual_length"],
        "optimum": args.optimum,
        "gap_pct": ((best["actual_length"] - args.optimum) / args.optimum * 100.0) if args.optimum else None,
        "above_optimum": best["actual_length"] - args.optimum if args.optimum else None,
        "distinct_coordinates": distinct_coords,
        "duplicate_coordinate_ids": n - distinct_coords,
        "tour_sha256": best["tour_sha256"],
        "variant_id": best["variant_id"],
        "source_path": best["source_path"],
        "declared_length": best["declared_length"],
        "declared_length_matches": best["declared_length_matches"],
        "valid_permutation": True,
        "closure_edge_included": True,
    }

    stem = name
    tour_path = out_dir / f"{stem}.tour"
    csv_path = out_dir / f"{stem}.csv"
    svg_path = out_dir / f"{stem}_route.svg"
    html_path = out_dir / f"{stem}_interactive.html"
    verify_path = out_dir / f"{stem}_verification.json"
    checked_path = out_dir / "all_validated_candidates.json"

    write_tour(tour_path, name, tour, best["actual_length"], best["source_path"])
    write_csv(csv_path, tour, inst["coords_float"])
    make_svg(svg_path, tour, inst["coords_float"], name, best["actual_length"])
    make_html(html_path, tour, inst["coords_float"], meta)
    verify_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    checked_path.write_text(json.dumps([{k:v for k,v in c.items() if k != "tour"} for c in checked], indent=2), encoding="utf-8")
    (out_dir / "validation_errors.json").write_text(json.dumps(errors, indent=2), encoding="utf-8")

    print("=" * 78)
    print(VERSION)
    print(f"INSTANCE: {inst['name']} n={n} distinct_coordinates={distinct_coords}")
    print(f"SOURCE:   {best['source_path']}")
    print(f"VARIANT:  {best['variant_id']}")
    print(f"LENGTH:   {best['actual_length']}")
    print(f"OPTIMUM:  {args.optimum}")
    print(f"GAP:      {meta['gap_pct']:.9f}%")
    print(f"SHA256:   {best['tour_sha256']}")
    print(f"OUT:      {out_dir}")
    print("FILES:")
    for p in (tour_path, verify_path, csv_path, svg_path, html_path):
        print(f"  {p.name}")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
